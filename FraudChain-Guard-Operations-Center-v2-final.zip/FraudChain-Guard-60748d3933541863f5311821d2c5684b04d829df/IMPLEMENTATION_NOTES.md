# FraudChain Guard – Updated Prototype

Implemented requested changes:
- Password login gate before dashboard.
- Banking-style left sidebar navigation.
- Professional navy/blue banking operations visual system.
- Case/ticket ID generation for complaint-driven investigations.
- Automatic risk assessment preview when raising a complaint/ticket.
- Existing rule-based risk engine retained and surfaced with signal-by-signal points.
- Investigator manual risk-score override with reason and audit note.
- Expanded case dispositions:
  - Cleared
  - Under Investigation
  - Escalated to Branch Manager
  - Escalated to Internal Fraud Team
  - Escalated to LEA
  - Resolved
  - Closed
- Status/escalation history.
- Customer verification flow changed from SMS/mobile wording to secure-email response simulation.
- Realistic synthetic customer email addresses derived from customer names.

## Prototype login
Password: `Fraud@2026`

## Important security note
This repository is currently deployed as a static GitHub Pages application. The login gate is therefore a prototype access gate, not true server-side authentication. Anyone with access to the shipped frontend can technically inspect/bypass client-side authentication. For production banking use, authentication must be enforced server-side (for example with an identity provider/session service) and secrets must never be placed in frontend code.

## Run locally
After installing dependencies:
- `npm run dev` starts the existing Express/Vite development server.
- `npm run build` builds the static deployment.


## Expanded Operations Center
Added a dedicated Operations Center for the banking-style prototype with:
- Prioritised fraud alert queue with search, SLA-style indicators and bulk queue selection.
- Customer 360 view with KYC/profile data and linked transaction activity.
- Local watchlist management for accounts requiring repeated review.
- Local analyst audit trail for watchlist and export actions.
- CSV transaction ledger export, CSV case register export, JSON audit snapshot and print-ready review.
- System health/control-status panel showing the state of the synthetic risk environment.
- Responsive layout for smaller screens.
- Watchlist and audit data persist locally in browser storage for the prototype.

All new controls remain simulation-only and do not connect to real banking rails, freeze real accounts, or submit real regulatory reports.


## Core banking employee portal (v2)
Design system: Navy `#002D62` headers and primary actions, Crimson `#D32F2F` for alerts, freezes and destructive actions only, Slate `#1E293B` sidebar, `#F8FAFC` canvas. Tokens live at the top of `src/index.css` (`--bk-*`); light, dark and high-contrast themes share them. Type is IBM Plex Sans / Plex Mono.

Shell: collapsible sidebar (drawer on mobile), top bar with branch, alert bell and employee profile menu (theme, sign out), breadcrumbs and page header.

Customer workspace (`src/components/banking/`):
- Lookup by account number, CIF ID, PAN, mobile or name (keyboard navigable).
- Overview, KYC documents (approve / reject with remarks), Transactions (filters, flags, CSV export), Payment controls (per-channel switches), Account status (Debit Freeze, Total Freeze, Dormant with mandatory reason), Service requests (cheque-book address verification, approval, dispatch, tracking), LEA compliance.
- LEA: notices table, complaint detail modal (reference, agency, IO contacts, nature, action, lien/frozen amount, received time, timeline) and a view-only secure document viewer with watermark; each view is audited. A cross-account LEA compliance desk is in the sidebar.
- Rules enforced: restoring to Active is locked while an LEA freeze is in force; cheque-book approval and dispatch are blocked while the account is frozen; lien is capped at the balance.
- Every change is written to a per-customer audit trail (`src/state/useBankState.ts`).

All data is synthetic and in-memory (resets on reload or "Reset demo data"). Nothing connects to real banking rails.
