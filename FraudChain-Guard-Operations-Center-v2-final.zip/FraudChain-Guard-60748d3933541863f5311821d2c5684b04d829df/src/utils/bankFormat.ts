import { formatINR } from './riskEngine';

const TZ = 'Asia/Kolkata';

export const inr = (n: number) => `₹${formatINR(n)}`;

function valid(iso?: string): Date | null {
  if (!iso) return null;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function fmtDate(iso?: string): string {
  const d = valid(iso);
  return d ? d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: TZ }) : '—';
}

export function fmtTime(iso?: string): string {
  const d = valid(iso);
  return d ? d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: TZ }) : '—';
}

export function fmtDateTime(iso?: string): string {
  const d = valid(iso);
  return d ? `${fmtDate(iso)}, ${fmtTime(iso)}` : '—';
}

/** Date-only strings ("2026-09-30") are treated as end of day IST. */
export function toDeadline(iso: string): Date {
  return new Date(iso.length === 10 ? `${iso}T23:59:59+05:30` : iso);
}

export interface DueInfo { text: string; overdue: boolean; soon: boolean }

export function dueInfo(iso: string, now: Date = new Date()): DueInfo {
  const due = toDeadline(iso);
  const ms = due.getTime() - now.getTime();
  const hours = Math.floor(Math.abs(ms) / 3600000);
  const days = Math.floor(hours / 24);
  if (ms < 0) return { text: days >= 1 ? `Overdue by ${days}d` : `Overdue by ${Math.max(hours, 1)}h`, overdue: true, soon: false };
  if (hours < 24) return { text: `Due in ${Math.max(hours, 1)}h`, overdue: false, soon: true };
  return { text: `Due in ${days}d`, overdue: false, soon: days <= 2 };
}

export function ageFrom(iso: string, now: Date = new Date()): string {
  const d = valid(iso);
  if (!d) return '—';
  const months = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
  if (months < 1) return 'Less than a month';
  if (months < 24) return `${months} month${months === 1 ? '' : 's'}`;
  return `${Math.floor(months / 12)} years`;
}

export function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join('');
}

export function maskMobile(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 10 ? `+91 ••••• ••${digits.slice(-3)}` : phone;
}

/** CSV cell escaping, including protection against spreadsheet formula injection. */
function csvCell(value: unknown): string {
  let text = String(value ?? '');
  if (typeof value === 'string' && /^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

export function downloadCsv(filename: string, rows: (string | number | boolean | undefined)[][]) {
  const csv = rows.map((r) => r.map(csvCell).join(',')).join('\n');
  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
