import { Account, RiskBand, Transaction } from '../types';
import {
  AccountStatus, BankProfile, CustomerState, KycStatus, LeaNotice, RiskRating,
} from '../types/banking';

/* ------------------------------ Account status rules ------------------------------ */

export const STATUS_RULES: Record<AccountStatus, { debit: boolean; credit: boolean; summary: string }> = {
  Active: { debit: true, credit: true, summary: 'All debits and credits are allowed, subject to the channel controls.' },
  'Debit Freeze': { debit: false, credit: true, summary: 'Debits are blocked on every channel. Credits are still accepted.' },
  'Total Freeze': { debit: false, credit: false, summary: 'All debits and credits are blocked until the freeze is lifted.' },
  Dormant: { debit: false, credit: true, summary: 'Debits are blocked until re-KYC and reactivation. Credits are still accepted.' },
};

export const isFrozen = (s: AccountStatus) => s === 'Debit Freeze' || s === 'Total Freeze';
export const statusSlug = (s: AccountStatus) => (isFrozen(s) ? 'frozen' : s === 'Dormant' ? 'dormant' : 'active');

export const isFreezeAction = (a: LeaNotice['action']) => a === 'Total Account Freeze' || a === 'Debit Freeze';
export const freezeNotices = (notices: LeaNotice[]) => notices.filter((n) => n.status === 'Action Applied' && isFreezeAction(n.action));
export const openNotices = (notices: LeaNotice[]) => notices.filter((n) => n.status !== 'Released');
export const pendingNotices = (notices: LeaNotice[]) => notices.filter((n) => n.status === 'New' || n.status === 'Acknowledged');

/** Funds the bank must hold under active notices, never more than the balance. */
export function lienHeld(notices: LeaNotice[], balance: number): number {
  const total = notices.filter((n) => n.status === 'Action Applied' && n.lien_amount > 0).reduce((s, n) => s + n.lien_amount, 0);
  return Math.min(total, balance);
}

/* ------------------------------ Risk rating ------------------------------ */

const BAND_POINTS: Record<RiskBand, number> = { Critical: 3, High: 2, Medium: 1, Low: 0 };

export interface RiskAssessment { rating: RiskRating; score: number; factors: string[] }

export function deriveRiskRating(account: Account, transactions: Transaction[], customer: CustomerState): RiskAssessment {
  let score = 0;
  const factors: string[] = [];

  if (account.risk_status === 'Under Investigation') { score += 3; factors.push('Account is under investigation'); }
  else if (account.risk_status === 'Potentially Exposed') { score += 1; factors.push('Account is potentially exposed to fraud proceeds'); }
  else if (account.risk_status === 'Potential Victim') { score += 1; factors.push('Customer is a potential fraud victim'); }

  // Only transactions that put funds into the account, or move them on as part of a chain, describe its own risk.
  const own = transactions.filter(
    (t) => t.receiver_id === account.id || (t.sender_id === account.id && t.is_fraud_chain_part && t.chain_role !== 'Victim Source'),
  );
  const worst = own.reduce<Transaction | null>((w, t) => (!w || BAND_POINTS[t.risk_band] > BAND_POINTS[w.risk_band] ? t : w), null);
  if (worst && BAND_POINTS[worst.risk_band] > 0) {
    score += BAND_POINTS[worst.risk_band];
    factors.push(`${worst.risk_band} risk activity on ${worst.transaction_id}`);
  }

  const open = openNotices(customer.notices);
  if (open.length) { score += 2; factors.push(`${open.length} open LEA notice${open.length > 1 ? 's' : ''}`); }

  const bad = (s: KycStatus) => customer.kyc.filter((d) => d.status === s).length;
  const kycIssues = bad('Rejected') + bad('Expired') + bad('Pending Verification');
  if (kycIssues) {
    score += 1;
    const parts = ([['Rejected', bad('Rejected')], ['Expired', bad('Expired')], ['Pending', bad('Pending Verification')]] as [string, number][])
      .filter(([, n]) => n > 0).map(([l, n]) => `${n} ${l.toLowerCase()}`);
    factors.push(`KYC documents: ${parts.join(', ')}`);
  }

  const rating: RiskRating = score >= 5 ? 'High' : score >= 3 ? 'Medium' : 'Low';
  return { rating, score, factors };
}

/* ------------------------------ Customer lookup ------------------------------ */

export type SearchMode = 'all' | 'account' | 'cif' | 'pan' | 'mobile';
export interface SearchHit { account: Account; profile: BankProfile; matchedOn: string }

const norm = (s: string) => s.toLowerCase().replace(/[\s\-•*]/g, '');
const digitsOf = (s: string) => s.replace(/\D/g, '');

export function searchCustomers(query: string, mode: SearchMode, accounts: Account[], profiles: Record<string, BankProfile>): SearchHit[] {
  const q = norm(query);
  const qd = digitsOf(query);
  if (q.length < 2) return [];
  const want = (m: SearchMode) => mode === 'all' || mode === m;
  const hits: SearchHit[] = [];
  for (const account of accounts) {
    const profile = profiles[account.id];
    if (!profile) continue;
    let matchedOn: string | null = null;
    if (want('account') && qd.length >= 3 && profile.account_number.includes(qd)) matchedOn = 'Account number';
    else if (want('cif') && norm(profile.cif_id).includes(q)) matchedOn = 'CIF ID';
    else if (want('pan') && norm(profile.pan_full).includes(q)) matchedOn = 'PAN';
    else if (want('mobile') && qd.length >= 4 && digitsOf(account.phone).includes(qd)) matchedOn = 'Mobile number';
    else if (mode === 'all' && (norm(account.name).includes(q) || norm(account.id).includes(q) || norm(account.upi_handle || '').includes(q))) matchedOn = 'Name / ID';
    if (matchedOn) hits.push({ account, profile, matchedOn });
  }
  return hits;
}
