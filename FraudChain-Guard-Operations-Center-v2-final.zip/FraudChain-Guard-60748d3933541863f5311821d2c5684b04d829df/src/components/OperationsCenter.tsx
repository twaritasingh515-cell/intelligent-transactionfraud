import React from 'react';
import {
  Activity, AlertCircle, Archive, ArrowUpRight, Bell, CheckCircle2, ClipboardList,
  Download, Eye, FileText, Flag, History, LockKeyhole, Network, Search, Shield,
  ShieldCheck, SlidersHorizontal, UserRound, Users, XCircle
} from 'lucide-react';
import { Account, Transaction } from '../types';
import { formatINR } from '../utils/riskEngine';

type Module = 'queue' | 'customers' | 'watchlist' | 'audit' | 'reports' | 'health';

interface OperationsCenterProps {
  accounts: Account[];
  transactions: Transaction[];
  onSelectTransaction: (tx: Transaction) => void;
  onOpenCase: (tx: Transaction) => void;
  onToast: (message: string, type?: 'success' | 'alert' | 'info') => void;
}

const moduleItems: { id: Module; label: string; icon: React.ElementType }[] = [
  { id: 'queue', label: 'Alert Queue', icon: ClipboardList },
  { id: 'customers', label: 'Customer 360', icon: UserRound },
  { id: 'watchlist', label: 'Watchlist', icon: Flag },
  { id: 'audit', label: 'Audit Trail', icon: History },
  { id: 'reports', label: 'Reports & Export', icon: FileText },
  { id: 'health', label: 'System Health', icon: Activity },
];

const riskRank: Record<Transaction['risk_band'], number> = { Critical: 4, High: 3, Medium: 2, Low: 1 };

function downloadFile(filename: string, content: string, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function csvEscape(value: unknown) {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

function riskBadge(band: Transaction['risk_band']) {
  return `ops-risk ops-risk-${band.toLowerCase()}`;
}

export const OperationsCenter: React.FC<OperationsCenterProps> = ({
  accounts,
  transactions,
  onSelectTransaction,
  onOpenCase,
  onToast,
}) => {
  const [module, setModule] = React.useState<Module>('queue');
  const [query, setQuery] = React.useState('');
  const [selectedAccountId, setSelectedAccountId] = React.useState(accounts[0]?.id || '');
  const [watchlist, setWatchlist] = React.useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('fraudchain_watchlist') || '[]'); } catch { return []; }
  });
  const [audit, setAudit] = React.useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('fraudchain_audit') || '[]'); } catch { return []; }
  });
  const [autoRefresh, setAutoRefresh] = React.useState(true);
  const [lastScan, setLastScan] = React.useState(new Date());
  const [selectedRows, setSelectedRows] = React.useState<string[]>([]);

  const appendAudit = React.useCallback((event: string) => {
    const entry = `${new Date().toLocaleString('en-IN')} • ${event}`;
    setAudit((prev) => {
      const next = [entry, ...prev].slice(0, 100);
      localStorage.setItem('fraudchain_audit', JSON.stringify(next));
      return next;
    });
  }, []);

  React.useEffect(() => {
    localStorage.setItem('fraudchain_watchlist', JSON.stringify(watchlist));
  }, [watchlist]);

  React.useEffect(() => {
    if (!autoRefresh) return;
    const timer = window.setInterval(() => setLastScan(new Date()), 15000);
    return () => window.clearInterval(timer);
  }, [autoRefresh]);

  const alerts = React.useMemo(() => transactions
    .filter((tx) => tx.risk_band === 'Critical' || tx.risk_band === 'High' || tx.investigation_status === 'Customer Verification Pending')
    .sort((a, b) => riskRank[b.risk_band] - riskRank[a.risk_band] || b.risk_score - a.risk_score), [transactions]);

  const filteredAlerts = alerts.filter((tx) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return [tx.transaction_id, tx.case_id, tx.investigation_status, tx.risk_band].some((v) => String(v || '').toLowerCase().includes(q));
  });

  const selectedAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];
  const customerTransactions = selectedAccount ? transactions.filter((tx) => tx.sender_id === selectedAccount.id || tx.receiver_id === selectedAccount.id) : [];
  const accountIncoming = customerTransactions.filter((tx) => tx.receiver_id === selectedAccount?.id).reduce((sum, tx) => sum + tx.amount, 0);
  const accountOutgoing = customerTransactions.filter((tx) => tx.sender_id === selectedAccount?.id).reduce((sum, tx) => sum + tx.amount, 0);

  const toggleWatch = (id: string, label: string) => {
    setWatchlist((prev) => {
      const exists = prev.includes(id);
      const next = exists ? prev.filter((x) => x !== id) : [...prev, id];
      appendAudit(`${exists ? 'Removed from' : 'Added to'} watchlist: ${label} (${id})`);
      onToast(`${label} ${exists ? 'removed from' : 'added to'} watchlist`, 'info');
      return next;
    });
  };

  const exportTransactions = () => {
    const headers = ['Transaction ID', 'Sender', 'Receiver', 'Amount', 'Type', 'Risk Score', 'Risk Band', 'Status', 'Case ID'];
    const rows = transactions.map((tx) => [tx.transaction_id, tx.sender_id, tx.receiver_id, tx.amount, tx.type, tx.risk_score, tx.risk_band, tx.investigation_status, tx.case_id || '']);
    const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(',')).join('\n');
    downloadFile(`fraudchain-transactions-${Date.now()}.csv`, csv, 'text/csv');
    appendAudit('Exported transaction ledger CSV');
    onToast('Transaction CSV exported successfully', 'success');
  };

  const exportCases = () => {
    const cases = transactions.filter((tx) => tx.case_id || tx.risk_score >= 51);
    const headers = ['Case ID', 'Transaction ID', 'Risk', 'Band', 'Status', 'Signals', 'Complaint Ref'];
    const rows = cases.map((tx) => [tx.case_id || `CASE-${tx.transaction_id.slice(-6)}`, tx.transaction_id, tx.risk_score, tx.risk_band, tx.investigation_status, tx.detected_signals.map((s) => s.name).join(' | '), tx.complaint?.portal_ref || '']);
    const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(',')).join('\n');
    downloadFile(`fraudchain-case-register-${Date.now()}.csv`, csv, 'text/csv');
    appendAudit('Exported case register CSV');
    onToast('Case register exported successfully', 'success');
  };

  const exportSnapshot = () => {
    const payload = { generatedAt: new Date().toISOString(), accounts, transactions, watchlist, audit };
    downloadFile(`fraudchain-audit-snapshot-${Date.now()}.json`, JSON.stringify(payload, null, 2), 'application/json');
    appendAudit('Exported full audit snapshot JSON');
    onToast('Audit snapshot exported', 'success');
  };

  const bulkReview = () => {
    if (!selectedRows.length) {
      onToast('Select one or more alerts first', 'info');
      return;
    }
    appendAudit(`Bulk review queue action opened for ${selectedRows.length} alert(s)`);
    onToast(`${selectedRows.length} alert(s) marked for review queue`, 'success');
    setSelectedRows([]);
  };

  const renderQueue = () => (
    <div className="space-y-5">
      <div className="ops-grid-4">
        <Metric label="Open Alerts" value={alerts.length} icon={Bell} tone="red" />
        <Metric label="Critical" value={alerts.filter((x) => x.risk_band === 'Critical').length} icon={Shield} tone="red" />
        <Metric label="High Risk" value={alerts.filter((x) => x.risk_band === 'High').length} icon={AlertCircle} tone="amber" />
        <Metric label="Watchlist" value={watchlist.length} icon={Flag} tone="blue" />
      </div>

      <div className="ops-panel">
        <div className="ops-panel-head">
          <div><div className="ops-eyebrow">REAL-TIME TRIAGE</div><h2>Fraud alert work queue</h2><p>Prioritised synthetic alerts with SLA-style handling controls.</p></div>
          <div className="flex items-center gap-2">
            <label className="ops-toggle"><input type="checkbox" checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} /><span /> Auto refresh</label>
            <button className="ops-btn" onClick={bulkReview}><ClipboardList className="w-4 h-4" /> Queue selected</button>
          </div>
        </div>
        <div className="ops-toolbar">
          <div className="ops-search"><Search className="w-4 h-4" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search transaction, case, status..." /></div>
          <span className="ops-muted">{autoRefresh ? `Queue scan active • ${lastScan.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` : 'Queue scan paused'}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="ops-table"><thead><tr><th></th><th>Alert</th><th>Risk</th><th>Amount</th><th>Status</th><th>Signals</th><th>SLA</th><th></th></tr></thead>
            <tbody>{filteredAlerts.map((tx) => {
              const selected = selectedRows.includes(tx.transaction_id);
              const sla = tx.risk_band === 'Critical' ? '08 min' : tx.risk_band === 'High' ? '24 min' : '45 min';
              return <tr key={tx.transaction_id} className={selected ? 'ops-row-selected' : ''}>
                <td><input type="checkbox" checked={selected} onChange={() => setSelectedRows((prev) => selected ? prev.filter((x) => x !== tx.transaction_id) : [...prev, tx.transaction_id])} /></td>
                <td><button className="ops-link" onClick={() => onSelectTransaction(tx)}>{tx.transaction_id}</button><div className="ops-sub">{tx.case_id || 'No case ID'} • {tx.type}</div></td>
                <td><span className={riskBadge(tx.risk_band)}>{tx.risk_band} {tx.risk_score}</span></td>
                <td>₹{formatINR(tx.amount)}</td>
                <td><span className="ops-status">{tx.investigation_status}</span></td>
                <td><span className="ops-sub">{tx.detected_signals.slice(0, 2).map((s) => s.name).join(' • ') || 'No active signal'}</span></td>
                <td><span className={tx.risk_band === 'Critical' ? 'ops-sla urgent' : 'ops-sla'}>{sla}</span></td>
                <td><div className="flex gap-1"><button title="Open case" className="ops-icon-btn" onClick={() => onOpenCase(tx)}><Eye className="w-4 h-4" /></button><button title="Watchlist" className={`ops-icon-btn ${watchlist.includes(tx.receiver_id) ? 'is-on' : ''}`} onClick={() => toggleWatch(tx.receiver_id, 'Receiver account')}><Flag className="w-4 h-4" /></button></div></td>
              </tr>;
            })}</tbody>
          </table>
          {!filteredAlerts.length && <EmptyState label="No matching alerts in the current queue." />}
        </div>
      </div>
    </div>
  );

  const renderCustomers = () => (
    <div className="space-y-5">
      <div className="ops-panel"><div className="ops-panel-head"><div><div className="ops-eyebrow">CUSTOMER 360</div><h2>Account profile investigation</h2><p>Review KYC profile, transaction behaviour and linked risk without leaving the console.</p></div><select className="ops-select" value={selectedAccount?.id || ''} onChange={(e) => setSelectedAccountId(e.target.value)}>{accounts.map((a) => <option key={a.id} value={a.id}>{a.name} • {a.id}</option>)}</select></div></div>
      {selectedAccount && <>
        <div className="ops-grid-4">
          <Metric label="Risk status" value={selectedAccount.risk_status} icon={ShieldCheck} tone={selectedAccount.risk_status === 'Normal' ? 'green' : 'red'} />
          <Metric label="Transactions" value={customerTransactions.length} icon={Network} tone="blue" />
          <Metric label="Incoming observed" value={`₹${formatINR(accountIncoming)}`} icon={ArrowUpRight} tone="green" />
          <Metric label="Outgoing observed" value={`₹${formatINR(accountOutgoing)}`} icon={ArrowUpRight} tone="amber" />
        </div>
        <div className="ops-customer-grid">
          <div className="ops-panel"><div className="ops-section-title"><UserRound className="w-4 h-4" /> KYC & profile</div><div className="ops-profile-grid">
            <Info label="Customer" value={selectedAccount.name} /><Info label="Account ID" value={selectedAccount.id} /><Info label="Account type" value={selectedAccount.account_type} /><Info label="Occupation" value={selectedAccount.kyc_occupation} /><Info label="Account age" value={selectedAccount.account_age} /><Info label="City" value={selectedAccount.city} /><Info label="PAN" value={selectedAccount.pan_masked} /><Info label="UPI" value={selectedAccount.upi_handle || '—'} /><Info label="Phone" value={selectedAccount.phone} /><Info label="Expected monthly credit" value={`₹${formatINR(selectedAccount.usual_monthly_credit_range[0])} – ₹${formatINR(selectedAccount.usual_monthly_credit_range[1])}`} />
          </div><div className="ops-note-box"><strong>Analyst note</strong><span>{selectedAccount.notes || 'No profile notes recorded.'}</span></div>
          <button className={`ops-btn ${watchlist.includes(selectedAccount.id) ? 'danger' : ''}`} onClick={() => toggleWatch(selectedAccount.id, selectedAccount.name)}><Flag className="w-4 h-4" /> {watchlist.includes(selectedAccount.id) ? 'Remove from watchlist' : 'Add to watchlist'}</button>
          </div>
          <div className="ops-panel"><div className="ops-section-title"><Network className="w-4 h-4" /> Linked activity</div><div className="space-y-2">{customerTransactions.slice(0, 12).map((tx) => <button key={tx.transaction_id} className="ops-activity-row" onClick={() => onSelectTransaction(tx)}><span><b>{tx.transaction_id}</b><small>{tx.type} • {tx.investigation_status}</small></span><span className={riskBadge(tx.risk_band)}>{tx.risk_score}</span><strong>₹{formatINR(tx.amount)}</strong></button>)}{!customerTransactions.length && <EmptyState label="No linked transactions." />}</div></div>
        </div>
      </>}
    </div>
  );

  const renderWatchlist = () => (
    <div className="ops-panel"><div className="ops-panel-head"><div><div className="ops-eyebrow">CONTROL LIST</div><h2>Watchlist management</h2><p>Track accounts that need repeated review. This is a local simulation only.</p></div><div className="ops-stat-chip"><Flag className="w-4 h-4" /> {watchlist.length} monitored</div></div>
      <div className="ops-watch-grid">{watchlist.map((id) => { const acc = accounts.find((a) => a.id === id); const tx = transactions.find((t) => t.sender_id === id || t.receiver_id === id); return <div className="ops-watch-card" key={id}><div className="flex items-start justify-between"><div><div className="font-bold">{acc?.name || tx?.transaction_id || id}</div><div className="ops-sub">{id}</div></div><button className="ops-icon-btn" onClick={() => toggleWatch(id, acc?.name || id)}><XCircle className="w-4 h-4" /></button></div><div className="ops-watch-meta"><span>{acc?.risk_status || 'Transaction monitor'}</span><span>{acc ? acc.account_type : 'Linked alert'}</span></div></div>; })}{!watchlist.length && <EmptyState label="Watchlist is empty. Add an account from Alert Queue or Customer 360." />}</div>
    </div>
  );

  const renderAudit = () => (
    <div className="ops-panel"><div className="ops-panel-head"><div><div className="ops-eyebrow">CONTROL EVIDENCE</div><h2>Audit trail</h2><p>Local prototype log of analyst actions and exports.</p></div><button className="ops-btn" onClick={() => { localStorage.removeItem('fraudchain_audit'); setAudit([]); onToast('Local audit trail cleared', 'info'); }}><Archive className="w-4 h-4" /> Clear local log</button></div><div className="ops-audit-list">{audit.map((event, i) => <div className="ops-audit-row" key={`${event}-${i}`}><span className="ops-audit-dot" /><span>{event}</span></div>)}{!audit.length && <EmptyState label="No local audit events yet. Actions taken in this module will appear here." />}</div></div>
  );

  const renderReports = () => (
    <div className="ops-grid-2">
      <ReportCard icon={Download} title="Transaction ledger" text="Export all synthetic transactions with risk, status and case fields." button="Export CSV" onClick={exportTransactions} />
      <ReportCard icon={FileText} title="Case register" text="Export high-risk and case-linked alerts for review or presentation." button="Export CSV" onClick={exportCases} />
      <ReportCard icon={LockKeyhole} title="Audit snapshot" text="Create a portable JSON snapshot containing current demo data and local audit events." button="Export JSON" onClick={exportSnapshot} />
      <ReportCard icon={SlidersHorizontal} title="Print-ready review" text="Use the browser print dialog to create a paper/PDF review pack." button="Print" onClick={() => { appendAudit('Opened print-ready review'); window.print(); }} />
    </div>
  );

  const renderHealth = () => {
    const critical = transactions.filter((x) => x.risk_band === 'Critical').length;
    const flagged = transactions.filter((x) => x.risk_score >= 51).length;
    const complaintLinked = transactions.filter((x) => x.complaint).length;
    return <div className="space-y-5"><div className="ops-grid-4"><HealthCard label="Core monitoring" value="ONLINE" ok /><HealthCard label="Risk engine" value="ACTIVE" ok /><HealthCard label="Synthetic feed" value="STREAMING" ok /><HealthCard label="AI assistant" value="OPTIONAL" ok={false} /></div><div className="ops-grid-2"><div className="ops-panel"><div className="ops-section-title"><Activity className="w-4 h-4" /> Monitoring snapshot</div><div className="ops-health-list"><Info label="Total transactions" value={transactions.length} /><Info label="High + critical" value={flagged} /><Info label="Critical alerts" value={critical} /><Info label="Cyber complaints linked" value={complaintLinked} /><Info label="Accounts monitored" value={accounts.length} /><Info label="Watchlist entries" value={watchlist.length} /></div></div><div className="ops-panel"><div className="ops-section-title"><Shield className="w-4 h-4" /> Control status</div><div className="space-y-3"><HealthLine label="Automatic scoring" detail="Signal-weighted scoring with 0–100 cap" ok /><HealthLine label="Manual override" detail="Investigator override is retained with reason" ok /><HealthLine label="Case history" detail="Status changes append a timeline event" ok /><HealthLine label="Real bank integration" detail="Disabled in this prototype" ok={false} /></div></div></div></div>;
  };

  const content: Record<Module, React.ReactNode> = { queue: renderQueue(), customers: renderCustomers(), watchlist: renderWatchlist(), audit: renderAudit(), reports: renderReports(), health: renderHealth() };

  return <section className="space-y-5 animate-fadeIn">
    <div className="ops-hero"><div><div className="ops-eyebrow">BANK OPERATIONS CENTER</div><h2>Fraud Control & Investigation Workspace</h2><p>One console for triage, customer review, watchlists, audit evidence, reporting and system health.</p></div><div className="ops-hero-badge"><span className="ops-live-dot" /> Monitoring active</div></div>
    <div className="ops-module-tabs">{moduleItems.map(({ id, label, icon: Icon }) => <button key={id} className={module === id ? 'active' : ''} onClick={() => setModule(id)}><Icon className="w-4 h-4" /> {label}</button>)}</div>
    {content[module]}
  </section>;
};

const Metric: React.FC<{ label: string; value: React.ReactNode; icon: React.ElementType; tone: string }> = ({ label, value, icon: Icon, tone }) => <div className={`ops-metric tone-${tone}`}><div className="ops-metric-icon"><Icon className="w-4 h-4" /></div><div><div className="ops-sub">{label}</div><div className="ops-metric-value">{value}</div></div></div>;
const Info: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => <div className="ops-info"><span>{label}</span><strong>{value}</strong></div>;
const EmptyState: React.FC<{ label: string }> = ({ label }) => <div className="ops-empty"><Archive className="w-5 h-5" /><span>{label}</span></div>;
const ReportCard: React.FC<{ icon: React.ElementType; title: string; text: string; button: string; onClick: () => void }> = ({ icon: Icon, title, text, button, onClick }) => <div className="ops-report-card"><div className="ops-report-icon"><Icon className="w-5 h-5" /></div><h3>{title}</h3><p>{text}</p><button className="ops-btn" onClick={onClick}>{button}</button></div>;
const HealthCard: React.FC<{ label: string; value: string; ok: boolean }> = ({ label, value, ok }) => <div className="ops-health-card"><span className={ok ? 'health-check' : 'health-neutral'}>{ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}</span><div><div className="ops-sub">{label}</div><strong>{value}</strong></div></div>;
const HealthLine: React.FC<{ label: string; detail: string; ok: boolean }> = ({ label, detail, ok }) => <div className="ops-health-line"><span className={ok ? 'health-check' : 'health-neutral'}>{ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}</span><div><b>{label}</b><small>{detail}</small></div></div>;
