import React, { useEffect, useRef, useState } from 'react';
import { Bell, Check, ChevronDown, Contrast, LogOut, Menu, Moon, Search, Sun } from 'lucide-react';
import { EMPLOYEE } from '../data/bankingData';
import { initials } from '../utils/bankFormat';

type Theme = 'light' | 'dark' | 'black';

interface Props {
  onOpenMenu: () => void;
  onSearch: (query: string) => void;
  alertCount: number;
  onOpenAlerts: () => void;
  theme: Theme;
  onThemeChange: (t: Theme) => void;
  onLogout: () => void;
}

const THEMES: { id: Theme; label: string; icon: React.ElementType }[] = [
  { id: 'light', label: 'Light', icon: Sun }, { id: 'dark', label: 'Dark', icon: Moon }, { id: 'black', label: 'High contrast', icon: Contrast },
];

export const TopBar: React.FC<Props> = ({ onOpenMenu, onSearch, alertCount, onOpenAlerts, theme, onThemeChange, onLogout }) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', away); document.removeEventListener('keydown', esc); };
  }, [open]);

  return (
    <header className="bk-topbar">
      <button className="bk-icon-btn lg:hidden" onClick={onOpenMenu} aria-label="Open navigation menu"><Menu size={20} /></button>
      <form className="bk-top-search" role="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) { onSearch(q.trim()); setQ(''); } }}>
        <Search size={16} aria-hidden />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find a customer" aria-label="Quick customer lookup" />
      </form>
      <div style={{ flex: 1 }} />
      <div className="bk-branch-chip"><b>{EMPLOYEE.branch}</b><span>Branch {EMPLOYEE.branch_code} · {EMPLOYEE.ifsc}</span></div>
      <button className="bk-icon-btn" onClick={onOpenAlerts} aria-label={`${alertCount} open fraud alerts`} title="Fraud alerts">
        <Bell size={18} />{alertCount > 0 && <span className="bk-pip">{alertCount > 99 ? '99+' : alertCount}</span>}
      </button>
      <div ref={ref} style={{ position: 'relative' }}>
        <button className="bk-profile-btn" onClick={() => setOpen((v) => !v)} aria-haspopup="menu" aria-expanded={open}>
          <span className="bk-avatar">{initials(EMPLOYEE.name)}</span>
          <div style={{ lineHeight: 1.2 }}><b style={{ fontWeight: 600, fontSize: 13 }}>{EMPLOYEE.name}</b><small>{EMPLOYEE.employee_id}</small></div>
          <ChevronDown size={14} />
        </button>
        {open && (
          <div className="bk-menu" role="menu">
            <div className="bk-menu-head">
              <b>{EMPLOYEE.name}</b>
              <div className="bk-small bk-muted">{EMPLOYEE.role}</div>
              <div className="bk-small bk-muted">{EMPLOYEE.employee_id} · {EMPLOYEE.branch} · {EMPLOYEE.region}</div>
            </div>
            <div className="bk-menu-label">Appearance</div>
            {THEMES.map(({ id, label, icon: Icon }) => (
              <button key={id} role="menuitemradio" aria-checked={theme === id} className={`bk-menu-item ${theme === id ? 'is-selected' : ''}`} onClick={() => onThemeChange(id)}>
                <Icon size={15} /><span style={{ flex: 1 }}>{label}</span>{theme === id && <Check size={14} />}
              </button>
            ))}
            <div style={{ borderTop: '1px solid var(--bk-border)' }} />
            <button role="menuitem" className="bk-menu-item is-danger" onClick={onLogout}><LogOut size={15} /> Sign out</button>
          </div>
        )}
      </div>
    </header>
  );
};
