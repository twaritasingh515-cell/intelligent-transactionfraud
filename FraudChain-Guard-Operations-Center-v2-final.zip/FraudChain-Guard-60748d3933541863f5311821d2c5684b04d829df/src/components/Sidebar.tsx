import React from 'react';
import {
  Building2, ClipboardList, FileSearch, Gauge, GitFork, Landmark, LayoutDashboard, MessageSquare,
  PlusCircle, Radio, RefreshCw, Scale, UsersRound, Zap, PanelLeftClose, PanelLeftOpen,
} from 'lucide-react';

export type Tab = 'customers' | 'lea' | 'dashboard' | 'graph' | 'cases' | 'triggers' | 'simulator' | 'operations';

interface SidebarProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  activeCasesCount: number;
  pendingLeaCount: number;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onInjectSpike: () => void;
  onResetData: () => void;
  onOpenChat: () => void;
  onOpenVoice: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab, setActiveTab, activeCasesCount, pendingLeaCount, collapsed, onToggleCollapsed, mobileOpen, onCloseMobile,
  onInjectSpike, onResetData, onOpenChat, onOpenVoice,
}) => {
  const groups: { label: string; items: { id: Tab; label: string; icon: React.ElementType; count?: number }[] }[] = [
    { label: 'Branch operations', items: [
      { id: 'customers', label: 'Customer workspace', icon: UsersRound },
      { id: 'lea', label: 'LEA compliance desk', icon: Scale, count: pendingLeaCount },
    ] },
    { label: 'Fraud monitoring', items: [
      { id: 'dashboard', label: 'Overview & ledger', icon: LayoutDashboard },
      { id: 'graph', label: 'Fraud chain graph', icon: GitFork },
      { id: 'cases', label: 'Investigation cases', icon: FileSearch, count: activeCasesCount },
      { id: 'triggers', label: 'Triggers & scrutiny', icon: Zap },
      { id: 'simulator', label: 'Risk engine', icon: Gauge },
      { id: 'operations', label: 'Operations center', icon: ClipboardList },
    ] },
  ];
  const go = (id: Tab) => { setActiveTab(id); onCloseMobile(); };
  const tool = (label: string, Icon: React.ElementType, onClick: () => void) => (
    <button key={label} className="bk-nav" onClick={() => { onClick(); onCloseMobile(); }} title={collapsed ? label : undefined} aria-label={label}>
      <Icon size={17} /><span className="bk-nav-label">{label}</span>
    </button>
  );

  return (
    <>
      {mobileOpen && <div className="bk-scrim" onClick={onCloseMobile} aria-hidden />}
      <aside className={`bk-sidebar ${collapsed ? 'is-collapsed' : ''} ${mobileOpen ? 'is-open' : ''}`} aria-label="Main navigation">
        <div className="bk-brand">
          <div className="bk-brand-mark"><Landmark size={18} /></div>
          <div><b>FraudChain Bank</b><small>Operations portal</small></div>
        </div>
        <nav className="bk-side-scroll">
          {groups.map((g) => (
            <div key={g.label}>
              <div className="bk-side-group">{g.label}</div>
              {g.items.map(({ id, label, icon: Icon, count }) => (
                <button key={id} className={`bk-nav ${activeTab === id ? 'is-active' : ''}`} onClick={() => go(id)}
                  aria-current={activeTab === id ? 'page' : undefined} title={collapsed ? label : undefined}>
                  <Icon size={17} /><span className="bk-nav-label">{label}</span>
                  {!!count && <span className="bk-count">{count}</span>}
                </button>
              ))}
            </div>
          ))}
          <div className="bk-side-group">Analyst tools</div>
          {tool('AML Copilot', MessageSquare, onOpenChat)}
          {tool('Live voice', Radio, onOpenVoice)}
          {tool('Simulate alert', PlusCircle, onInjectSpike)}
          {tool('Reset demo data', RefreshCw, onResetData)}
        </nav>
        <div className="bk-side-foot">
          <button className="bk-nav" onClick={onToggleCollapsed} style={{ display: 'flex' }} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
            {collapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}<span className="bk-nav-label">Collapse sidebar</span>
          </button>
          {!collapsed && <div className="bk-small" style={{ padding: '6px 12px 0', color: '#7C8BA3', display: 'flex', gap: 6, alignItems: 'center' }}><Building2 size={12} /> Synthetic demonstration data</div>}
        </div>
      </aside>
    </>
  );
};
