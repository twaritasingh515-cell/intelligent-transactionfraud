import React, { useMemo, useState } from 'react';
import { Account } from '../types';
import { BankState, LeaNotice, LeaNoticeStatus } from '../types/banking';
import { dueInfo, fmtDateTime, inr } from '../utils/bankFormat';
import { Badge, Card, EmptyState, Stat, noticeTone } from './banking/ui';
import { lienHeld } from '../utils/bankSelectors';

type Row = { notice: LeaNotice; account: Account };
const FILTERS: ('All' | 'Open' | LeaNoticeStatus)[] = ['Open', 'New', 'Acknowledged', 'Action Applied', 'Released', 'All'];

/** Cross-customer queue of every LEA notice, so nothing waits inside a single account. */
export const LeaDesk: React.FC<{ accounts: Account[]; bank: BankState; onOpen: (accountId: string, noticeId: string) => void }> = ({ accounts, bank, onOpen }) => {
  const [filter, setFilter] = useState<typeof FILTERS[number]>('Open');
  const rows = useMemo<Row[]>(() => accounts.flatMap((a) => (bank[a.id]?.notices || []).map((n) => ({ notice: n, account: a })))
    .sort((a, b) => new Date(b.notice.received_at).getTime() - new Date(a.notice.received_at).getTime()), [accounts, bank]);
  const shown = rows.filter((r) => filter === 'All' ? true : filter === 'Open' ? r.notice.status !== 'Released' : r.notice.status === filter);
  const count = (s: LeaNoticeStatus) => rows.filter((r) => r.notice.status === s).length;
  const held = accounts.reduce((sum, a) => sum + lienHeld(bank[a.id]?.notices || [], a.current_balance), 0);

  return (
    <div className="bk-stack">
      <div className="bk-grid-4">
        <Stat label="New notices" value={count('New')} alert={count('New') > 0} hint="Need acknowledgement" />
        <Stat label="Acknowledged" value={count('Acknowledged')} hint="Action not yet applied" />
        <Stat label="Action applied" value={count('Action Applied')} hint="Freeze, lien or hold in force" />
        <Stat label="Total held across accounts" value={inr(held)} alert={held > 0} />
      </div>
      <Card title="All LEA notices" subtitle="Select a notice to open the complaint and the notice document" flush
        actions={<div className="bk-row">{FILTERS.map((f) => <button key={f} className={`bk-chip ${filter === f ? 'is-active' : ''}`} aria-pressed={filter === f} onClick={() => setFilter(f)}>{f}</button>)}</div>}>
        {shown.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr><th>Complaint ID</th><th>Account holder</th><th>Agency</th><th>Nature</th><th>Action required</th><th className="is-right">Lien / frozen</th><th>Received</th><th>Response due</th><th>Status</th></tr></thead>
              <tbody>
                {shown.map(({ notice: n, account: a }) => {
                  const due = n.status === 'Released' ? null : dueInfo(n.response_due);
                  return (
                    <tr key={n.id} className={`is-clickable ${n.status === 'New' ? 'is-flagged' : ''}`} onClick={() => onOpen(a.id, n.id)} tabIndex={0}
                      onKeyDown={(e) => { if (e.key === 'Enter') onOpen(a.id, n.id); }}>
                      <td><span className="bk-mono bk-strong">{n.complaint_ref}</span></td>
                      <td>{a.name}</td>
                      <td className="is-agency">{n.agency}</td>
                      <td><Badge tone="danger">{n.nature}</Badge></td>
                      <td>{n.action}</td>
                      <td className="is-right bk-num">{n.action === 'Information Request' ? '—' : inr(n.lien_amount)}</td>
                      <td className="bk-num" style={{ whiteSpace: 'nowrap' }}>{fmtDateTime(n.received_at)}</td>
                      <td style={{ color: due?.overdue ? 'var(--bk-danger)' : undefined, whiteSpace: 'nowrap' }}>{due ? due.text : '—'}</td>
                      <td><Badge tone={noticeTone(n.status)} dot>{n.status}</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : <EmptyState title="No notices in this view" text="Try another status filter." />}
      </Card>
    </div>
  );
};
