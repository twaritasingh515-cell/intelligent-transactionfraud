import React, { useState } from 'react';
import { AlertCircle, Eye, EyeOff, Landmark, LockKeyhole } from 'lucide-react';

interface LoginScreenProps {
  onAuthenticated: () => void;
}

const DEMO_PASSWORD = 'Fraud@2026';

export const LoginScreen: React.FC<LoginScreenProps> = ({ onAuthenticated }) => {
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === DEMO_PASSWORD) {
      sessionStorage.setItem('fraudchain_authenticated', 'true');
      onAuthenticated();
    } else {
      setError('That password is incorrect. Check it and try again.');
      setPassword('');
    }
  };

  return (
    <div className="app-shell theme-light bk-login">
      <section className="bk-login-brand">
        <div className="bk-row" style={{ gap: 12 }}>
          <span className="bk-brand-mark"><Landmark size={18} /></span>
          <b style={{ fontSize: 15, fontWeight: 600 }}>FraudChain Bank</b>
        </div>
        <div>
          <h1>Branch and fraud operations portal</h1>
          <p>Look up customers, review KYC, control payment channels, freeze accounts and answer law enforcement notices from one place.</p>
        </div>
        <small style={{ color: 'rgba(255,255,255,.7)' }}>Authorised personnel only. Synthetic demonstration data.</small>
      </section>
      <section className="bk-login-panel">
        <form className="bk-login-card" onSubmit={submit}>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 600, color: 'var(--bk-link)' }}>Employee sign-in</h2>
          <p className="bk-muted" style={{ margin: '4px 0 20px' }}>Enter the console password to continue.</p>
          <label className="bk-label" htmlFor="pw">Console password</label>
          <div style={{ position: 'relative' }}>
            <LockKeyhole size={16} className="bk-muted" style={{ position: 'absolute', left: 11, top: 10 }} aria-hidden />
            <input id="pw" autoFocus type={show ? 'text' : 'password'} className={`bk-input ${error ? 'is-invalid' : ''}`} style={{ paddingLeft: 34, paddingRight: 38 }}
              value={password} onChange={(e) => { setPassword(e.target.value); setError(''); }} placeholder="Enter password" autoComplete="current-password" aria-invalid={!!error} aria-describedby={error ? 'pw-err' : undefined} />
            <button type="button" className="bk-icon-btn" style={{ position: 'absolute', right: 2, top: 0, color: 'var(--bk-muted)' }} onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {error && <div id="pw-err" className="bk-alert bk-alert-danger" role="alert" style={{ marginTop: 12 }}><AlertCircle size={16} /><div>{error}</div></div>}
          <button className="bk-btn is-primary" style={{ width: '100%', height: 40, marginTop: 18 }} disabled={!password}>Sign in</button>
          <p className="bk-hint" style={{ textAlign: 'center', marginTop: 14 }}>Prototype access gate. Not real server-side authentication.</p>
        </form>
      </section>
    </div>
  );
};
