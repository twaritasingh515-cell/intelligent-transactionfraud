import React from 'react';
import { ArrowRight, Mail, Phone, ShieldCheck, UserRound } from 'lucide-react';
import { RiskAssessment, STATUS_RULES, isFrozen, lienHeld, pendingNotices } from '../../utils/bankSelectors';
import { ageFrom, fmtDate, fmtDateTime, inr, maskMobile } from '../../utils/bankFormat';
import { maskPan } from '../../data/bankingData';
import { Alert, Badge, Card, KV, KVGrid, RiskBadge, Stat, StatusBadge } from './ui';
import { CustomerCtx } from './context';

export const OverviewTab: React.FC<{ ctx: CustomerCtx; risk: RiskAssessment }> = ({ ctx, risk }) => {
  const { account, profile, customer, ledger, goTab } = ctx;
  const held = lienHeld(customer.notices, account.current_balance);
  const rules = STATUS_RULES[customer.status];
  const available = rules.debit ? Math.max(account.current_balance - held, 0) : 0;
  const pending = pendingNotices(customer.notices);
  const verified = customer.kyc.filter((d) => d.status === 'Verified').length;
  const reviewOverdue = new Date(profile.kyc_review_due).getTime() < Date.now();
  const recent = ledger.slice(0, 5);

  return (
    <div className="bk-stack">
      {isFrozen(customer.status) && (
        <Alert tone="danger">
          <b>{customer.status} is active.</b> {rules.summary}{' '}
          {customer.status_note && <>Applied under “{customer.status_note.category}”. </>}
          <button className="bk-btn is-link is-sm" onClick={() => goTab('status')}>Open account status <ArrowRight size={13} /></button>
        </Alert>
      )}
      {pending.length > 0 && (
        <Alert tone="warning">
          <b>{pending.length} LEA notice{pending.length > 1 ? 's' : ''} waiting for action.</b> Acknowledge and respond before the response date.{' '}
          <button className="bk-btn is-link is-sm" onClick={() => goTab('lea')}>Review notices <ArrowRight size={13} /></button>
        </Alert>
      )}

      <div className="bk-grid-4">
        <Stat label="Ledger balance" value={inr(account.current_balance)} />
        <Stat label="Lien / amount on hold" value={inr(held)} alert={held > 0} hint={held > 0 ? 'Held under LEA notices' : 'No hold on the account'} />
        <Stat label="Available for debit" value={inr(available)} hint={rules.debit ? 'After lien' : `Debits blocked (${customer.status})`} alert={!rules.debit} />
        <Stat label="KYC documents verified" value={`${verified} of ${customer.kyc.length}`} alert={verified < customer.kyc.length} hint={`Review due ${fmtDate(profile.kyc_review_due)}${reviewOverdue ? ' (overdue)' : ''}`} />
      </div>

      <div className="bk-grid-main">
        <div className="bk-stack">
          <Card title="Customer and account profile" subtitle="Core banking record for this relationship">
            <KVGrid>
              <KV label="Customer name">{account.name}</KV>
              <KV label="Segment · product">{profile.segment} · {profile.product}</KV>
              <KV label="Account number"><span className="bk-mono">{profile.account_number}</span></KV>
              <KV label="CIF ID"><span className="bk-mono">{profile.cif_id}</span></KV>
              <KV label="Branch">{profile.branch_name} ({profile.branch_code})</KV>
              <KV label="IFSC"><span className="bk-mono">{profile.ifsc}</span></KV>
              <KV label="Account opened">{fmtDate(profile.opened_on)} · {ageFrom(profile.opened_on)}</KV>
              <KV label="Occupation on KYC">{account.kyc_occupation}</KV>
              <KV label="PAN"><span className="bk-mono">{maskPan(profile.pan_full)}</span></KV>
              <KV label="Aadhaar"><span className="bk-mono">XXXX XXXX {profile.aadhaar_last4}</span></KV>
              <KV label="Registered mobile">{maskMobile(account.phone)}</KV>
              <KV label="Email">{profile.email}</KV>
              <KV label="Expected monthly credit">{inr(account.usual_monthly_credit_range[0])} – {inr(account.usual_monthly_credit_range[1])}</KV>
              <KV label="UPI handle">{account.upi_handle || '—'}</KV>
              <KV label="Registered address" wide>{profile.registered_address}</KV>
            </KVGrid>
          </Card>

          <Card title="Recent activity" subtitle="Latest five ledger entries"
            actions={<button className="bk-btn is-sm" onClick={() => goTab('transactions')}>Open ledger <ArrowRight size={13} /></button>} flush>
            <div className="bk-table-wrap">
              <table className="bk-table">
                <thead><tr><th>Date</th><th>Counterparty</th><th>Channel</th><th className="is-right">Amount</th></tr></thead>
                <tbody>
                  {recent.map((e) => {
                    const flagged = customer.flag_overrides[e.id] ?? e.suspicious;
                    return (
                      <tr key={e.id} className={flagged ? 'is-flagged' : ''}>
                        <td>{fmtDateTime(e.date)}</td>
                        <td>{e.counterparty}{flagged && <> <Badge tone="danger">Flagged</Badge></>}</td>
                        <td>{e.channel}</td>
                        <td className="is-right bk-num" style={{ color: e.type === 'Credit' ? 'var(--bk-success)' : undefined }}>
                          {e.type === 'Credit' ? '+' : '−'}{inr(e.amount)}
                        </td>
                      </tr>
                    );
                  })}
                  {!recent.length && <tr><td colSpan={4} className="bk-muted">No ledger entries yet.</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        <div className="bk-stack">
          <Card title="Risk rating" actions={<RiskBadge rating={risk.rating} />}>
            {risk.factors.length ? (
              <ul className="bk-list">
                {risk.factors.map((f) => <li key={f}>{f}</li>)}
              </ul>
            ) : <p className="bk-muted" style={{ margin: 0 }}>No risk factors on record.</p>}
            {account.notes && <p className="bk-small bk-muted" style={{ margin: '12px 0 0', paddingTop: 10, borderTop: '1px solid var(--bk-border)' }}>{account.notes}</p>}
          </Card>

          <Card title="Account status" actions={<StatusBadge status={customer.status} />}>
            <p className="bk-small" style={{ margin: 0 }}>{rules.summary}</p>
            {customer.status_note && (
              <p className="bk-small bk-muted" style={{ margin: '8px 0 0' }}>
                {customer.status_note.category} · {customer.status_note.by} · {fmtDateTime(customer.status_note.at)}
              </p>
            )}
          </Card>

          <Card title="Relationship manager" actions={<UserRound size={16} className="bk-muted" />}>
            <div className="bk-strong">{profile.relationship_manager.name}</div>
            <div className="bk-small bk-muted" style={{ marginBottom: 10 }}>{profile.relationship_manager.grade}</div>
            <div className="bk-stack" style={{ gap: 6 }}>
              <a className="bk-row bk-small" style={{ color: 'var(--bk-link)' }} href={`tel:${profile.relationship_manager.phone.replace(/\s/g, '')}`}><Phone size={14} /> {profile.relationship_manager.phone}</a>
              <a className="bk-row bk-small" style={{ color: 'var(--bk-link)' }} href={`mailto:${profile.relationship_manager.email}`}><Mail size={14} /> {profile.relationship_manager.email}</a>
            </div>
          </Card>

          <Card title="Compliance checks" actions={<ShieldCheck size={16} className="bk-muted" />}>
            <div className="bk-stack" style={{ gap: 8 }}>
              <div className="bk-spread"><span>KYC documents</span><Badge tone={verified === customer.kyc.length ? 'success' : 'warning'}>{verified}/{customer.kyc.length} verified</Badge></div>
              <div className="bk-spread"><span>Open LEA notices</span><Badge tone={customer.notices.some((n) => n.status !== 'Released') ? 'danger' : 'success'}>{customer.notices.filter((n) => n.status !== 'Released').length}</Badge></div>
              <div className="bk-spread"><span>Restricted channels</span><Badge tone={customer.channels.some((c) => !c.enabled) ? 'warning' : 'success'}>{customer.channels.filter((c) => !c.enabled).length} of {customer.channels.length}</Badge></div>
              <div className="bk-spread"><span>Open service requests</span><Badge tone="info">{customer.requests.filter((r) => !['Completed', 'Rejected', 'Delivered'].includes(r.status)).length}</Badge></div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
