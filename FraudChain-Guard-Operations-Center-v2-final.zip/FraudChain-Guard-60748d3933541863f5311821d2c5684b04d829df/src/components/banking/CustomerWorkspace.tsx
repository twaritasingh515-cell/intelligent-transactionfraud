import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Search } from 'lucide-react';
import { Account, Transaction } from '../../types';
import { BankState } from '../../types/banking';
import { BankActions } from '../../state/useBankState';
import { buildAllProfiles, generateRoutineEntries, buildLedger, maskPan } from '../../data/bankingData';
import { SearchMode, deriveRiskRating, isFrozen, pendingNotices, searchCustomers, statusSlug } from '../../utils/bankSelectors';
import { fmtDate, initials, inr } from '../../utils/bankFormat';
import { Badge, RiskBadge, StatusBadge } from './ui';
import { CustomerCtx, ToastFn, WorkspaceTab } from './context';
import { OverviewTab } from './OverviewTab';
import { KycTab } from './KycTab';
import { TransactionsTab } from './TransactionsTab';
import { ControlsTab } from './ControlsTab';
import { StatusTab } from './StatusTab';
import { ServiceRequestsTab } from './ServiceRequestsTab';
import { LeaTab } from './LeaTab';

const MODES: { id: SearchMode; label: string; hint: string }[] = [
  { id: 'all', label: 'Any', hint: 'Account no., CIF ID, PAN, mobile or name' },
  { id: 'account', label: 'Account number', hint: 'Enter at least 3 digits of the account number' },
  { id: 'cif', label: 'CIF ID', hint: 'For example CIF123456789' },
  { id: 'pan', label: 'PAN', hint: 'Ten-character PAN' },
  { id: 'mobile', label: 'Mobile', hint: 'Enter at least 4 digits of the mobile number' },
];

interface Props {
  accounts: Account[];
  transactions: Transaction[];
  bank: BankState;
  actions: BankActions;
  accountId: string;
  onSelectAccount: (id: string) => void;
  tab: WorkspaceTab;
  onTab: (t: WorkspaceTab) => void;
  onToast: ToastFn;
  onOpenTransaction: (txnId: string) => void;
  initialNoticeId?: string | null;
  onNoticeClosed?: () => void;
}

export const CustomerWorkspace: React.FC<Props> = ({
  accounts, transactions, bank, actions, accountId, onSelectAccount, tab, onTab, onToast, onOpenTransaction, initialNoticeId, onNoticeClosed,
}) => {
  const [q, setQ] = useState('');
  const [mode, setMode] = useState<SearchMode>('all');
  const [focused, setFocused] = useState(false);
  const [hot, setHot] = useState(0);
  const boxRef = useRef<HTMLDivElement>(null);

  const profiles = useMemo(() => buildAllProfiles(accounts), [accounts]);
  const accountsMap = useMemo(() => new Map(accounts.map((a) => [a.id, a])), [accounts]);
  const routine = useMemo(() => Object.fromEntries(accounts.map((a) => [a.id, generateRoutineEntries(a)])), [accounts]);

  const account = accountsMap.get(accountId) ?? accounts[0];
  const profile = profiles[account.id];
  const customer = bank[account.id];

  const ledger = useMemo(
    () => buildLedger(account.id, { accountsMap, profiles, transactions, routine }),
    [account.id, accountsMap, profiles, transactions, routine],
  );
  const risk = useMemo(() => deriveRiskRating(account, transactions, customer), [account, transactions, customer]);
  const hits = useMemo(() => searchCustomers(q, mode, accounts, profiles).slice(0, 6), [q, mode, accounts, profiles]);

  useEffect(() => setHot(0), [q, mode]);
  useEffect(() => {
    const away = (e: MouseEvent) => { if (boxRef.current && !boxRef.current.contains(e.target as Node)) setFocused(false); };
    document.addEventListener('mousedown', away);
    return () => document.removeEventListener('mousedown', away);
  }, []);

  const choose = (id: string) => { onSelectAccount(id); setQ(''); setFocused(false); onTab('overview'); };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setHot((h) => Math.min(h + 1, hits.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setHot((h) => Math.max(h - 1, 0)); }
    else if (e.key === 'Enter' && hits[hot]) { e.preventDefault(); choose(hits[hot].account.id); }
    else if (e.key === 'Escape') setFocused(false);
  };

  if (!customer || !profile) return null;

  const ctx: CustomerCtx = { account, profile, customer, ledger, transactions, actions, onToast, onOpenTransaction, goTab: onTab };
  const pendingLea = pendingNotices(customer.notices).length;
  const flagged = ledger.filter((e) => customer.flag_overrides[e.id] ?? e.suspicious).length;
  const pendingKyc = customer.kyc.filter((d) => d.status !== 'Verified').length;
  const restricted = customer.channels.filter((c) => !c.enabled).length;
  const openReq = customer.requests.filter((r) => !['Completed', 'Rejected', 'Delivered'].includes(r.status)).length;

  const tabs: { id: WorkspaceTab; label: string; count?: number; alert?: boolean }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'kyc', label: 'KYC documents', count: pendingKyc, alert: pendingKyc > 0 },
    { id: 'transactions', label: 'Transactions', count: flagged, alert: flagged > 0 },
    { id: 'controls', label: 'Payment controls', count: restricted },
    { id: 'status', label: 'Account status' },
    { id: 'requests', label: 'Service requests', count: openReq },
    { id: 'lea', label: 'LEA compliance', count: customer.notices.filter((n) => n.status !== 'Released').length, alert: pendingLea > 0 },
  ];

  const showResults = focused && q.trim().length >= 2;
  const hint = MODES.find((m) => m.id === mode)!.hint;

  return (
    <div className="bk-stack">
      <div ref={boxRef}>
        <div className="bk-row" style={{ marginBottom: 8 }} role="group" aria-label="Search by">
          {MODES.map((m) => <button key={m.id} className={`bk-chip ${mode === m.id ? 'is-active' : ''}`} aria-pressed={mode === m.id} onClick={() => setMode(m.id)}>{m.label}</button>)}
        </div>
        <div className="bk-search-box">
          <Search size={18} aria-hidden />
          <input value={q} onChange={(e) => { setQ(e.target.value); setFocused(true); }} onFocus={() => setFocused(true)} onKeyDown={onKey}
            placeholder="Look up a customer" aria-label="Customer lookup" aria-describedby="cust-hint" autoComplete="off" />
          {showResults && (
            <div className="bk-results" role="listbox">
              {hits.length ? hits.map((h, i) => (
                <button key={h.account.id} role="option" aria-selected={i === hot} className={`bk-result ${i === hot ? 'is-hot' : ''}`} onMouseEnter={() => setHot(i)} onClick={() => choose(h.account.id)}>
                  <span className="bk-avatar">{initials(h.account.name)}</span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <b>{h.account.name}</b>
                    <span className="bk-small bk-muted" style={{ display: 'block' }}>A/C <span className="bk-mono">{h.profile.account_number}</span> · {h.profile.cif_id} · {maskPan(h.profile.pan_full)}</span>
                  </span>
                  <Badge tone="navy">{h.matchedOn}</Badge>
                  <StatusBadge status={bank[h.account.id]?.status ?? 'Active'} />
                </button>
              )) : <div className="bk-result bk-muted" style={{ cursor: 'default' }}>No customer matches “{q.trim()}”. Check the digits or try another lookup type.</div>}
            </div>
          )}
        </div>
        <div id="cust-hint" className="bk-hint">{hint}. Press ↓ and Enter to open a result.</div>
      </div>

      <section className={`bk-card bk-cust is-${statusSlug(customer.status)}`}>
        <div className="bk-cust-avatar" aria-hidden>{initials(account.name)}</div>
        <div style={{ minWidth: 0 }}>
          <div className="bk-row"><h2>{account.name}</h2><StatusBadge status={customer.status} /><RiskBadge rating={risk.rating} /></div>
          <div className="bk-cust-meta">
            <span>A/C <b className="bk-mono">{profile.account_number}</b></span>
            <span>CIF <b className="bk-mono">{profile.cif_id}</b></span>
            <span>{profile.product}</span>
            <span>Opened <b>{fmtDate(profile.opened_on)}</b></span>
            <span>RM <b>{profile.relationship_manager.name}</b></span>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="bk-small bk-muted">Ledger balance</div>
          <div className="bk-num" style={{ fontSize: 22, fontWeight: 600, color: isFrozen(customer.status) ? 'var(--bk-danger)' : undefined }}>{inr(account.current_balance)}</div>
        </div>
      </section>

      <div>
        <div className="bk-tabs" role="tablist" aria-label="Customer sections">
          {tabs.map((t) => (
            <button key={t.id} role="tab" aria-selected={tab === t.id} className={`bk-tab ${tab === t.id ? 'is-active' : ''}`} onClick={() => onTab(t.id)}>
              {t.label}{!!t.count && <Badge tone={t.alert ? 'danger' : 'neutral'}>{t.count}</Badge>}
            </button>
          ))}
        </div>
        <div style={{ paddingTop: 16 }} role="tabpanel" key={`${account.id}-${tab}`} className="animate-fadeIn">
          {tab === 'overview' && <OverviewTab ctx={ctx} risk={risk} />}
          {tab === 'kyc' && <KycTab ctx={ctx} />}
          {tab === 'transactions' && <TransactionsTab ctx={ctx} />}
          {tab === 'controls' && <ControlsTab ctx={ctx} />}
          {tab === 'status' && <StatusTab ctx={ctx} />}
          {tab === 'requests' && <ServiceRequestsTab ctx={ctx} />}
          {tab === 'lea' && <LeaTab ctx={ctx} initialNoticeId={initialNoticeId} onNoticeClosed={onNoticeClosed} />}
        </div>
      </div>
    </div>
  );
};
