import React, { useMemo, useState } from 'react';
import { CheckCircle2, Fingerprint, FileText, Home, Plane, CreditCard, XCircle } from 'lucide-react';
import { KycDocType, KycDocument } from '../../types/banking';
import { fmtDate, fmtDateTime } from '../../utils/bankFormat';
import { Alert, Badge, Card, KycBadge, ReasonDialog, KV, KVGrid, EmptyState } from './ui';
import { CustomerCtx } from './context';

const ICONS: Record<KycDocType, React.ElementType> = { Aadhaar: Fingerprint, PAN: CreditCard, Passport: Plane, 'Address Proof': Home };
const REJECT_REASONS = [
  'Image is blurred or unreadable', 'Name does not match account title', 'Document belongs to a third party',
  'Suspected tampering or forgery', 'Document has expired', 'Incomplete or wrong document type',
];

function expiryNote(doc: KycDocument): { text: string; tone: 'danger' | 'warning' } | null {
  if (!doc.expires_on) return null;
  const days = Math.ceil((new Date(doc.expires_on).getTime() - Date.now()) / 86400000);
  if (days < 0) return { text: `Expired ${-days} day${days === -1 ? '' : 's'} ago`, tone: 'danger' };
  if (days <= 90) return { text: `Expires in ${days} day${days === 1 ? '' : 's'}`, tone: 'warning' };
  return null;
}

export const KycTab: React.FC<{ ctx: CustomerCtx }> = ({ ctx }) => {
  const { account, profile, customer, actions, onToast } = ctx;
  const [review, setReview] = useState<{ doc: KycDocument; decision: 'Verified' | 'Rejected' } | null>(null);
  const history = useMemo(() => customer.audit.filter((a) => a.category === 'KYC'), [customer.audit]);
  const counts = (s: KycDocument['status']) => customer.kyc.filter((d) => d.status === s).length;
  const outstanding = counts('Pending Verification') + counts('Rejected') + counts('Expired');

  const confirm = (category: string, reason: string) => {
    if (!review) return;
    actions.reviewKyc(account.id, review.doc.id, review.decision, reason, category || undefined);
    onToast(`${review.doc.type} ${review.decision === 'Verified' ? 'approved' : 'rejected'} for ${account.name}.`, review.decision === 'Verified' ? 'success' : 'alert');
    setReview(null);
  };

  return (
    <div className="bk-stack">
      <div className="bk-spread">
        <div className="bk-row">
          <Badge tone="success">{counts('Verified')} verified</Badge>
          <Badge tone="warning">{counts('Pending Verification')} pending</Badge>
          <Badge tone="danger">{counts('Rejected')} rejected</Badge>
          <Badge tone="neutral">{counts('Expired')} expired</Badge>
        </div>
        <span className="bk-small bk-muted">Periodic KYC review due {fmtDate(profile.kyc_review_due)}</span>
      </div>

      {outstanding > 0 && <Alert tone="warning"><b>{outstanding} document{outstanding > 1 ? 's need' : ' needs'} attention.</b> Review each one and record a decision with remarks.</Alert>}

      {!customer.kyc.length ? <Card><EmptyState title="No KYC documents on file" text="Collect the customer's identity and address proof at the branch." /></Card> : (
        <div className="bk-grid-2">
          {customer.kyc.map((doc) => {
            const Icon = ICONS[doc.type];
            const exp = expiryNote(doc);
            const canApprove = doc.status !== 'Verified' && doc.status !== 'Expired';
            const canReject = doc.status !== 'Rejected';
            return (
              <Card key={doc.id}
                title={<span className="bk-row"><Icon size={16} /> {doc.type}</span>}
                subtitle={doc.document_name}
                actions={<KycBadge status={doc.status} />}>
                <KVGrid>
                  <KV label="Document number"><span className="bk-mono">{doc.number_masked}</span></KV>
                  <KV label="Name on document">{doc.holder_name}</KV>
                  <KV label="Issued">{fmtDate(doc.issued_on)}</KV>
                  <KV label="Valid until">{doc.expires_on ? fmtDate(doc.expires_on) : 'No expiry'}</KV>
                  <KV label="Submitted">{fmtDate(doc.submitted_on)} via {doc.submitted_via}</KV>
                  <KV label="Last reviewed">{doc.reviewed_at ? `${fmtDateTime(doc.reviewed_at)}` : 'Not reviewed yet'}</KV>
                </KVGrid>
                {doc.reviewed_by && <p className="bk-small bk-muted" style={{ margin: '8px 0 0' }}>Reviewed by {doc.reviewed_by}</p>}
                {exp && <div style={{ marginTop: 10 }}><Badge tone={exp.tone}>{exp.text}</Badge></div>}
                {doc.remarks && (
                  <div className="bk-alert bk-alert-warning" style={{ marginTop: 12 }}><div><b>Remarks:</b> {doc.remarks}</div></div>
                )}
                <div className="bk-row" style={{ marginTop: 14 }}>
                  <button className="bk-btn is-success-ghost is-sm" disabled={!canApprove}
                    title={doc.status === 'Expired' ? 'Expired documents cannot be approved. Collect a fresh document.' : undefined}
                    onClick={() => setReview({ doc, decision: 'Verified' })}><CheckCircle2 size={14} /> {doc.status === 'Rejected' ? 'Re-verify' : 'Approve'}</button>
                  <button className="bk-btn is-danger-ghost is-sm" disabled={!canReject} onClick={() => setReview({ doc, decision: 'Rejected' })}>
                    <XCircle size={14} /> {doc.status === 'Verified' ? 'Revoke' : 'Reject'}
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Card title="KYC review history" subtitle="Every decision is recorded with the reviewer and remarks" flush>
        {history.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr><th>When</th><th>Reviewer</th><th>Action</th><th>Detail</th></tr></thead>
              <tbody>{history.map((h) => <tr key={h.id}><td className="bk-num" style={{ whiteSpace: 'nowrap' }}>{fmtDateTime(h.at)}</td><td>{h.actor}</td><td>{h.action}</td><td>{h.detail}</td></tr>)}</tbody>
            </table>
          </div>
        ) : <EmptyState icon={FileText} title="No decisions recorded in this session" text="Approvals and rejections you make here will appear in this log." />}
      </Card>

      <ReasonDialog
        open={!!review}
        tone={review?.decision === 'Rejected' ? 'danger' : 'primary'}
        title={review ? `${review.decision === 'Verified' ? 'Approve' : review.doc.status === 'Verified' ? 'Revoke' : 'Reject'} ${review.doc.type}` : ''}
        subtitle={review ? `${review.doc.document_name} · ${review.doc.number_masked}` : undefined}
        confirmLabel={review?.decision === 'Verified' ? 'Approve document' : 'Reject document'}
        categories={review?.decision === 'Rejected' ? REJECT_REASONS : undefined}
        categoryLabel="Rejection reason"
        reasonLabel="Remarks"
        reasonPlaceholder={review?.decision === 'Verified' ? 'Add a note on how the document was checked' : 'Tell the customer what to correct or resubmit'}
        minLength={review?.decision === 'Rejected' ? 10 : 0}
        onCancel={() => setReview(null)}
        onConfirm={(r) => confirm(r.category, r.reason)}
      />
    </div>
  );
};
