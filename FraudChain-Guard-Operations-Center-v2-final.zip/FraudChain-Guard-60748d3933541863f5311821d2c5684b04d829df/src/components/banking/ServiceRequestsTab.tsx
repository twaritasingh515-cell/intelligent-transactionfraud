import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen, Check, CheckCircle2, CreditCard, FileText, MapPin, PauseCircle, Phone, PlayCircle, Plus, Truck, UserPen, XCircle,
} from 'lucide-react';
import { ServiceRequest, ServiceRequestStatus, ServiceRequestType } from '../../types/banking';
import { isFrozen } from '../../utils/bankSelectors';
import { dueInfo, fmtDate, fmtDateTime } from '../../utils/bankFormat';
import { Alert, Badge, Card, EmptyState, KV, KVGrid, Modal, ReasonDialog, requestTone } from './ui';
import { CustomerCtx } from './context';

const TYPE_ICONS: Record<ServiceRequestType, React.ElementType> = {
  'Cheque Book Request': BookOpen, 'Debit Card Reissue': CreditCard, 'Statement Request': FileText,
  'Address Change': MapPin, 'Mobile Number Update': Phone, 'Nominee Update': UserPen,
};
const TYPES = Object.keys(TYPE_ICONS) as ServiceRequestType[];
const CHEQUE_STEPS: ServiceRequestStatus[] = ['Received', 'Address Verified', 'Approved', 'Dispatched', 'Delivered'];
const SIMPLE_STEPS: ServiceRequestStatus[] = ['Received', 'Approved', 'Completed'];
const COURIERS = ['BlueDart Express', 'DTDC', 'Delhivery', 'India Post Speed Post'];
const TRACK_PRESETS = ['In transit', 'Reached destination hub', 'Out for delivery', 'Delivery attempted, customer unavailable'];
const HOLD_REASONS = ['Awaiting customer documents', 'Address mismatch', 'Account is restricted', 'Under LEA review', 'Other'];
const REJECT_REASONS = ['Address could not be verified', 'Account not eligible', 'Customer withdrew the request', 'Duplicate request', 'Other'];
const TERMINAL: ServiceRequestStatus[] = ['Delivered', 'Completed', 'Rejected'];

const normalise = (s?: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

type Dialog = 'hold' | 'reject' | 'accept' | 'dispatch' | 'track' | 'new' | null;

export const ServiceRequestsTab: React.FC<{ ctx: CustomerCtx }> = ({ ctx }) => {
  const { account, profile, customer, actions, onToast } = ctx;
  const [selectedId, setSelectedId] = useState<string | null>(customer.requests[0]?.id ?? null);
  const [dialog, setDialog] = useState<Dialog>(null);

  const selected = customer.requests.find((r) => r.id === selectedId) ?? customer.requests[0] ?? null;
  useEffect(() => {
    if (!selectedId || !customer.requests.some((r) => r.id === selectedId)) setSelectedId(customer.requests[0]?.id ?? null);
  }, [customer.requests, selectedId]);

  const open = customer.requests.filter((r) => !TERMINAL.includes(r.status)).length;
  const isCheque = selected?.type === 'Cheque Book Request';
  const frozenBlock = isCheque && isFrozen(customer.status);

  const update = (patch: Partial<ServiceRequest>, event: { label: string; location?: string } | null, action: string, detail: string) => {
    if (!selected) return;
    actions.updateRequest(account.id, selected.id, patch, event, { action, detail });
  };

  const verifyAddress = () => {
    if (!selected) return;
    const match = normalise(selected.delivery_address) === normalise(profile.registered_address);
    if (match) {
      update({ status: 'Address Verified', address_check: 'Matches Registered Address' }, { label: 'Address verified against KYC' }, 'Delivery address verified', 'Delivery address matches the registered address.');
      onToast('Delivery address matches the registered address.', 'success');
    } else {
      update({ address_check: 'Mismatch' }, { label: 'Address check flagged a mismatch' }, 'Address mismatch found', 'Delivery address differs from the registered address.');
      onToast('Address mismatch found. Accept it with a reason, hold or reject the request.', 'alert');
    }
  };

  const steps = isCheque ? CHEQUE_STEPS : SIMPLE_STEPS;
  const stepIndex = selected ? (selected.status === 'Completed' && isCheque ? steps.length : steps.indexOf(selected.status)) : -1;
  const sla = selected && !TERMINAL.includes(selected.status) && selected.status !== 'On Hold' ? dueInfo(selected.sla_due) : null;

  const actionButtons = () => {
    if (!selected) return null;
    const s = selected.status;
    const btn = (label: string, icon: React.ReactNode, onClick: () => void, cls = '', disabled = false, title?: string) =>
      <button key={label} className={`bk-btn is-sm ${cls}`} onClick={onClick} disabled={disabled} title={title}>{icon}{label}</button>;
    const hold = btn('Put on hold', <PauseCircle size={14} />, () => setDialog('hold'));
    const reject = btn('Reject', <XCircle size={14} />, () => setDialog('reject'), 'is-danger-ghost');
    const freezeTip = frozenBlock ? `Not allowed while the account is under ${customer.status}` : undefined;

    if (s === 'Received') {
      if (isCheque) {
        return <>
          {selected.address_check === 'Mismatch'
            ? btn('Accept mismatched address', <Check size={14} />, () => setDialog('accept'), 'is-primary')
            : btn('Verify address', <MapPin size={14} />, verifyAddress, 'is-primary')}
          {hold}{reject}
        </>;
      }
      return <>{btn('Approve', <CheckCircle2 size={14} />, () => { update({ status: 'Approved' }, { label: 'Approved by branch operations' }, `${selected.type} approved`, 'Approved by branch operations.'); onToast('Request approved.', 'success'); }, 'is-primary')}{hold}{reject}</>;
    }
    if (s === 'Address Verified') {
      return <>{btn('Approve cheque book', <CheckCircle2 size={14} />, () => { update({ status: 'Approved' }, { label: 'Approved and sent for printing' }, 'Cheque book approved', 'Approved for printing and dispatch.'); onToast('Cheque book approved.', 'success'); }, 'is-primary', frozenBlock, freezeTip)}{hold}{reject}</>;
    }
    if (s === 'On Hold') {
      const resume = selected.address_check === 'Matches Registered Address' ? 'Address Verified' : 'Received';
      return <>{btn('Resume request', <PlayCircle size={14} />, () => { update({ status: resume }, { label: 'Hold released by operations' }, 'Request resumed', `Hold released; request returned to ${resume}.`); onToast('Request resumed.', 'info'); }, 'is-primary')}{reject}</>;
    }
    if (s === 'Approved') {
      if (isCheque) return <>{btn('Dispatch cheque book', <Truck size={14} />, () => setDialog('dispatch'), 'is-primary', frozenBlock, freezeTip)}{hold}</>;
      return btn('Mark completed', <CheckCircle2 size={14} />, () => { update({ status: 'Completed' }, { label: 'Request completed' }, `${selected.type} completed`, 'Marked completed.'); onToast('Request completed.', 'success'); }, 'is-primary');
    }
    if (s === 'Dispatched') {
      return <>
        {btn('Add tracking update', <Truck size={14} />, () => setDialog('track'))}
        {btn('Mark delivered', <CheckCircle2 size={14} />, () => { update({ status: 'Delivered' }, { label: 'Delivered to customer', location: selected.delivery_address }, 'Cheque book delivered', 'Delivery confirmed.'); onToast('Cheque book marked as delivered.', 'success'); }, 'is-primary')}
      </>;
    }
    return <span className="bk-small bk-muted">This request is closed.</span>;
  };

  return (
    <div className="bk-grid-split">
      <div className="bk-stack" style={{ gap: 10 }}>
        <div className="bk-spread">
          <span className="bk-small bk-muted">{customer.requests.length} request{customer.requests.length === 1 ? '' : 's'} · {open} open</span>
          <button className="bk-btn is-primary is-sm" onClick={() => setDialog('new')}><Plus size={14} /> New request</button>
        </div>
        {customer.requests.length ? customer.requests.map((r) => {
          const Icon = TYPE_ICONS[r.type];
          const due = !TERMINAL.includes(r.status) && r.status !== 'On Hold' ? dueInfo(r.sla_due) : null;
          return (
            <button key={r.id} className={`bk-req ${selected?.id === r.id ? 'is-active' : ''}`} onClick={() => setSelectedId(r.id)} aria-pressed={selected?.id === r.id}>
              <div className="bk-spread" style={{ flexWrap: 'nowrap' }}>
                <span className="bk-row" style={{ flexWrap: 'nowrap' }}><Icon size={15} /><b>{r.type}</b></span>
                <Badge tone={requestTone(r.status)}>{r.status}</Badge>
              </div>
              <div className="bk-small bk-muted"><span className="bk-mono">{r.id}</span> · {fmtDate(r.raised_at)} · {r.raised_via}</div>
              {due && <div className="bk-small" style={{ color: due.overdue ? 'var(--bk-danger)' : due.soon ? 'var(--bk-warning)' : 'var(--bk-muted)' }}>{due.text}</div>}
            </button>
          );
        }) : <Card><EmptyState title="No service requests" text="Raise a cheque book, card reissue or statement request for this customer." /></Card>}
      </div>

      {selected ? (
        <div className="bk-stack">
          <Card title={<span className="bk-row">{React.createElement(TYPE_ICONS[selected.type], { size: 16 })} {selected.type}</span>}
            subtitle={<><span className="bk-mono">{selected.id}</span> · raised {fmtDateTime(selected.raised_at)} via {selected.raised_via}</>}
            actions={<Badge tone={requestTone(selected.status)}>{selected.status}</Badge>}>
            <p style={{ margin: '0 0 14px' }}>{selected.details}</p>

            {(selected.status === 'On Hold' || selected.status === 'Rejected') ? (
              <Alert tone={selected.status === 'Rejected' ? 'danger' : 'warning'}>
                <b>{selected.status === 'Rejected' ? 'Request rejected.' : 'Request on hold.'}</b> {selected.remarks || 'No remarks recorded.'}
              </Alert>
            ) : (
              <ol className="bk-stepper" aria-label="Request progress">
                {steps.map((step, i) => (
                  <li key={step} className={i < stepIndex ? 'is-done' : i === stepIndex ? 'is-current' : ''} aria-current={i === stepIndex ? 'step' : undefined}>
                    <i>{i < stepIndex || (i === stepIndex && TERMINAL.includes(selected.status)) ? <Check size={13} /> : null}</i>{step}
                  </li>
                ))}
              </ol>
            )}

            {frozenBlock && !TERMINAL.includes(selected.status) && (
              <div style={{ marginTop: 14 }}><Alert tone="danger"><b>Account is under {customer.status}.</b> Approval and dispatch of a cheque book are blocked until the freeze is lifted. You can still hold or reject the request.</Alert></div>
            )}
            {sla && <p className="bk-small" style={{ margin: '14px 0 0', color: sla.overdue ? 'var(--bk-danger)' : 'var(--bk-muted)' }}>Service level: {sla.text} (due {fmtDateTime(selected.sla_due)})</p>}
            <div className="bk-row" style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--bk-border)' }}>{actionButtons()}</div>
          </Card>

          {isCheque && (
            <div className="bk-grid-2">
              <Card title="Address verification" actions={
                <Badge tone={selected.address_check === 'Matches Registered Address' ? 'success' : selected.address_check === 'Mismatch' ? 'danger' : 'warning'}>
                  {selected.address_check === 'Matches Registered Address' ? 'Matches KYC address' : selected.address_check === 'Mismatch' ? 'Mismatch' : 'Not checked'}
                </Badge>}>
                <div className="bk-stack" style={{ gap: 10 }}>
                  <div className="bk-addr"><small>Registered address (KYC)</small>{profile.registered_address}</div>
                  <div className="bk-addr" style={selected.address_check === 'Mismatch' ? { borderColor: 'var(--bk-danger)' } : undefined}><small>Delivery address requested</small>{selected.delivery_address || '—'}</div>
                  {selected.address_check === 'Mismatch' && selected.status !== 'Address Verified' && selected.status !== 'Approved' && selected.status !== 'Dispatched' && selected.status !== 'Delivered' && (
                    <p className="bk-small bk-muted" style={{ margin: 0 }}>Delivery to a different address needs a written reason from the employee before approval.</p>
                  )}
                  {selected.address_check === 'Mismatch' && ['Address Verified', 'Approved', 'Dispatched', 'Delivered'].includes(selected.status) && (
                    <p className="bk-small" style={{ margin: 0, color: 'var(--bk-warning)' }}>Mismatched address was accepted by an employee. See the tracking log for the reason.</p>
                  )}
                </div>
              </Card>
              <Card title="Cheque book and delivery">
                <KVGrid>
                  <KV label="Leaves">{selected.leaves ?? '—'}</KV>
                  <KV label="Courier">{selected.courier || 'Not assigned'}</KV>
                  <KV label="Tracking ID"><span className="bk-mono">{selected.tracking_id || '—'}</span></KV>
                  <KV label="Expected delivery">{selected.expected_delivery ? fmtDate(selected.expected_delivery) : '—'}</KV>
                </KVGrid>
              </Card>
            </div>
          )}

          <Card title="Tracking log" subtitle="Every step, in the order it happened">
            <ul className="bk-timeline">
              {selected.tracking.map((t, i) => (
                <li key={`${t.at}-${i}`} className={i === selected.tracking.length - 1 ? 'is-current' : ''}>
                  <b>{t.label}</b>
                  <small>{fmtDateTime(t.at)}{t.location ? ` · ${t.location}` : ''}</small>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      ) : (
        <Card><EmptyState title="Select a request" text="Choose a request on the left to see its status, verification and tracking." /></Card>
      )}

      <ReasonDialog open={dialog === 'hold'} title="Put request on hold" subtitle={selected?.id} confirmLabel="Put on hold" categories={HOLD_REASONS}
        minLength={10} reasonPlaceholder="What is needed before this request can move forward?" onCancel={() => setDialog(null)}
        onConfirm={(r) => { update({ status: 'On Hold', remarks: `${r.category}: ${r.reason}` }, { label: 'Placed on hold by operations' }, 'Request put on hold', `${r.category}: ${r.reason}`); onToast('Request put on hold.', 'info'); setDialog(null); }} />
      <ReasonDialog open={dialog === 'reject'} tone="danger" title="Reject request" subtitle={selected?.id} confirmLabel="Reject request" categories={REJECT_REASONS}
        minLength={10} reasonPlaceholder="This reason is shared with the customer" onCancel={() => setDialog(null)}
        onConfirm={(r) => { update({ status: 'Rejected', remarks: `${r.category}: ${r.reason}` }, { label: 'Rejected by operations' }, 'Request rejected', `${r.category}: ${r.reason}`); onToast('Request rejected.', 'alert'); setDialog(null); }} />
      <ReasonDialog open={dialog === 'accept'} title="Accept mismatched delivery address" subtitle={selected?.id} confirmLabel="Accept address" minLength={15}
        reasonLabel="Why is this address acceptable?" reasonPlaceholder="For example: customer showed employer letter with the new address at the branch"
        ackLabel="I have checked supporting proof for the delivery address." onCancel={() => setDialog(null)}
        onConfirm={(r) => { update({ status: 'Address Verified' }, { label: 'Mismatch accepted by employee' }, 'Mismatched address accepted', r.reason); onToast('Address accepted with reason.', 'info'); setDialog(null); }} />

      {selected && <DispatchDialog open={dialog === 'dispatch'} hubName={profile.branch_name} onCancel={() => setDialog(null)}
        onConfirm={(courier, trackingId, expected) => {
          update({ status: 'Dispatched', courier, tracking_id: trackingId, expected_delivery: expected }, { label: `Dispatched via ${courier}`, location: profile.branch_name }, 'Cheque book dispatched', `${courier}, tracking ${trackingId}.`);
          onToast(`Dispatched via ${courier}. Tracking ${trackingId}.`, 'success'); setDialog(null);
        }} />}
      <TrackDialog open={dialog === 'track'} onCancel={() => setDialog(null)}
        onConfirm={(label, location) => { update({}, { label, location: location || undefined }, 'Tracking updated', label); onToast('Tracking log updated.', 'info'); setDialog(null); }} />
      <NewRequestDialog open={dialog === 'new'} registeredAddress={profile.registered_address} onCancel={() => setDialog(null)}
        onCreate={(input) => { const id = actions.createRequest(account.id, input); setSelectedId(id); onToast(`${input.type} raised (${id}).`, 'success'); setDialog(null); }} />
    </div>
  );
};

/* ------------------------------ Dialogs ------------------------------ */

const DispatchDialog: React.FC<{ open: boolean; hubName: string; onCancel: () => void; onConfirm: (courier: string, trackingId: string, expected: string) => void }> = ({ open, hubName, onCancel, onConfirm }) => {
  const [courier, setCourier] = useState(COURIERS[0]);
  const trackingId = useMemo(() => `${courier.slice(0, 2).toUpperCase()}${Math.floor(1e9 + Math.random() * 9e9)}`, [courier, open]); // eslint-disable-line react-hooks/exhaustive-deps
  const expected = useMemo(() => new Date(Date.now() + 4 * 86400000).toISOString(), [open]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Modal open={open} size="sm" title="Dispatch cheque book" subtitle={`From ${hubName}`} onClose={onCancel}
      footer={<><button className="bk-btn" onClick={onCancel}>Cancel</button><button className="bk-btn is-primary" onClick={() => onConfirm(courier, trackingId, expected)}>Confirm dispatch</button></>}>
      <div className="bk-stack" style={{ gap: 14 }}>
        <div><label className="bk-label" htmlFor="dp-courier">Courier partner</label>
          <select id="dp-courier" className="bk-select" value={courier} onChange={(e) => setCourier(e.target.value)}>{COURIERS.map((c) => <option key={c}>{c}</option>)}</select></div>
        <KVGrid><KV label="Tracking ID (generated)"><span className="bk-mono">{trackingId}</span></KV><KV label="Expected delivery">{fmtDate(expected)}</KV></KVGrid>
      </div>
    </Modal>
  );
};

const TrackDialog: React.FC<{ open: boolean; onCancel: () => void; onConfirm: (label: string, location: string) => void }> = ({ open, onCancel, onConfirm }) => {
  const [label, setLabel] = useState(TRACK_PRESETS[0]);
  const [location, setLocation] = useState('');
  useEffect(() => { if (open) { setLabel(TRACK_PRESETS[0]); setLocation(''); } }, [open]);
  return (
    <Modal open={open} size="sm" title="Add tracking update" onClose={onCancel}
      footer={<><button className="bk-btn" onClick={onCancel}>Cancel</button><button className="bk-btn is-primary" onClick={() => onConfirm(label, location.trim())}>Add update</button></>}>
      <div className="bk-stack" style={{ gap: 14 }}>
        <div><label className="bk-label" htmlFor="tr-label">Status</label>
          <select id="tr-label" className="bk-select" value={label} onChange={(e) => setLabel(e.target.value)}>{TRACK_PRESETS.map((p) => <option key={p}>{p}</option>)}</select></div>
        <div><label className="bk-label" htmlFor="tr-loc">Location (optional)</label>
          <input id="tr-loc" className="bk-input" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City or hub" /></div>
      </div>
    </Modal>
  );
};

const NewRequestDialog: React.FC<{
  open: boolean; registeredAddress: string; onCancel: () => void;
  onCreate: (input: { type: ServiceRequestType; details: string; leaves?: 25 | 50 | 100; delivery_address?: string }) => void;
}> = ({ open, registeredAddress, onCancel, onCreate }) => {
  const [type, setType] = useState<ServiceRequestType>('Cheque Book Request');
  const [details, setDetails] = useState('');
  const [leaves, setLeaves] = useState<25 | 50 | 100>(25);
  const [address, setAddress] = useState(registeredAddress);
  useEffect(() => { if (open) { setType('Cheque Book Request'); setDetails(''); setLeaves(25); setAddress(registeredAddress); } }, [open, registeredAddress]);
  const cheque = type === 'Cheque Book Request';
  const valid = details.trim().length >= 10 && (!cheque || address.trim().length >= 8);
  return (
    <Modal open={open} title="Raise a service request" subtitle="Created at the branch on behalf of the customer" onClose={onCancel}
      footer={<><button className="bk-btn" onClick={onCancel}>Cancel</button>
        <button className="bk-btn is-primary" disabled={!valid} onClick={() => onCreate({ type, details: details.trim(), ...(cheque ? { leaves, delivery_address: address.trim() } : {}) })}>Raise request</button></>}>
      <div className="bk-stack" style={{ gap: 14 }}>
        <div><label className="bk-label" htmlFor="nr-type">Request type</label>
          <select id="nr-type" className="bk-select" value={type} onChange={(e) => setType(e.target.value as ServiceRequestType)}>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></div>
        {cheque && (
          <div className="bk-grid-2">
            <div><label className="bk-label" htmlFor="nr-leaves">Number of leaves</label>
              <select id="nr-leaves" className="bk-select" value={leaves} onChange={(e) => setLeaves(Number(e.target.value) as 25 | 50 | 100)}><option value={25}>25</option><option value={50}>50</option><option value={100}>100</option></select></div>
            <div style={{ gridColumn: '1 / -1' }}><label className="bk-label" htmlFor="nr-addr">Delivery address</label>
              <textarea id="nr-addr" className="bk-textarea" style={{ minHeight: 64 }} value={address} onChange={(e) => setAddress(e.target.value)} />
              <div className="bk-hint">Defaults to the registered address. A different address is checked before approval.</div></div>
          </div>
        )}
        <div><label className="bk-label" htmlFor="nr-details">Details</label>
          <textarea id="nr-details" className="bk-textarea" value={details} onChange={(e) => setDetails(e.target.value)} placeholder="What did the customer ask for?" />
          <div className="bk-hint">{details.trim().length < 10 ? 'At least 10 characters.' : 'Ready to raise.'}</div></div>
      </div>
    </Modal>
  );
};
