import React, { useMemo, useState } from 'react';
import { Eye, ShieldCheck } from 'lucide-react';
import { LeaNotice } from '../../types/banking';
import { lienHeld, openNotices, pendingNotices } from '../../utils/bankSelectors';
import { dueInfo, fmtDateTime, inr } from '../../utils/bankFormat';
import { Alert, Badge, Card, EmptyState, Stat, noticeTone } from './ui';
import { LeaNoticeModal } from './LeaNoticeModal';
import { CustomerCtx } from './context';

export const LeaTab: React.FC<{ ctx: CustomerCtx; initialNoticeId?: string | null; onNoticeClosed?: () => void }> = ({ ctx, initialNoticeId, onNoticeClosed }) => {
  const { account, customer } = ctx;
  const [openId, setOpenId] = useState<string | null>(initialNoticeId ?? null);
  const notices = useMemo(() => [...customer.notices].sort((a, b) => new Date(b.received_at).getTime() - new Date(a.received_at).getTime()), [customer.notices]);
  const active = openNotices(customer.notices);
  const pending = pendingNotices(customer.notices);
  const held = lienHeld(customer.notices, account.current_balance);
  const next = useMemo(() => {
    const dates = active.map((n) => n.response_due).sort();
    return dates.length ? dueInfo(dates[0]) : null;
  }, [active]);
  const current: LeaNotice | null = notices.find((n) => n.id === openId) ?? null;

  return (
    <div className="bk-stack">
      <div className="bk-grid-4">
        <Stat label="Active LEA notices" value={active.length} alert={active.length > 0} hint={`${notices.length} received in total`} />
        <Stat label="Waiting for action" value={pending.length} alert={pending.length > 0} hint={pending.length ? 'Acknowledge or apply the action' : 'Everything is handled'} />
        <Stat label="Amount under lien / frozen" value={inr(held)} alert={held > 0} hint="Capped at the current balance" />
        <Stat label="Next response date" value={next ? next.text : '—'} alert={!!next?.overdue} hint={next ? 'Earliest open notice' : 'No open notices'} />
      </div>

      {pending.length > 0 && <Alert tone="danger"><b>{pending.length} notice{pending.length > 1 ? 's need' : ' needs'} action.</b> Do not disclose notice contents to the account holder beyond what the law requires.</Alert>}

      <Card title="LEA notices and cyber cell complaints" subtitle={`Complaints received against ${account.name} from cyber cells, police and courts`} flush>
        {notices.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr><th>Complaint ID</th><th>Agency</th><th>Nature</th><th>Action required</th><th className="is-right">Lien / frozen</th><th>Received</th><th>Response due</th><th>Status</th><th><span className="sr-only">Open</span></th></tr></thead>
              <tbody>
                {notices.map((n) => {
                  const due = n.status === 'Released' ? null : dueInfo(n.response_due);
                  return (
                    <tr key={n.id} className={`is-clickable ${n.status === 'New' ? 'is-flagged' : ''}`} onClick={() => setOpenId(n.id)}>
                      <td><span className="bk-mono bk-strong">{n.complaint_ref}</span></td>
                      <td className="is-agency">{n.agency}<div className="bk-small bk-muted">{n.agency_type}</div></td>
                      <td><Badge tone="danger">{n.nature}</Badge></td>
                      <td>{n.action}</td>
                      <td className="is-right bk-num">{n.action === 'Information Request' ? '—' : inr(n.lien_amount)}</td>
                      <td style={{ whiteSpace: 'nowrap' }} className="bk-num">{fmtDateTime(n.received_at)}</td>
                      <td style={{ whiteSpace: 'nowrap', color: due?.overdue ? 'var(--bk-danger)' : undefined }}>{due ? due.text : '—'}</td>
                      <td><Badge tone={noticeTone(n.status)} dot>{n.status}</Badge></td>
                      <td><button className="bk-btn is-sm" onClick={(e) => { e.stopPropagation(); setOpenId(n.id); }}><Eye size={13} /> View</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : <EmptyState icon={ShieldCheck} title="No LEA notices on this account" text="Notices from cyber cells, police or courts will be listed here with their documents." />}
      </Card>

      {notices.length > 0 && active.length === 0 && (
        <Alert tone="success">All notices on this account have been released.</Alert>
      )}

      {current && <LeaNoticeModal ctx={ctx} notice={current} onClose={() => { setOpenId(null); onNoticeClosed?.(); }} />}
    </div>
  );
};
