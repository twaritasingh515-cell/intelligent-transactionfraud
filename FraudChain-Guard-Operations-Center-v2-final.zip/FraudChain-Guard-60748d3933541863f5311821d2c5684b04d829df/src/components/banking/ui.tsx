import React, { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle, CalendarX, CheckCircle2, Clock, Info, Inbox, ShieldAlert, X, XCircle,
} from 'lucide-react';
import {
  AccountStatus, KycStatus, LeaNoticeStatus, LedgerStatus, RiskRating, ServiceRequestStatus,
} from '../../types/banking';

/* -------------------------------------------------------------------------- */
/* Badges                                                                     */
/* -------------------------------------------------------------------------- */

export type Tone = 'success' | 'danger' | 'warning' | 'info' | 'neutral' | 'navy';

export const Badge: React.FC<{
  tone?: Tone; dot?: boolean; solid?: boolean; icon?: React.ElementType; title?: string; children: React.ReactNode;
}> = ({ tone = 'neutral', dot, solid, icon: Icon, title, children }) => (
  <span className={`bk-badge bk-badge-${tone} ${solid ? 'bk-badge-solid-danger' : ''}`} title={title}>
    {dot && <i className="bk-dot" aria-hidden />}
    {Icon && <Icon size={12} aria-hidden />}
    {children}
  </span>
);

export const kycTone = (s: KycStatus): Tone =>
  s === 'Verified' ? 'success' : s === 'Pending Verification' ? 'warning' : s === 'Rejected' ? 'danger' : 'neutral';

export const KycBadge: React.FC<{ status: KycStatus }> = ({ status }) => {
  const icon = status === 'Verified' ? CheckCircle2 : status === 'Pending Verification' ? Clock : status === 'Rejected' ? XCircle : CalendarX;
  return <Badge tone={kycTone(status)} icon={icon}>{status}</Badge>;
};

export const StatusBadge: React.FC<{ status: AccountStatus }> = ({ status }) => (
  <Badge tone={status === 'Active' ? 'success' : status === 'Dormant' ? 'warning' : 'danger'} dot solid={status === 'Total Freeze'}>
    {status}
  </Badge>
);

export const RiskBadge: React.FC<{ rating: RiskRating }> = ({ rating }) => (
  <Badge tone={rating === 'Low' ? 'success' : rating === 'Medium' ? 'warning' : 'danger'}>{rating} risk</Badge>
);

export const ledgerTone = (s: LedgerStatus): Tone =>
  s === 'Success' ? 'success' : s === 'Pending' || s === 'On Hold' ? 'warning' : s === 'Failed' ? 'danger' : 'info';

export const requestTone = (s: ServiceRequestStatus): Tone =>
  s === 'Completed' || s === 'Delivered' ? 'success' : s === 'Rejected' ? 'danger' : s === 'On Hold' ? 'warning'
    : s === 'Approved' || s === 'Dispatched' ? 'navy' : 'info';

export const noticeTone = (s: LeaNoticeStatus): Tone =>
  s === 'New' ? 'danger' : s === 'Acknowledged' ? 'warning' : s === 'Action Applied' ? 'navy' : 'success';

/* -------------------------------------------------------------------------- */
/* Layout helpers                                                             */
/* -------------------------------------------------------------------------- */

export const Card: React.FC<{
  title?: React.ReactNode; subtitle?: React.ReactNode; actions?: React.ReactNode; flush?: boolean; className?: string; children: React.ReactNode;
}> = ({ title, subtitle, actions, flush, className = '', children }) => (
  <section className={`bk-card ${className}`}>
    {(title || actions) && (
      <header className="bk-card-head">
        <div>{title && <h3>{title}</h3>}{subtitle && <p>{subtitle}</p>}</div>
        {actions && <div className="bk-row">{actions}</div>}
      </header>
    )}
    {flush ? children : <div className="bk-card-body">{children}</div>}
  </section>
);

export const KVGrid: React.FC<{ children: React.ReactNode }> = ({ children }) => <dl className="bk-kv-grid">{children}</dl>;

export const KV: React.FC<{ label: string; wide?: boolean; children: React.ReactNode }> = ({ label, wide, children }) => (
  <div className={`bk-kv ${wide ? 'is-wide' : ''}`}><dt>{label}</dt><dd>{children}</dd></div>
);

export const Stat: React.FC<{ label: string; value: React.ReactNode; hint?: React.ReactNode; alert?: boolean }> = ({ label, value, hint, alert }) => (
  <div className={`bk-stat ${alert ? 'is-alert' : ''}`}><small>{label}</small><b>{value}</b>{hint && <span>{hint}</span>}</div>
);

export const Alert: React.FC<{ tone?: 'info' | 'warning' | 'danger' | 'success'; children: React.ReactNode }> = ({ tone = 'info', children }) => {
  const Icon = tone === 'danger' ? ShieldAlert : tone === 'warning' ? AlertTriangle : tone === 'success' ? CheckCircle2 : Info;
  return <div className={`bk-alert bk-alert-${tone}`} role={tone === 'danger' ? 'alert' : 'status'}><Icon size={16} aria-hidden /><div>{children}</div></div>;
};

export const EmptyState: React.FC<{ title: string; text?: string; icon?: React.ElementType; action?: React.ReactNode }> = ({ title, text, icon: Icon = Inbox, action }) => (
  <div style={{ textAlign: 'center', padding: '36px 20px' }}>
    <Icon size={28} className="bk-muted" style={{ margin: '0 auto 10px' }} aria-hidden />
    <div className="bk-strong">{title}</div>
    {text && <p className="bk-muted bk-small" style={{ margin: '4px auto 0', maxWidth: 420 }}>{text}</p>}
    {action && <div style={{ marginTop: 14 }}>{action}</div>}
  </div>
);

export const Switch: React.FC<{ checked: boolean; onChange: (next: boolean) => void; label: string; disabled?: boolean }> = ({ checked, onChange, label, disabled }) => (
  <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled}
    className={`bk-switch ${checked ? 'is-on' : ''}`} onClick={() => onChange(!checked)}>
    <span />
  </button>
);

/* -------------------------------------------------------------------------- */
/* Modal                                                                      */
/* -------------------------------------------------------------------------- */

const modalStack: string[] = [];
const FOCUSABLE = 'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';

export const Modal: React.FC<{
  open: boolean; title: string; subtitle?: React.ReactNode; onClose: () => void;
  size?: 'sm' | 'md' | 'lg' | 'xl'; tone?: 'default' | 'danger'; dismissible?: boolean;
  footer?: React.ReactNode; children: React.ReactNode;
}> = ({ open, title, subtitle, onClose, size = 'md', tone = 'default', dismissible = true, footer, children }) => {
  const id = useId();
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    modalStack.push(id);
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    if (ref.current && !ref.current.contains(document.activeElement)) ref.current.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissible && modalStack[modalStack.length - 1] === id) {
        e.stopPropagation();
        closeRef.current();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      const at = modalStack.indexOf(id);
      if (at >= 0) modalStack.splice(at, 1);
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus?.();
    };
  }, [open, id, dismissible]);

  if (!open) return null;

  const trapTab = (e: React.KeyboardEvent) => {
    if (e.key !== 'Tab' || !ref.current || !ref.current.contains(e.target as Node)) return;
    const nodes = ref.current.querySelectorAll<HTMLElement>(FOCUSABLE);
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };

  const host = (document.querySelector('.app-shell') as HTMLElement | null) || document.body;

  return createPortal(
    <div className="bk-overlay" onMouseDown={(e) => { if (dismissible && e.target === e.currentTarget) onClose(); }}>
      <div ref={ref} className={`bk-modal is-${size} ${tone === 'danger' ? 'is-danger' : ''}`} role="dialog" aria-modal="true"
        aria-labelledby={`${id}-title`} tabIndex={-1} onKeyDown={trapTab}>
        <header className="bk-modal-head">
          <div style={{ minWidth: 0 }}>
            <h2 id={`${id}-title`}>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          {dismissible && <button type="button" className="bk-icon-btn" onClick={onClose} aria-label="Close dialog"><X size={18} /></button>}
        </header>
        <div className="bk-modal-body">{children}</div>
        {footer && <footer className="bk-modal-foot">{footer}</footer>}
      </div>
    </div>,
    host,
  );
};

/* -------------------------------------------------------------------------- */
/* Mandatory-reason dialog: every sensitive action is captured for the audit  */
/* -------------------------------------------------------------------------- */

export interface ReasonResult { category: string; reason: string; reference: string; option: boolean }

export const ReasonDialog: React.FC<{
  open: boolean; title: string; subtitle?: React.ReactNode; description?: React.ReactNode;
  tone?: 'primary' | 'danger'; confirmLabel: string;
  categoryLabel?: string; categories?: string[];
  reasonLabel?: string; reasonPlaceholder?: string; minLength?: number;
  refLabel?: string; refPlaceholder?: string; refRequired?: boolean;
  ackLabel?: string; optionLabel?: string; optionDefault?: boolean;
  onCancel: () => void; onConfirm: (result: ReasonResult) => void;
  children?: React.ReactNode;
}> = ({
  open, title, subtitle, description, tone = 'primary', confirmLabel, categoryLabel = 'Reason category', categories,
  reasonLabel = 'Reason for audit trail', reasonPlaceholder = 'Describe why this action is being taken', minLength = 0,
  refLabel, refPlaceholder, refRequired, ackLabel, optionLabel, optionDefault, onCancel, onConfirm, children,
}) => {
  const [category, setCategory] = useState('');
  const [reason, setReason] = useState('');
  const [reference, setReference] = useState('');
  const [ack, setAck] = useState(false);
  const [option, setOption] = useState(!!optionDefault);

  useEffect(() => {
    if (!open) return;
    setCategory(''); setReason(''); setReference(''); setAck(false); setOption(!!optionDefault);
  }, [open, optionDefault]);

  const chars = reason.trim().length;
  const valid =
    (!categories || category !== '') &&
    chars >= minLength &&
    (!refLabel || !refRequired || reference.trim().length >= 3) &&
    (!ackLabel || ack);

  const submit = () => {
    if (!valid) return;
    onConfirm({ category, reason: reason.trim(), reference: reference.trim(), option });
  };

  return (
    <Modal open={open} title={title} subtitle={subtitle} onClose={onCancel} size="md" tone={tone === 'danger' ? 'danger' : 'default'}
      footer={<>
        <button type="button" className="bk-btn" onClick={onCancel}>Cancel</button>
        <button type="button" className={`bk-btn ${tone === 'danger' ? 'is-danger' : 'is-primary'}`} disabled={!valid} onClick={submit}>{confirmLabel}</button>
      </>}>
      <div className="bk-stack" style={{ gap: 14 }}>
        {description && <div className="bk-small">{description}</div>}
        {children}
        {categories && (
          <div>
            <label className="bk-label" htmlFor="rd-category">{categoryLabel}</label>
            <select id="rd-category" className="bk-select" value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="">Select a category</option>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        )}
        {refLabel && (
          <div>
            <label className="bk-label" htmlFor="rd-ref">{refLabel}{refRequired ? '' : ' (optional)'}</label>
            <input id="rd-ref" className="bk-input" value={reference} onChange={(e) => setReference(e.target.value)} placeholder={refPlaceholder} />
          </div>
        )}
        <div>
          <label className="bk-label" htmlFor="rd-reason">{reasonLabel}{minLength === 0 ? ' (optional)' : ''}</label>
          <textarea id="rd-reason" className="bk-textarea" value={reason} onChange={(e) => setReason(e.target.value)} placeholder={reasonPlaceholder} />
          {minLength > 0 && (
            <div className="bk-hint" style={{ color: chars >= minLength ? 'var(--bk-success)' : undefined }}>
              {chars >= minLength ? 'Reason recorded for audit.' : `${minLength - chars} more character${minLength - chars === 1 ? '' : 's'} needed. This text is written to the audit trail.`}
            </div>
          )}
        </div>
        {optionLabel && (
          <label className="bk-check"><input type="checkbox" checked={option} onChange={(e) => setOption(e.target.checked)} /><span>{optionLabel}</span></label>
        )}
        {ackLabel && (
          <label className="bk-check"><input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} /><span>{ackLabel}</span></label>
        )}
      </div>
    </Modal>
  );
};
