import React, { useMemo, useState } from 'react';
import { ArrowLeftRight, Banknote, CreditCard, Globe, Lock, ShieldCheck, ShieldOff, Smartphone, MonitorSmartphone } from 'lucide-react';
import { PaymentChannelId } from '../../types/banking';
import { CHANNEL_META, CHANNEL_ORDER } from '../../data/bankingData';
import { STATUS_RULES } from '../../utils/bankSelectors';
import { fmtDateTime } from '../../utils/bankFormat';
import { Alert, Badge, Card, EmptyState, ReasonDialog, Switch } from './ui';
import { CustomerCtx } from './context';

const ICONS: Record<PaymentChannelId, React.ElementType> = {
  upi: Smartphone, netbanking: MonitorSmartphone, transfers: ArrowLeftRight, atm: Banknote, card: CreditCard, international: Globe,
};

export const ControlsTab: React.FC<{ ctx: CustomerCtx }> = ({ ctx }) => {
  const { account, customer, actions, onToast } = ctx;
  const [bulk, setBulk] = useState<'restrict' | 'allow' | null>(null);
  const rules = STATUS_RULES[customer.status];
  const byId = useMemo(() => new Map(customer.channels.map((c) => [c.id, c])), [customer.channels]);
  const allowed = customer.channels.filter((c) => c.enabled).length;
  const history = customer.audit.filter((a) => a.category === 'Payment Control');
  const suspended =
    customer.status === 'Total Freeze' ? 'All channels suspended by the Total Freeze'
    : customer.status === 'Debit Freeze' ? 'Debits suspended by the Debit Freeze'
    : customer.status === 'Dormant' ? 'Debits suspended while the account is dormant' : null;

  const toggle = (id: PaymentChannelId, next: boolean) => {
    actions.setChannel(account.id, id, next);
    onToast(`${CHANNEL_META[id].label} ${next ? 'allowed' : 'restricted'} for ${account.name}.`, next ? 'success' : 'alert');
  };

  return (
    <div className="bk-stack">
      <div className="bk-spread">
        <div className="bk-row">
          <Badge tone={allowed === customer.channels.length ? 'success' : 'warning'}>{allowed} of {customer.channels.length} channels allowed</Badge>
          <span className="bk-small bk-muted">Changes apply immediately and are recorded in the audit trail.</span>
        </div>
        <div className="bk-row">
          <button className="bk-btn is-danger-ghost is-sm" disabled={allowed === 0} onClick={() => setBulk('restrict')}><ShieldOff size={14} /> Restrict all channels</button>
          <button className="bk-btn is-success-ghost is-sm" disabled={allowed === customer.channels.length} onClick={() => setBulk('allow')}><ShieldCheck size={14} /> Allow all channels</button>
        </div>
      </div>

      {suspended && <Alert tone="danger"><b>{suspended}.</b> The settings below are kept and take effect again once the account is restored to Active.</Alert>}

      <div className="bk-grid-3">
        {CHANNEL_ORDER.map((id) => {
          const ch = byId.get(id);
          if (!ch) return null;
          const Icon = ICONS[id];
          return (
            <div key={id} className={`bk-control ${ch.enabled ? '' : 'is-blocked'}`}>
              <div className="bk-spread" style={{ flexWrap: 'nowrap' }}>
                <div className="bk-row" style={{ flexWrap: 'nowrap' }}>
                  <span className="bk-control-icon">{ch.enabled ? <Icon size={18} /> : <Lock size={18} />}</span>
                  <div><div className="bk-strong">{CHANNEL_META[id].label}</div><div className="bk-small bk-muted">{CHANNEL_META[id].description}</div></div>
                </div>
                <Switch checked={ch.enabled} onChange={(v) => toggle(id, v)} label={`${CHANNEL_META[id].label} ${ch.enabled ? 'allowed' : 'restricted'}`} />
              </div>
              <div className="bk-row">
                <Badge tone={ch.enabled ? 'success' : 'danger'} dot>{ch.enabled ? 'Allowed' : 'Restricted'}</Badge>
                {suspended && !rules.debit && <Badge tone="neutral">Not usable now</Badge>}
              </div>
              {(ch.last_changed_by || ch.reason) && (
                <div className="bk-small bk-muted" style={{ borderTop: '1px solid var(--bk-border)', paddingTop: 8 }}>
                  {ch.reason && <div>{ch.reason}</div>}
                  {ch.last_changed_by && <div>{ch.last_changed_by} · {fmtDateTime(ch.last_changed_at)}</div>}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <Card title="Control change history" subtitle="Who changed which channel, and when" flush>
        {history.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr><th>When</th><th>Employee</th><th>Change</th><th>Detail</th></tr></thead>
              <tbody>{history.map((h) => <tr key={h.id}><td className="bk-num" style={{ whiteSpace: 'nowrap' }}>{fmtDateTime(h.at)}</td><td>{h.actor}</td><td>{h.action}</td><td>{h.detail}</td></tr>)}</tbody>
            </table>
          </div>
        ) : <EmptyState title="No changes made in this session" text="Toggle a channel above to restrict or allow it." />}
      </Card>

      <ReasonDialog
        open={bulk !== null}
        tone={bulk === 'restrict' ? 'danger' : 'primary'}
        title={bulk === 'restrict' ? 'Restrict all payment channels' : 'Allow all payment channels'}
        subtitle={account.name}
        description={bulk === 'restrict'
          ? 'UPI, Net Banking, IMPS/NEFT/RTGS, ATM, cards and international use will all be switched off.'
          : 'Every channel will be switched on, including international transactions. Confirm this matches the customer profile.'}
        confirmLabel={bulk === 'restrict' ? 'Restrict all channels' : 'Allow all channels'}
        minLength={10}
        onCancel={() => setBulk(null)}
        onConfirm={(r) => {
          if (bulk) {
            actions.setAllChannels(account.id, bulk === 'allow', r.reason);
            onToast(bulk === 'allow' ? 'All channels allowed.' : 'All channels restricted.', bulk === 'allow' ? 'success' : 'alert');
          }
          setBulk(null);
        }}
      />
    </div>
  );
};
