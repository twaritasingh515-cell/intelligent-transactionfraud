import React, { useMemo, useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, ChevronDown, ChevronRight, Copy, Download, ExternalLink, Flag, FlagOff, Search } from 'lucide-react';
import { LedgerChannel, LedgerEntry, LedgerStatus } from '../../types/banking';
import { SEED_REFERENCE_DATE } from '../../data/bankingData';
import { copyText, downloadCsv, fmtDateTime, inr } from '../../utils/bankFormat';
import { Alert, Badge, Card, EmptyState, ReasonDialog, Stat, ledgerTone } from './ui';
import { CustomerCtx } from './context';

const CHANNELS: LedgerChannel[] = ['UPI', 'IMPS', 'NEFT', 'RTGS', 'ATM', 'POS', 'Net Banking', 'Cheque', 'Branch'];
const STATUSES: LedgerStatus[] = ['Success', 'Pending', 'Failed', 'Reversed', 'On Hold'];
const PERIODS = [
  { id: '30', label: 'Last 30 days', days: 30 },
  { id: '90', label: 'Last 90 days', days: 90 },
  { id: '180', label: 'Last 180 days', days: 180 },
  { id: 'all', label: 'All time', days: 0 },
];
const PAGE_SIZE = 12;

interface Filters {
  q: string; period: string; type: 'All' | 'Credit' | 'Debit'; channel: 'All' | LedgerChannel; status: 'All' | LedgerStatus;
  min: string; max: string; flaggedOnly: boolean;
}
const DEFAULTS: Filters = { q: '', period: '90', type: 'All', channel: 'All', status: 'All', min: '', max: '', flaggedOnly: false };

export const TransactionsTab: React.FC<{ ctx: CustomerCtx }> = ({ ctx }) => {
  const { account, customer, ledger, actions, onToast, onOpenTransaction } = ctx;
  const [f, setF] = useState<Filters>(DEFAULTS);
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<string | null>(null);
  const [flagTarget, setFlagTarget] = useState<{ entry: LedgerEntry; next: boolean } | null>(null);

  const set = <K extends keyof Filters>(key: K, value: Filters[K]) => { setF((p) => ({ ...p, [key]: value })); setPage(0); };

  // The seeded book is anchored to a business date, so "last N days" counts back from the newest data.
  const asOf = useMemo(() => Math.max(SEED_REFERENCE_DATE.getTime(), ...ledger.map((e) => new Date(e.date).getTime())), [ledger]);

  const all = useMemo(() => ledger.map((e) => {
    const flagged = customer.flag_overrides[e.id] ?? e.suspicious;
    const overridden = e.id in customer.flag_overrides;
    const reason = overridden ? customer.flag_notes?.[e.id] : e.flag_reason;
    return { ...e, flagged, overridden, reason };
  }), [ledger, customer.flag_overrides, customer.flag_notes]);

  const rows = useMemo(() => {
    const q = f.q.trim().toLowerCase();
    const days = PERIODS.find((p) => p.id === f.period)?.days || 0;
    const from = days ? asOf - days * 86400000 : 0;
    const min = f.min !== '' ? Number(f.min) : null;
    const max = f.max !== '' ? Number(f.max) : null;
    return all.filter((e) =>
      (!days || new Date(e.date).getTime() >= from) &&
      (f.type === 'All' || e.type === f.type) &&
      (f.channel === 'All' || e.channel === f.channel) &&
      (f.status === 'All' || e.status === f.status) &&
      (!f.flaggedOnly || e.flagged) &&
      (min === null || Number.isNaN(min) || e.amount >= min) &&
      (max === null || Number.isNaN(max) || e.amount <= max) &&
      (!q || [e.reference, e.counterparty, e.counterparty_detail, e.txn_id].some((v) => (v || '').toLowerCase().includes(q))));
  }, [all, f, asOf]);

  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const visible = rows.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);
  const credits = rows.filter((e) => e.type === 'Credit' && e.status === 'Success').reduce((s, e) => s + e.amount, 0);
  const debits = rows.filter((e) => e.type === 'Debit' && e.status === 'Success').reduce((s, e) => s + e.amount, 0);
  const flaggedCount = rows.filter((e) => e.flagged).length;
  const dirty = JSON.stringify(f) !== JSON.stringify(DEFAULTS);

  const exportCsv = () => {
    downloadCsv(`ledger-${account.id}-${new Date().toISOString().slice(0, 10)}.csv`, [
      ['Date', 'Type', 'Amount (INR)', 'UTR / Ref', 'Channel', 'Counterparty', 'Counterparty detail', 'Status', 'Suspicious', 'Flag reason'],
      ...rows.map((e) => [e.date, e.type, e.amount, e.reference, e.channel, e.counterparty, e.counterparty_detail, e.status, e.flagged ? 'Yes' : 'No', e.reason]),
    ]);
    onToast(`Exported ${rows.length} ledger entries.`, 'success');
  };

  return (
    <div className="bk-stack">
      <div className="bk-grid-4">
        <Stat label="Entries in view" value={rows.length} hint={`of ${all.length} on record`} />
        <Stat label="Credits (successful)" value={inr(credits)} />
        <Stat label="Debits (successful)" value={inr(debits)} />
        <Stat label="Suspicious flags" value={flaggedCount} alert={flaggedCount > 0} hint={flaggedCount ? 'Review before closing the case' : 'Nothing flagged'} />
      </div>

      <Card flush>
        <div style={{ padding: 14, display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', alignItems: 'end' }}>
          <div style={{ gridColumn: 'span 2', minWidth: 200 }}>
            <label className="bk-label" htmlFor="tx-q">Search</label>
            <div style={{ position: 'relative' }}>
              <Search size={15} className="bk-muted" style={{ position: 'absolute', left: 10, top: 10 }} aria-hidden />
              <input id="tx-q" className="bk-input" style={{ paddingLeft: 32 }} placeholder="UTR, reference or counterparty" value={f.q} onChange={(e) => set('q', e.target.value)} />
            </div>
          </div>
          <div><label className="bk-label" htmlFor="tx-period">Period</label>
            <select id="tx-period" className="bk-select" value={f.period} onChange={(e) => set('period', e.target.value)}>{PERIODS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}</select></div>
          <div><label className="bk-label" htmlFor="tx-type">Type</label>
            <select id="tx-type" className="bk-select" value={f.type} onChange={(e) => set('type', e.target.value as Filters['type'])}><option>All</option><option>Credit</option><option>Debit</option></select></div>
          <div><label className="bk-label" htmlFor="tx-ch">Channel</label>
            <select id="tx-ch" className="bk-select" value={f.channel} onChange={(e) => set('channel', e.target.value as Filters['channel'])}><option>All</option>{CHANNELS.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="bk-label" htmlFor="tx-st">Status</label>
            <select id="tx-st" className="bk-select" value={f.status} onChange={(e) => set('status', e.target.value as Filters['status'])}><option>All</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
          <div><label className="bk-label" htmlFor="tx-min">Min amount (₹)</label>
            <input id="tx-min" className="bk-input" inputMode="numeric" value={f.min} onChange={(e) => set('min', e.target.value.replace(/[^\d.]/g, ''))} placeholder="0" /></div>
          <div><label className="bk-label" htmlFor="tx-max">Max amount (₹)</label>
            <input id="tx-max" className="bk-input" inputMode="numeric" value={f.max} onChange={(e) => set('max', e.target.value.replace(/[^\d.]/g, ''))} placeholder="No limit" /></div>
        </div>
        <div className="bk-spread" style={{ padding: '0 14px 14px' }}>
          <div className="bk-row">
            <button className={`bk-chip ${f.flaggedOnly ? 'is-active' : ''}`} aria-pressed={f.flaggedOnly} onClick={() => set('flaggedOnly', !f.flaggedOnly)}><Flag size={13} /> Suspicious only</button>
            {dirty && <button className="bk-btn is-link is-sm" onClick={() => { setF(DEFAULTS); setPage(0); }}>Clear filters</button>}
          </div>
          <button className="bk-btn is-sm" onClick={exportCsv} disabled={!rows.length}><Download size={14} /> Export CSV</button>
        </div>
      </Card>

      {flaggedCount > 0 && !f.flaggedOnly && (
        <Alert tone="danger"><b>{flaggedCount} suspicious transaction{flaggedCount > 1 ? 's' : ''} in this view.</b> Open a row to see why it was flagged and link it to a fraud case.</Alert>
      )}

      <Card flush>
        {visible.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr>
                <th style={{ width: 34 }}><span className="sr-only">Details</span></th><th>Date</th><th>Type</th><th className="is-right">Amount</th><th>UTR / Ref no.</th><th>Channel</th><th>Counterparty</th><th>Status</th><th>Flag</th>
              </tr></thead>
              <tbody>
                {visible.map((e) => {
                  const isOpen = open === e.id;
                  return (
                    <React.Fragment key={e.id}>
                      <tr className={e.flagged ? 'is-flagged' : ''}>
                        <td><button className="bk-icon-btn" style={{ width: 26, height: 26, color: 'var(--bk-muted)' }} aria-expanded={isOpen} aria-label={isOpen ? 'Hide details' : 'Show details'} onClick={() => setOpen(isOpen ? null : e.id)}>
                          {isOpen ? <ChevronDown size={15} /> : <ChevronRight size={15} />}</button></td>
                        <td style={{ whiteSpace: 'nowrap' }} className="bk-num">{fmtDateTime(e.date)}</td>
                        <td><span className="bk-row" style={{ gap: 4, color: e.type === 'Credit' ? 'var(--bk-success)' : 'var(--bk-text)' }}>
                          {e.type === 'Credit' ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}{e.type}</span></td>
                        <td className="is-right bk-num bk-strong" style={{ color: e.type === 'Credit' ? 'var(--bk-success)' : undefined }}>{e.type === 'Credit' ? '+' : '−'}{inr(e.amount)}</td>
                        <td><span className="bk-mono">{e.reference}</span></td>
                        <td>{e.channel}</td>
                        <td>{e.counterparty}{e.counterparty_detail && <div className="bk-small bk-muted">{e.counterparty_detail}</div>}</td>
                        <td><Badge tone={ledgerTone(e.status)}>{e.status}</Badge></td>
                        <td>{e.flagged ? <Badge tone="danger" icon={Flag} title={e.reason}>Suspicious</Badge> : <span className="bk-muted">—</span>}</td>
                      </tr>
                      {isOpen && (
                        <tr>
                          <td />
                          <td colSpan={8} style={{ background: 'var(--bk-surface-2)' }}>
                            <div className="bk-grid-2" style={{ alignItems: 'start' }}>
                              <div className="bk-small">
                                <div><span className="bk-muted">Reference:</span> <span className="bk-mono">{e.reference}</span>{' '}
                                  <button className="bk-btn is-link is-sm" style={{ height: 22 }} onClick={async () => onToast((await copyText(e.reference)) ? 'Reference copied.' : 'Copy is not available in this browser.', 'info')}><Copy size={12} /> Copy</button></div>
                                <div><span className="bk-muted">Counterparty:</span> {e.counterparty}{e.counterparty_detail ? ` (${e.counterparty_detail})` : ''}</div>
                                {e.risk_score !== undefined && <div><span className="bk-muted">Fraud-monitor score:</span> {e.risk_score} / 100</div>}
                                {e.txn_id && <div><span className="bk-muted">Monitored transaction:</span> <span className="bk-mono">{e.txn_id}</span></div>}
                              </div>
                              <div className="bk-small">
                                {e.flagged
                                  ? <div><b style={{ color: 'var(--bk-danger)' }}>Flagged {e.overridden ? 'by employee' : `by ${e.flag_source || 'System'}`}.</b> {e.reason}</div>
                                  : <div className="bk-muted">{e.overridden ? `Flag cleared by employee. ${e.reason || ''}` : 'No suspicion recorded on this entry.'}</div>}
                                <div className="bk-row" style={{ marginTop: 8 }}>
                                  {e.txn_id && <button className="bk-btn is-sm" onClick={() => onOpenTransaction(e.txn_id!)}><ExternalLink size={13} /> Open in fraud monitor</button>}
                                  {e.flagged
                                    ? <button className="bk-btn is-sm" onClick={() => setFlagTarget({ entry: e, next: false })}><FlagOff size={13} /> Clear flag</button>
                                    : <button className="bk-btn is-danger-ghost is-sm" onClick={() => setFlagTarget({ entry: e, next: true })}><Flag size={13} /> Flag as suspicious</button>}
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : <EmptyState title="No transactions match these filters" text="Widen the period or clear the filters to see more of the ledger." action={dirty ? <button className="bk-btn is-sm" onClick={() => { setF(DEFAULTS); setPage(0); }}>Clear filters</button> : undefined} />}
        {rows.length > 0 && (
          <div className="bk-table-foot">
            <span>Showing {safePage * PAGE_SIZE + 1}–{Math.min(rows.length, (safePage + 1) * PAGE_SIZE)} of {rows.length}</span>
            <div className="bk-row">
              <button className="bk-btn is-sm" disabled={safePage === 0} onClick={() => setPage(safePage - 1)}>Previous</button>
              <span>Page {safePage + 1} of {pageCount}</span>
              <button className="bk-btn is-sm" disabled={safePage >= pageCount - 1} onClick={() => setPage(safePage + 1)}>Next</button>
            </div>
          </div>
        )}
      </Card>

      <ReasonDialog
        open={!!flagTarget}
        tone={flagTarget?.next ? 'danger' : 'primary'}
        title={flagTarget?.next ? 'Flag transaction as suspicious' : 'Clear suspicious flag'}
        subtitle={flagTarget ? `${flagTarget.entry.reference} · ${inr(flagTarget.entry.amount)}` : undefined}
        confirmLabel={flagTarget?.next ? 'Flag transaction' : 'Clear flag'}
        minLength={10}
        reasonPlaceholder={flagTarget?.next ? 'Why does this transaction look suspicious?' : 'Why is this transaction now considered genuine?'}
        onCancel={() => setFlagTarget(null)}
        onConfirm={(r) => {
          if (flagTarget) {
            actions.setFlag(account.id, flagTarget.entry.id, flagTarget.next, r.reason);
            onToast(flagTarget.next ? 'Transaction flagged as suspicious.' : 'Suspicious flag cleared.', flagTarget.next ? 'alert' : 'info');
          }
          setFlagTarget(null);
        }}
      />
    </div>
  );
};
