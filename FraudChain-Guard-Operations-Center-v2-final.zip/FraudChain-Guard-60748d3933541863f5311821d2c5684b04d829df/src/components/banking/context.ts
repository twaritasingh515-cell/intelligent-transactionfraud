import { Account, Transaction } from '../../types';
import { BankProfile, CustomerState, LedgerEntry } from '../../types/banking';
import { BankActions } from '../../state/useBankState';

export type WorkspaceTab = 'overview' | 'kyc' | 'transactions' | 'controls' | 'status' | 'requests' | 'lea';
export type ToastFn = (message: string, type?: 'success' | 'alert' | 'info') => void;

/** Everything a customer tab needs, resolved once by the workspace. */
export interface CustomerCtx {
  account: Account;
  profile: BankProfile;
  customer: CustomerState;
  ledger: LedgerEntry[];
  transactions: Transaction[];
  actions: BankActions;
  onToast: ToastFn;
  onOpenTransaction: (txnId: string) => void;
  goTab: (tab: WorkspaceTab) => void;
}
