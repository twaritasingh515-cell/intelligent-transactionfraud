import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Eye, Lock, ZoomIn, ZoomOut } from 'lucide-react';
import { LeaNotice } from '../../types/banking';
import { EMPLOYEE } from '../../data/bankingData';
import { fmtDate, fmtDateTime, inr } from '../../utils/bankFormat';

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/'/g, '&apos;');

/**
 * View-only preview of the LEA notice. Copy, print, drag and right-click are disabled and every
 * open is written to the audit trail through onFirstView. A per-employee watermark is tiled over the page.
 */
export const LeaDocumentViewer: React.FC<{ notice: LeaNotice; onFirstView: () => void }> = ({ notice, onFirstView }) => {
  const [zoom, setZoom] = useState(100);
  const logged = useRef(false);
  const doc = notice.document;

  useEffect(() => {
    if (logged.current) return;
    logged.current = true;
    onFirstView();
  }, [onFirstView]);

  const watermark = useMemo(() => {
    const label = `${EMPLOYEE.employee_id} · ${new Date().toLocaleDateString('en-IN')} · CONFIDENTIAL`;
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='170'><text x='150' y='90' text-anchor='middle' font-family='monospace' font-size='13' fill='#0F172A' transform='rotate(-24 150 85)'>${esc(label)}</text></svg>`;
    return `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;
  }, []);

  const block = (e: React.SyntheticEvent) => e.preventDefault();

  return (
    <div className="bk-secure-only">
      <div className="bk-doc-shell">
        <div className="bk-doc-bar">
          <span className="bk-row" style={{ gap: 8 }}><Lock size={14} /> <b style={{ fontWeight: 600 }}>Secure viewer</b> <span style={{ opacity: 0.75 }}>View only · Page 1 of 1</span></span>
          <span className="bk-row" style={{ gap: 6 }}>
            <button type="button" className="bk-btn" onClick={() => setZoom((z) => Math.max(70, z - 10))} disabled={zoom <= 70} aria-label="Zoom out"><ZoomOut size={14} /></button>
            <span className="bk-num" style={{ minWidth: 40, textAlign: 'center' }}>{zoom}%</span>
            <button type="button" className="bk-btn" onClick={() => setZoom((z) => Math.min(140, z + 10))} disabled={zoom >= 140} aria-label="Zoom in"><ZoomIn size={14} /></button>
          </span>
        </div>
        <div className="bk-doc-stage" onCopy={block} onCut={block} onContextMenu={block} onDragStart={block}>
          <article className="bk-doc-paper" style={{ zoom: zoom / 100 } as React.CSSProperties} aria-label={`Notice ${doc.document_ref}`}>
            <div className="bk-doc-mark" style={{ backgroundImage: watermark }} aria-hidden />
            <h3>{notice.agency.toUpperCase()}</h3>
            <div className="bk-doc-office">{notice.investigating_officer.office}</div>
            <div className="bk-doc-rule" />
            <div className="bk-doc-meta">
              <span><b>Ref:</b> {doc.document_ref}</span>
              <span><b>Date:</b> {fmtDate(doc.issued_on)}</span>
            </div>
            <p style={{ textAlign: 'left', fontWeight: 700, marginBottom: 4 }}>{doc.title}</p>
            <p style={{ textAlign: 'left' }}><b>To,</b><br />{doc.addressed_to.map((l, i) => <React.Fragment key={i}>{l}<br /></React.Fragment>)}</p>
            <p style={{ textAlign: 'left' }}><b>Subject:</b> {doc.subject}</p>
            {doc.body.map((para, i) => <p key={i}>{para}</p>)}
            <p style={{ textAlign: 'left', marginBottom: 3 }}><b>Requested actions</b></p>
            <ol>{doc.requested_actions.map((a, i) => <li key={i}>{a}</li>)}</ol>
            {doc.annexure.length > 0 && (
              <>
                <p style={{ textAlign: 'left', marginBottom: 3 }}><b>Annexure: transactions under examination</b></p>
                <table>
                  <thead><tr><th>Date and time</th><th>Reference</th><th>Amount</th><th>Note</th></tr></thead>
                  <tbody>{doc.annexure.map((r, i) => <tr key={i}><td>{fmtDateTime(r.date)}</td><td>{r.reference}</td><td>{inr(r.amount)}</td><td>{r.note}</td></tr>)}</tbody>
                </table>
              </>
            )}
            <div className="bk-doc-sign">
              <i>Digitally signed (simulated) · {doc.document_ref}</i>
              <b>{doc.signatory.name}</b><br />{doc.signatory.designation}<br />
              <span style={{ color: '#475569' }}>{notice.investigating_officer.phone} · {notice.investigating_officer.email}</span>
            </div>
            <div className="bk-doc-foot">Preview of the notice as received by the nodal officer. Synthetic demonstration document.</div>
          </article>
        </div>
      </div>
      <p className="bk-small bk-muted" style={{ margin: '8px 0 0', display: 'flex', gap: 6, alignItems: 'flex-start' }}>
        <Eye size={14} style={{ flex: 'none', marginTop: 2 }} aria-hidden /> Download, print and copy are disabled for LEA notices. Each time this document is opened, your name and time are written to the audit trail.
      </p>
    </div>
  );
};
