import React, { useState } from 'react';
import { Ban, CheckCircle2, Lock, Moon, ShieldAlert, ArrowRight } from 'lucide-react';
import { AccountStatus } from '../../types/banking';
import { STATUS_RULES, freezeNotices, isFrozen, lienHeld } from '../../utils/bankSelectors';
import { fmtDateTime, inr } from '../../utils/bankFormat';
import { Alert, Badge, Card, EmptyState, ReasonDialog } from './ui';
import { CustomerCtx } from './context';

type Target = AccountStatus;

const CATEGORIES: Record<Target, string[]> = {
  'Debit Freeze': ['LEA request', 'Suspected fraud or mule activity', 'KYC non-compliance', 'Customer reported unauthorised access', 'Internal investigation'],
  'Total Freeze': ['LEA or court order', 'Confirmed fraud', 'Regulatory direction', 'Deceased account holder', 'Internal investigation'],
  Dormant: ['No customer-initiated activity for 24 months', 'Customer request', 'Re-KYC pending'],
  Active: ['Re-KYC completed', 'Investigation closed and cleared', 'Customer request verified', 'Freeze applied in error', 'LEA release order received'],
};

export const StatusTab: React.FC<{ ctx: CustomerCtx }> = ({ ctx }) => {
  const { account, customer, actions, onToast, goTab } = ctx;
  const [target, setTarget] = useState<Target | null>(null);
  const rules = STATUS_RULES[customer.status];
  const lea = freezeNotices(customer.notices);
  const held = lienHeld(customer.notices, account.current_balance);
  const history = customer.audit.filter((a) => a.category === 'Account Status');
  const lockedByLea = lea.length > 0;
  const frozen = isFrozen(customer.status);

  const confirm = (category: string, reason: string) => {
    if (!target) return;
    actions.changeStatus(account.id, target, category, reason);
    onToast(`${account.name}: account status set to ${target}.`, target === 'Active' ? 'success' : 'alert');
    setTarget(null);
  };

  const preview = target ? STATUS_RULES[target] : null;

  return (
    <div className="bk-stack">
      <section className={`bk-card bk-status-hero ${frozen ? 'is-frozen' : customer.status === 'Dormant' ? 'is-dormant' : ''}`} aria-live="polite">
        <div>
          <div className="bk-small bk-muted">Current account status</div>
          <div className="bk-status-name">{customer.status}</div>
          <p style={{ margin: '4px 0 0', maxWidth: 560 }}>{rules.summary}</p>
          {customer.status_note ? (
            <p className="bk-small bk-muted" style={{ margin: '8px 0 0' }}>
              <b style={{ color: 'var(--bk-text)' }}>{customer.status_note.category}.</b> {customer.status_note.reason} Set by {customer.status_note.by} on {fmtDateTime(customer.status_note.at)}.
            </p>
          ) : <p className="bk-small bk-muted" style={{ margin: '8px 0 0' }}>No restriction is applied to this account.</p>}
        </div>
        <div className="bk-stack" style={{ gap: 8 }}>
          <div className="bk-perm">{rules.debit ? <CheckCircle2 size={15} color="var(--bk-success)" /> : <Ban size={15} color="var(--bk-danger)" />} Debits {rules.debit ? 'allowed' : 'blocked'}</div>
          <div className="bk-perm">{rules.credit ? <CheckCircle2 size={15} color="var(--bk-success)" /> : <Ban size={15} color="var(--bk-danger)" />} Credits {rules.credit ? 'allowed' : 'blocked'}</div>
          {held > 0 && <div className="bk-perm"><Lock size={15} color="var(--bk-danger)" /> {inr(held)} held under LEA notice</div>}
        </div>
      </section>

      {lockedByLea && (
        <Alert tone="warning">
          <b>Restoring to Active is locked.</b> {lea.length} LEA notice{lea.length > 1 ? 's' : ''} ({lea.map((n) => n.complaint_ref).join(', ')}) require this restriction.
          Release {lea.length > 1 ? 'them' : 'it'} against a written release order first.{' '}
          <button className="bk-btn is-link is-sm" onClick={() => goTab('lea')}>Go to LEA compliance <ArrowRight size={13} /></button>
        </Alert>
      )}

      <Card title="Change account status" subtitle="Every change asks for a reason and is written to the audit trail">
        <div className="bk-grid-4">
          <button className="bk-action-tile is-danger" disabled={customer.status === 'Debit Freeze'} onClick={() => setTarget('Debit Freeze')}>
            <b><Lock size={16} /> Debit Freeze</b><span>Block all debits. Credits keep coming in.</span>
          </button>
          <button className="bk-action-tile is-solid-danger" disabled={customer.status === 'Total Freeze'} onClick={() => setTarget('Total Freeze')}>
            <b><ShieldAlert size={16} /> Total Freeze</b><span>Block every debit and credit.</span>
          </button>
          <button className="bk-action-tile" disabled={customer.status === 'Dormant'} onClick={() => setTarget('Dormant')}>
            <b><Moon size={16} /> Mark Dormant</b><span>Block debits until re-KYC.</span>
          </button>
          <button className="bk-action-tile" disabled={customer.status === 'Active' || lockedByLea}
            title={lockedByLea ? 'Locked by an active LEA notice' : undefined} onClick={() => setTarget('Active')}>
            <b><CheckCircle2 size={16} color="var(--bk-success)" /> Restore to Active</b><span>{lockedByLea ? 'Locked by LEA notice.' : 'Lift the restriction.'}</span>
          </button>
        </div>
      </Card>

      <Card title="Status history" subtitle="Changes to account status for this customer" flush>
        {history.length ? (
          <div className="bk-table-wrap">
            <table className="bk-table">
              <thead><tr><th>When</th><th>Employee</th><th>Change</th><th>Reason</th></tr></thead>
              <tbody>{history.map((h) => <tr key={h.id}><td className="bk-num" style={{ whiteSpace: 'nowrap' }}>{fmtDateTime(h.at)}</td><td>{h.actor}</td><td>{h.action}</td><td>{h.detail}</td></tr>)}</tbody>
            </table>
          </div>
        ) : <EmptyState title="No status changes recorded" />}
      </Card>

      <ReasonDialog
        open={!!target}
        tone={target === 'Debit Freeze' || target === 'Total Freeze' ? 'danger' : 'primary'}
        title={target === 'Active' ? 'Restore account to Active' : target === 'Dormant' ? 'Mark account dormant' : `Apply ${target}`}
        subtitle={`${account.name} · currently ${customer.status}`}
        confirmLabel={target === 'Active' ? 'Restore account' : target === 'Dormant' ? 'Mark dormant' : `Apply ${target}`}
        categories={target ? CATEGORIES[target] : undefined}
        minLength={target === 'Debit Freeze' || target === 'Total Freeze' ? 15 : 10}
        reasonPlaceholder="State the basis for the change, with any reference numbers"
        ackLabel={target === 'Total Freeze' ? 'I understand that all credits and debits, including incoming salary and refunds, will be rejected.' : undefined}
        onCancel={() => setTarget(null)}
        onConfirm={(r) => confirm(r.category, r.reason)}
      >
        {preview && (
          <div className="bk-row" style={{ gap: 8 }}>
            <Badge tone={preview.debit ? 'success' : 'danger'}>Debits {preview.debit ? 'allowed' : 'blocked'}</Badge>
            <Badge tone={preview.credit ? 'success' : 'danger'}>Credits {preview.credit ? 'allowed' : 'blocked'}</Badge>
          </div>
        )}
      </ReasonDialog>
    </div>
  );
};
