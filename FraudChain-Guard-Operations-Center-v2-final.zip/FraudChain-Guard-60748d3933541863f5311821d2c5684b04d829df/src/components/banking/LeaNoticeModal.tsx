import React, { useCallback, useState } from 'react';
import { Copy, ExternalLink, Mail, Phone } from 'lucide-react';
import { LeaNotice } from '../../types/banking';
import { freezeNotices, isFreezeAction } from '../../utils/bankSelectors';
import { copyText, dueInfo, fmtDateTime, inr } from '../../utils/bankFormat';
import { Alert, Badge, KV, KVGrid, Modal, ReasonDialog, noticeTone } from './ui';
import { LeaDocumentViewer } from './LeaDocumentViewer';
import { CustomerCtx } from './context';

const actionLabel = (n: LeaNotice) =>
  n.action === 'Total Account Freeze' ? 'Apply total freeze'
  : n.action === 'Debit Freeze' ? 'Apply debit freeze'
  : n.action === 'Information Request' ? 'Mark records furnished'
  : `${n.action === 'Lien Marked' ? 'Mark lien of' : 'Hold'} ${inr(n.lien_amount)}`;

const effectText = (n: LeaNotice) =>
  n.action === 'Total Account Freeze' ? 'The account status will change to Total Freeze and every debit and credit will be blocked.'
  : n.action === 'Debit Freeze' ? 'The account status will change to Debit Freeze. Debits are blocked and credits are still accepted.'
  : n.action === 'Information Request' ? 'No restriction is applied. The notice is recorded as answered once you confirm the records were sent.'
  : `${inr(n.lien_amount)} will be held. The account status is unchanged and the rest of the balance stays usable.`;

export const LeaNoticeModal: React.FC<{ ctx: CustomerCtx; notice: LeaNotice; onClose: () => void }> = ({ ctx, notice, onClose }) => {
  const { account, customer, actions, onToast, onOpenTransaction } = ctx;
  const [dlg, setDlg] = useState<'apply' | 'release' | null>(null);
  const io = notice.investigating_officer;
  const due = notice.status === 'Released' ? null : dueInfo(notice.response_due);
  const applied = notice.status === 'Action Applied';
  const otherFreeze = freezeNotices(customer.notices).some((n) => n.id !== notice.id);
  const logView = useCallback(() => actions.logNoticeView(account.id, notice.id), [actions, account.id, notice.id]);

  const placed =
    notice.action === 'Information Request' ? 'Not applicable' :
    !applied ? (notice.status === 'Released' ? 'Released' : `${inr(notice.lien_amount)} requested, not yet applied`) :
    isFreezeAction(notice.action) ? `Entire balance (${inr(account.current_balance)}) frozen` :
    inr(Math.min(notice.lien_amount, account.current_balance));

  return (
    <>
      <Modal open size="xl" onClose={onClose}
        title={`Complaint ${notice.complaint_ref}`}
        subtitle={`${notice.agency} · received ${fmtDateTime(notice.received_at)}`}
        footer={<>
          <button className="bk-btn" onClick={onClose}>Close</button>
          {notice.status === 'New' && <button className="bk-btn" onClick={() => { actions.acknowledgeNotice(account.id, notice.id); onToast(`Notice ${notice.complaint_ref} acknowledged.`, 'info'); }}>Acknowledge notice</button>}
          {(notice.status === 'New' || notice.status === 'Acknowledged') && <button className={`bk-btn ${notice.action === 'Information Request' ? 'is-primary' : 'is-danger'}`} onClick={() => setDlg('apply')}>{actionLabel(notice)}</button>}
          {applied && <button className="bk-btn is-danger-ghost" onClick={() => setDlg('release')}>Release notice</button>}
        </>}>
        <div className="bk-lea-layout">
          <div className="bk-stack">
            {notice.status === 'New' && <Alert tone="danger"><b>New notice.</b> Acknowledge it and apply the requested action within the response period.</Alert>}
            <section>
              <h3 className="bk-strong" style={{ margin: '0 0 4px', color: 'var(--bk-link)' }}>Complaint</h3>
              <KVGrid>
                <KV label="Complaint ID / reference no.">
                  <span className="bk-mono">{notice.complaint_ref}</span>{' '}
                  <button className="bk-btn is-link is-sm" style={{ height: 22 }} aria-label="Copy complaint reference" onClick={async () => onToast((await copyText(notice.complaint_ref)) ? 'Complaint reference copied.' : 'Copy is not available in this browser.', 'info')}><Copy size={12} /></button>
                </KV>
                <KV label="Notice status"><Badge tone={noticeTone(notice.status)} dot>{notice.status}</Badge></KV>
                <KV label="Nature of complaint"><Badge tone="danger">{notice.nature}</Badge></KV>
                <KV label="Legal basis">{notice.legal_basis}</KV>
                <KV label="Notice received">{fmtDateTime(notice.received_at)} IST</KV>
                <KV label="Response due">{due ? <span style={{ color: due.overdue ? 'var(--bk-danger)' : undefined }}>{fmtDateTime(notice.response_due.length === 10 ? `${notice.response_due}T23:59:00+05:30` : notice.response_due).split(',')[0]} · {due.text}</span> : 'Closed'}</KV>
              </KVGrid>
            </section>

            <section>
              <h3 className="bk-strong" style={{ margin: '0 0 4px', color: 'var(--bk-link)' }}>Law enforcement agency</h3>
              <KVGrid>
                <KV label="Agency" wide>{notice.agency} <span className="bk-muted">({notice.agency_type})</span></KV>
                <KV label="Investigating officer">{io.name}<div className="bk-small bk-muted">{io.rank}</div></KV>
                <KV label="Office">{io.office}</KV>
                <KV label="Phone"><a href={`tel:${io.phone.replace(/\s/g, '')}`} className="bk-row" style={{ color: 'var(--bk-link)' }}><Phone size={13} /> {io.phone}</a></KV>
                <KV label="Official email"><a href={`mailto:${io.email}`} className="bk-row" style={{ color: 'var(--bk-link)', wordBreak: 'break-all' }}><Mail size={13} /> {io.email}</a></KV>
              </KVGrid>
            </section>

            <section>
              <h3 className="bk-strong" style={{ margin: '0 0 4px', color: 'var(--bk-link)' }}>Action and amounts</h3>
              <KVGrid>
                <KV label="Action required / imposed"><Badge tone={notice.action === 'Information Request' ? 'info' : 'danger'}>{notice.action}</Badge>
                  <div className="bk-small bk-muted">{applied ? 'Applied on the account' : notice.status === 'Released' ? 'Released' : 'Not applied yet'}</div></KV>
                <KV label="Disputed amount"><span className="bk-num">{inr(notice.disputed_amount)}</span></KV>
                <KV label="Amount under lien / frozen" wide><span className="bk-strong bk-num" style={{ color: applied && notice.action !== 'Information Request' ? 'var(--bk-danger)' : undefined }}>{placed}</span>
                  {notice.lien_amount > account.current_balance && notice.action !== 'Information Request' && <div className="bk-small bk-muted">Notice asks for {inr(notice.lien_amount)} but the current balance is {inr(account.current_balance)}, so only the available balance can be held.</div>}
                </KV>
              </KVGrid>
              {notice.linked_txn_ids.length > 0 && (
                <div className="bk-row" style={{ marginTop: 10 }}>
                  <span className="bk-small bk-muted">Linked transactions:</span>
                  {notice.linked_txn_ids.map((id) => <button key={id} className="bk-chip" style={{ height: 26 }} onClick={() => onOpenTransaction(id)}><span className="bk-mono">{id}</span> <ExternalLink size={11} /></button>)}
                </div>
              )}
            </section>

            <section>
              <h3 className="bk-strong" style={{ margin: '0 0 10px', color: 'var(--bk-link)' }}>Handling timeline</h3>
              <ul className="bk-timeline">
                {notice.timeline.map((t, i) => (
                  <li key={i} className={i === notice.timeline.length - 1 ? 'is-current' : ''}>
                    <b>{t.text}</b><small>{fmtDateTime(t.at)} · {t.actor}</small>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          <LeaDocumentViewer notice={notice} onFirstView={logView} />
        </div>
      </Modal>

      <ReasonDialog open={dlg === 'apply'} tone={notice.action === 'Information Request' ? 'primary' : 'danger'} title={actionLabel(notice)} subtitle={notice.complaint_ref}
        description={effectText(notice)} confirmLabel="Confirm and apply" reasonLabel="Handling note" reasonPlaceholder="Optional note for the audit trail"
        ackLabel="I confirm this action is authorised by the notice shown in the secure viewer." onCancel={() => setDlg(null)}
        onConfirm={(r) => { actions.applyNotice(account.id, notice.id, r.reason); onToast(`${notice.action} recorded for ${notice.complaint_ref}.`, notice.action === 'Information Request' ? 'success' : 'alert'); setDlg(null); }} />
      <ReasonDialog open={dlg === 'release'} title="Release LEA notice" subtitle={notice.complaint_ref}
        description="Release only against a written release or de-freeze order from the agency or court." confirmLabel="Release notice"
        refLabel="Release order reference" refPlaceholder="For example: order number or letter date" refRequired minLength={10}
        reasonLabel="Remarks" reasonPlaceholder="Summarise the release order and who received it"
        optionLabel={isFreezeAction(notice.action) && !otherFreeze ? 'Also restore the account to Active.' : undefined} optionDefault
        onCancel={() => setDlg(null)}
        onConfirm={(r) => { actions.releaseNotice(account.id, notice.id, r.reference, r.reason, r.option); onToast(`Notice ${notice.complaint_ref} released.`, 'success'); setDlg(null); }} />
    </>
  );
};
