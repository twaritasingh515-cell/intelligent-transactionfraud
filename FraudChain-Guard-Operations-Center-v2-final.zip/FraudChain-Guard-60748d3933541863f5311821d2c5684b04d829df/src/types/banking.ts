// Domain types for the core-banking employee modules.
// All data behind these types is synthetic and simulation-only.

export type AccountStatus = 'Active' | 'Debit Freeze' | 'Total Freeze' | 'Dormant';
export type RiskRating = 'Low' | 'Medium' | 'High';

export interface Employee {
  name: string;
  employee_id: string;
  role: string;
  branch: string;
  branch_code: string;
  ifsc: string;
  region: string;
}

export interface RelationshipManager {
  name: string;
  grade: string;
  phone: string;
  email: string;
}

export interface BankProfile {
  account_id: string;
  cif_id: string;
  account_number: string;
  product: 'Savings Account' | 'Current Account';
  segment: 'Retail' | 'SME' | 'Corporate';
  ifsc: string;
  branch_name: string;
  branch_code: string;
  opened_on: string; // ISO date
  pan_full: string; // synthetic PAN, always displayed masked
  aadhaar_last4: string;
  email: string;
  registered_address: string;
  relationship_manager: RelationshipManager;
  kyc_review_due: string; // ISO date
}

/* ---------------------------------- KYC ---------------------------------- */

export type KycDocType = 'Aadhaar' | 'PAN' | 'Passport' | 'Address Proof';
export type KycStatus = 'Verified' | 'Pending Verification' | 'Rejected' | 'Expired';

export interface KycDocument {
  id: string;
  type: KycDocType;
  document_name: string;
  number_masked: string;
  holder_name: string;
  issued_on?: string;
  expires_on?: string;
  status: KycStatus;
  submitted_on: string;
  submitted_via: 'Branch' | 'Mobile App' | 'Net Banking' | 'Email';
  reviewed_by?: string;
  reviewed_at?: string;
  remarks?: string;
}

/* ------------------------------ Payment controls ------------------------------ */

export type PaymentChannelId = 'upi' | 'netbanking' | 'atm' | 'international' | 'card' | 'transfers';

export interface ChannelControl {
  id: PaymentChannelId;
  enabled: boolean;
  last_changed_by?: string;
  last_changed_at?: string;
  reason?: string;
}

/* ------------------------------ Ledger ------------------------------ */

export type LedgerChannel = 'UPI' | 'IMPS' | 'NEFT' | 'RTGS' | 'ATM' | 'POS' | 'Net Banking' | 'Cheque' | 'Branch';
export type LedgerStatus = 'Success' | 'Pending' | 'Failed' | 'Reversed' | 'On Hold';

export interface LedgerEntry {
  id: string;
  account_id: string;
  date: string; // ISO timestamp
  type: 'Credit' | 'Debit';
  amount: number;
  reference: string; // UTR / RRN / cheque or terminal reference
  channel: LedgerChannel;
  counterparty: string;
  counterparty_detail?: string;
  status: LedgerStatus;
  suspicious: boolean;
  flag_reason?: string;
  flag_source?: 'System' | 'Employee';
  txn_id?: string; // link into the fraud-monitoring transaction set
  risk_score?: number;
}

/* ------------------------------ Service requests ------------------------------ */

export type ServiceRequestType =
  | 'Cheque Book Request'
  | 'Debit Card Reissue'
  | 'Statement Request'
  | 'Address Change'
  | 'Mobile Number Update'
  | 'Nominee Update';

export type ServiceRequestStatus =
  | 'Received'
  | 'Address Verified'
  | 'On Hold'
  | 'Approved'
  | 'Dispatched'
  | 'Delivered'
  | 'Completed'
  | 'Rejected';

export interface TrackingEvent {
  at: string;
  label: string;
  location?: string;
}

export interface ServiceRequest {
  id: string;
  type: ServiceRequestType;
  status: ServiceRequestStatus;
  raised_at: string;
  raised_via: 'Branch' | 'Mobile App' | 'Net Banking' | 'Call Centre';
  sla_due: string;
  details: string;
  remarks?: string;
  // Cheque book specific
  leaves?: 25 | 50 | 100;
  delivery_address?: string;
  address_check?: 'Not Checked' | 'Matches Registered Address' | 'Mismatch';
  courier?: string;
  tracking_id?: string;
  expected_delivery?: string;
  tracking: TrackingEvent[];
}

/* ------------------------------ LEA compliance ------------------------------ */

export type LeaAgencyType = 'State Cyber Cell' | 'Police Station' | 'Court' | 'Economic Offences Wing';
export type LeaNature =
  | 'Cyber Fraud'
  | 'P2P Scam'
  | 'Suspicious Inflow'
  | 'Loan App Extortion'
  | 'Mule Account';
export type LeaAction =
  | 'Lien Marked'
  | 'Total Account Freeze'
  | 'Debit Freeze'
  | 'Partial Amount Hold'
  | 'Information Request';
export type LeaNoticeStatus = 'New' | 'Acknowledged' | 'Action Applied' | 'Released';

export interface InvestigatingOfficer {
  name: string;
  rank: string;
  phone: string;
  email: string;
  office: string;
}

export interface LeaAnnexureRow {
  date: string;
  reference: string;
  amount: number;
  note: string;
}

export interface LeaDocument {
  title: string;
  document_ref: string;
  issued_on: string;
  addressed_to: string[];
  subject: string;
  body: string[];
  requested_actions: string[];
  signatory: { name: string; designation: string };
  annexure: LeaAnnexureRow[];
}

export interface LeaNotice {
  id: string;
  complaint_ref: string;
  agency: string;
  agency_type: LeaAgencyType;
  investigating_officer: InvestigatingOfficer;
  nature: LeaNature;
  legal_basis: string;
  action: LeaAction;
  disputed_amount: number;
  lien_amount: number; // amount required to be held by the notice
  received_at: string; // ISO timestamp
  response_due: string; // ISO date
  status: LeaNoticeStatus;
  linked_txn_ids: string[];
  document: LeaDocument;
  timeline: { at: string; actor: string; text: string }[];
}

/* ------------------------------ Audit ------------------------------ */

export type AuditCategory = 'KYC' | 'Payment Control' | 'Account Status' | 'Service Request' | 'LEA' | 'Ledger';

export interface AuditEntry {
  id: string;
  at: string; // ISO timestamp
  actor: string;
  category: AuditCategory;
  action: string;
  detail: string;
}

/* ------------------------------ Aggregate state ------------------------------ */

export interface CustomerState {
  status: AccountStatus;
  status_note?: { category: string; reason: string; by: string; at: string };
  kyc: KycDocument[];
  channels: ChannelControl[];
  requests: ServiceRequest[];
  notices: LeaNotice[];
  audit: AuditEntry[];
  flag_overrides: Record<string, boolean>;
  flag_notes?: Record<string, string>;
}

export type BankState = Record<string, CustomerState>;
