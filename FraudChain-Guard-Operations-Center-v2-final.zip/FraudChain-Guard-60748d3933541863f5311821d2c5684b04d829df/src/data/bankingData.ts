import { Account, Transaction } from '../types';
import {
  AccountStatus,
  AuditEntry,
  BankProfile,
  BankState,
  ChannelControl,
  Employee,
  KycDocument,
  LedgerChannel,
  LedgerEntry,
  LeaDocument,
  LeaNotice,
  PaymentChannelId,
  ServiceRequest,
} from '../types/banking';

/* -------------------------------------------------------------------------- */
/* Static reference data                                                      */
/* -------------------------------------------------------------------------- */

export const EMPLOYEE: Employee = {
  name: 'Rohan Deshmukh',
  employee_id: 'FCG-20418',
  role: 'Branch Operations Officer · L2',
  branch: 'Mumbai Central',
  branch_code: '0101',
  ifsc: 'FCGB0000101',
  region: 'Western Zone',
};

export const CHANNEL_META: Record<PaymentChannelId, { label: string; description: string }> = {
  upi: { label: 'UPI', description: 'Send and collect via UPI apps and VPAs' },
  netbanking: { label: 'Net Banking', description: 'Internet banking logins and fund transfers' },
  atm: { label: 'ATM Withdrawals', description: 'Cash withdrawals at bank and third-party ATMs' },
  international: { label: 'International Transactions', description: 'Overseas card use and foreign remittances' },
  card: { label: 'Card Online & POS', description: 'Debit card e-commerce and point-of-sale payments' },
  transfers: { label: 'IMPS / NEFT / RTGS', description: 'Interbank fund transfers to beneficiaries' },
};

export const CHANNEL_ORDER: PaymentChannelId[] = ['upi', 'netbanking', 'transfers', 'atm', 'card', 'international'];

/** Ledger channel → payment control that governs it. */
export const LEDGER_TO_CONTROL: Partial<Record<LedgerChannel, PaymentChannelId>> = {
  UPI: 'upi',
  IMPS: 'transfers',
  NEFT: 'transfers',
  RTGS: 'transfers',
  ATM: 'atm',
  POS: 'card',
  'Net Banking': 'netbanking',
};

/** "Now" for seeded data — the day of the seeded fraud events plus a few days. */
export const SEED_REFERENCE_DATE = new Date('2026-09-28T09:30:00+05:30');

/* -------------------------------------------------------------------------- */
/* Deterministic helpers                                                      */
/* -------------------------------------------------------------------------- */

function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function digits(seed: string, length: number): string {
  const rnd = mulberry32(hashString(seed));
  let out = '';
  for (let i = 0; i < length; i++) out += Math.floor(rnd() * 10).toString();
  return out;
}

function isoDaysBefore(days: number, hour: number, minute: number): string {
  const d = new Date(SEED_REFERENCE_DATE.getTime());
  d.setDate(d.getDate() - days);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
}

export function maskPan(pan: string): string {
  if (pan.length !== 10) return pan;
  return `${pan.slice(0, 5)}••••${pan.slice(9)}`;
}

export function maskAccountNumber(accountNumber: string): string {
  return `${'•'.repeat(Math.max(0, accountNumber.length - 4))}${accountNumber.slice(-4)}`;
}

/* -------------------------------------------------------------------------- */
/* Bank profiles                                                              */
/* -------------------------------------------------------------------------- */

const RELATIONSHIP_MANAGERS = [
  { name: 'Neha Kapadia', grade: 'Senior RM · Retail Banking', phone: '+91 22 4000 1101', email: 'neha.kapadia@fraudchain-bank.example' },
  { name: 'Arjun Malhotra', grade: 'RM · Priority Banking', phone: '+91 22 4000 1108', email: 'arjun.malhotra@fraudchain-bank.example' },
  { name: 'Shreya Iyer', grade: 'RM · Retail Banking', phone: '+91 22 4000 1115', email: 'shreya.iyer@fraudchain-bank.example' },
  { name: 'Vivek Chandran', grade: 'Business Banking Manager', phone: '+91 22 4000 1142', email: 'vivek.chandran@fraudchain-bank.example' },
  { name: 'Pallavi Deshpande', grade: 'Corporate Relationship Head', phone: '+91 22 4000 1170', email: 'pallavi.deshpande@fraudchain-bank.example' },
];

const STREETS = [
  'MG Road', 'Station Road', 'Nehru Nagar', 'Gandhi Chowk', 'Civil Lines', 'Lake View Colony',
  'Old Market Road', 'Sector 14', 'Park Street', 'Residency Road',
];

export function buildProfile(account: Account): BankProfile {
  const isBusiness = account.account_type === 'Small Business' || account.account_type === 'Corporate';
  const seed = hashString(account.id);
  const rm = RELATIONSHIP_MANAGERS[
    account.account_type === 'Corporate' ? 4 : account.account_type === 'Small Business' ? 3 : seed % 3
  ];
  const panLetters = account.pan_masked.slice(0, 5).toUpperCase();
  const panLast = account.pan_masked.slice(-1).toUpperCase();
  const pan_full = `${panLetters}${digits(`${account.id}-pan`, 4)}${/[A-Z]/.test(panLast) ? panLast : 'K'}`;
  const opened = new Date(SEED_REFERENCE_DATE.getTime());
  const ageMatch = account.account_age.match(/(\d+)\s*(year|month)/i);
  if (ageMatch) {
    const n = parseInt(ageMatch[1], 10);
    if (ageMatch[2].toLowerCase().startsWith('year')) opened.setFullYear(opened.getFullYear() - n);
    else opened.setMonth(opened.getMonth() - n);
  }
  const reviewDue = new Date(SEED_REFERENCE_DATE.getTime());
  reviewDue.setMonth(reviewDue.getMonth() + (isBusiness ? 8 : 14) - (seed % 6) * 2);
  const slug = account.name.toLowerCase().replace(/[^a-z\s]/g, '').trim().split(/\s+/).slice(0, 2).join('.');

  return {
    account_id: account.id,
    cif_id: `CIF${digits(`${account.id}-cif`, 9)}`,
    account_number: `5010${digits(`${account.id}-acct`, 8)}`,
    product: isBusiness ? 'Current Account' : 'Savings Account',
    segment: account.account_type === 'Corporate' ? 'Corporate' : account.account_type === 'Small Business' ? 'SME' : 'Retail',
    ifsc: EMPLOYEE.ifsc,
    branch_name: `${EMPLOYEE.branch} Branch`,
    branch_code: EMPLOYEE.branch_code,
    opened_on: opened.toISOString(),
    pan_full,
    aadhaar_last4: digits(`${account.id}-aadhaar`, 4),
    email: account.email || `${slug}@mail.example`,
    registered_address: `${10 + (seed % 90)}, ${STREETS[seed % STREETS.length]}, ${account.city}`,
    relationship_manager: rm,
    kyc_review_due: reviewDue.toISOString(),
  };
}

export function buildAllProfiles(accounts: Account[]): Record<string, BankProfile> {
  return Object.fromEntries(accounts.map((a) => [a.id, buildProfile(a)]));
}

/* -------------------------------------------------------------------------- */
/* KYC                                                                        */
/* -------------------------------------------------------------------------- */

type KycOverride = Partial<Pick<KycDocument, 'status' | 'remarks' | 'expires_on'>> & { skip?: boolean };

const KYC_OVERRIDES: Record<string, Partial<Record<KycDocument['type'], KycOverride>>> = {
  'ACC-VIC-01': { Passport: { status: 'Expired', expires_on: '2025-03-14' } },
  'ACC-FRD-01': {
    Aadhaar: { status: 'Pending Verification', remarks: 'Name on Aadhaar differs from account title. Manual comparison required.' },
    'Address Proof': { status: 'Rejected', remarks: 'Utility bill is in the name of a third party.' },
    Passport: { skip: true },
  },
  'ACC-MUL-01': {
    PAN: { status: 'Pending Verification' },
    'Address Proof': { status: 'Pending Verification' },
    Passport: { skip: true },
  },
  'ACC-MUL-02': {
    'Address Proof': { status: 'Expired', expires_on: '2026-06-30', remarks: 'Rent agreement lapsed. Fresh proof requested from customer.' },
    Passport: { skip: true },
  },
  'ACC-CSH-01': { Aadhaar: { status: 'Pending Verification', remarks: 'Authorised signatory Aadhaar awaiting e-KYC match.' }, Passport: { skip: true } },
  'ACC-MUL-03': {
    PAN: { status: 'Pending Verification' },
    'Address Proof': { status: 'Rejected', remarks: 'Image is blurred and the address line is unreadable.' },
    Passport: { skip: true },
  },
  'ACC-LEG-01': { Passport: { skip: true } },
  'ACC-LEG-02': { Passport: { skip: true } },
  'ACC-LEG-03': { Passport: { skip: true } },
  'ACC-LEG-04': { Passport: { skip: true } },
};

const ADDRESS_PROOF_NAMES = ['Electricity bill', 'Rent agreement', 'Property tax receipt', 'Gas connection bill', 'Bank statement (3 months)'];

export function buildKycDocuments(account: Account, profile: BankProfile): KycDocument[] {
  const overrides = KYC_OVERRIDES[account.id] || {};
  const seed = hashString(account.id);
  const submitted = isoDaysBefore(30 + (seed % 200), 11, 20);
  const base: KycDocument[] = [
    {
      id: `${account.id}-KYC-AADHAAR`,
      type: 'Aadhaar',
      document_name: account.account_type === 'Corporate' || account.account_type === 'Small Business' ? 'Aadhaar (authorised signatory)' : 'Aadhaar card (e-KYC)',
      number_masked: `XXXX XXXX ${profile.aadhaar_last4}`,
      holder_name: account.name,
      issued_on: '2016-04-12',
      status: 'Verified',
      submitted_on: submitted,
      submitted_via: 'Branch',
      reviewed_by: 'Kavya Nair (FCG-11872)',
      reviewed_at: submitted,
    },
    {
      id: `${account.id}-KYC-PAN`,
      type: 'PAN',
      document_name: 'PAN card',
      number_masked: maskPan(profile.pan_full),
      holder_name: account.name,
      issued_on: '2014-08-21',
      status: 'Verified',
      submitted_on: submitted,
      submitted_via: 'Branch',
      reviewed_by: 'Kavya Nair (FCG-11872)',
      reviewed_at: submitted,
    },
    {
      id: `${account.id}-KYC-PASSPORT`,
      type: 'Passport',
      document_name: 'Indian passport',
      number_masked: `P${digits(`${account.id}-pp`, 1)}••••${digits(`${account.id}-pp2`, 3)}`,
      holder_name: account.name,
      issued_on: '2019-02-08',
      expires_on: '2029-02-07',
      status: 'Verified',
      submitted_on: submitted,
      submitted_via: 'Mobile App',
      reviewed_by: 'Kavya Nair (FCG-11872)',
      reviewed_at: submitted,
    },
    {
      id: `${account.id}-KYC-ADDRESS`,
      type: 'Address Proof',
      document_name: ADDRESS_PROOF_NAMES[seed % ADDRESS_PROOF_NAMES.length],
      number_masked: `Ref ••••${digits(`${account.id}-addr`, 4)}`,
      holder_name: account.name,
      issued_on: isoDaysBefore(70 + (seed % 90), 9, 0).slice(0, 10),
      status: 'Verified',
      submitted_on: submitted,
      submitted_via: 'Branch',
      reviewed_by: 'Kavya Nair (FCG-11872)',
      reviewed_at: submitted,
    },
  ];

  return base
    .filter((doc) => !overrides[doc.type]?.skip)
    .map((doc) => {
      const o = overrides[doc.type];
      if (!o) return doc;
      const next: KycDocument = { ...doc, ...o };
      delete (next as { skip?: boolean }).skip;
      if (next.status === 'Pending Verification') {
        next.reviewed_by = undefined;
        next.reviewed_at = undefined;
      }
      if (next.status === 'Rejected' || next.status === 'Expired') {
        next.reviewed_by = next.reviewed_by || 'Kavya Nair (FCG-11872)';
      }
      return next;
    });
}

/* -------------------------------------------------------------------------- */
/* Payment controls                                                           */
/* -------------------------------------------------------------------------- */

const CONTROL_OVERRIDES: Record<string, Partial<Record<PaymentChannelId, { enabled: boolean; reason: string }>>> = {
  'ACC-FRD-01': {
    upi: { enabled: false, reason: 'Blocked by fraud operations after collector-account pattern.' },
    netbanking: { enabled: false, reason: 'Blocked by fraud operations after collector-account pattern.' },
    transfers: { enabled: false, reason: 'Blocked by fraud operations after collector-account pattern.' },
    international: { enabled: false, reason: 'Never enabled for this profile.' },
  },
  'ACC-MUL-01': {
    upi: { enabled: false, reason: 'Rapid forwarding of inbound credits detected.' },
    transfers: { enabled: false, reason: 'Rapid forwarding of inbound credits detected.' },
  },
  'ACC-MUL-02': { upi: { enabled: false, reason: 'Rapid forwarding of inbound credits detected.' } },
};

export function buildChannels(account: Account): ChannelControl[] {
  const retailNoIntl = account.account_type === 'Student' || account.account_type === 'Homemaker';
  const overrides = CONTROL_OVERRIDES[account.id] || {};
  return CHANNEL_ORDER.map((id) => {
    const o = overrides[id];
    const defaultEnabled = id === 'international' ? !retailNoIntl : true;
    if (o) {
      return {
        id,
        enabled: o.enabled,
        last_changed_by: 'Fraud Ops · Rule Engine',
        last_changed_at: isoDaysBefore(3, 10, 42),
        reason: o.reason,
      };
    }
    return { id, enabled: defaultEnabled };
  });
}

/* -------------------------------------------------------------------------- */
/* Service requests                                                           */
/* -------------------------------------------------------------------------- */

function chequeTimeline(events: [number, string, string?][]): ServiceRequest['tracking'] {
  return events.map(([daysAgo, label, location]) => ({ at: isoDaysBefore(daysAgo, 10 + (daysAgo % 5), 15), label, location }));
}

export function buildServiceRequests(account: Account, profile: BankProfile): ServiceRequest[] {
  const addr = profile.registered_address;
  switch (account.id) {
    case 'ACC-VIC-01':
      return [
        {
          id: 'SR-260918-0412', type: 'Cheque Book Request', status: 'Dispatched', raised_at: isoDaysBefore(8, 12, 5), raised_via: 'Mobile App',
          sla_due: isoDaysBefore(-2, 18, 0), details: '25-leaf cheque book, standard delivery to registered address.', leaves: 25, delivery_address: addr,
          address_check: 'Matches Registered Address', courier: 'BlueDart Express', tracking_id: 'BD7742019338', expected_delivery: isoDaysBefore(-1, 18, 0),
          tracking: chequeTimeline([[8, 'Request received'], [7, 'Address verified against KYC'], [6, 'Approved and cheque book printed'], [4, 'Dispatched from Mumbai hub', 'Mumbai'], [2, 'In transit', 'Pune hub'], [1, 'Out for delivery', 'Pune']]),
        },
        {
          id: 'SR-260901-0177', type: 'Statement Request', status: 'Completed', raised_at: isoDaysBefore(27, 15, 30), raised_via: 'Net Banking',
          sla_due: isoDaysBefore(25, 18, 0), details: 'Statement for the last 6 months, sent to registered email.', tracking: chequeTimeline([[27, 'Request received'], [26, 'Statement emailed']]),
        },
      ];
    case 'ACC-VIC-02':
      return [
        {
          id: 'SR-260927-0533', type: 'Cheque Book Request', status: 'Received', raised_at: isoDaysBefore(1, 16, 42), raised_via: 'Mobile App',
          sla_due: isoDaysBefore(-3, 18, 0), details: '50-leaf cheque book. Customer asked for delivery to an office address.', leaves: 50,
          delivery_address: 'Tower B, 4th Floor, Embassy Tech Village, Outer Ring Road, Bengaluru', address_check: 'Not Checked',
          tracking: chequeTimeline([[1, 'Request received']]),
        },
      ];
    case 'ACC-FRD-01':
      return [
        {
          id: 'SR-260926-0498', type: 'Cheque Book Request', status: 'On Hold', raised_at: isoDaysBefore(2, 11, 10), raised_via: 'Net Banking',
          sla_due: isoDaysBefore(-1, 18, 0), details: '100-leaf cheque book requested three months after account opening, delivery to a third-party address.', leaves: 100,
          delivery_address: '2nd Floor, Shanti Complex, Karmatand Road, Jamtara', address_check: 'Mismatch', remarks: 'Held: address mismatch and active LEA notice on the account.',
          tracking: chequeTimeline([[2, 'Request received'], [2, 'Address check flagged a mismatch'], [1, 'Placed on hold by operations']]),
        },
      ];
    case 'ACC-LEG-02':
      return [
        {
          id: 'SR-260925-0301', type: 'Cheque Book Request', status: 'Address Verified', raised_at: isoDaysBefore(3, 10, 5), raised_via: 'Branch',
          sla_due: isoDaysBefore(-1, 18, 0), details: '100-leaf business cheque book, pick-up by authorised signatory declined; courier delivery.', leaves: 100,
          delivery_address: addr, address_check: 'Matches Registered Address', tracking: chequeTimeline([[3, 'Request received'], [2, 'Address verified against KYC']]),
        },
        {
          id: 'SR-260911-0088', type: 'Mobile Number Update', status: 'Completed', raised_at: isoDaysBefore(17, 13, 20), raised_via: 'Branch',
          sla_due: isoDaysBefore(15, 18, 0), details: 'Registered mobile updated after OTP validation on the new number.', tracking: chequeTimeline([[17, 'Request received'], [16, 'OTP validated'], [16, 'Mobile number updated']]),
        },
      ];
    case 'ACC-LEG-01':
      return [
        {
          id: 'SR-260928-0611', type: 'Debit Card Reissue', status: 'Received', raised_at: isoDaysBefore(0, 8, 35), raised_via: 'Mobile App',
          sla_due: isoDaysBefore(-4, 18, 0), details: 'Card damaged at ATM. Replacement requested for the registered address.', tracking: chequeTimeline([[0, 'Request received']]),
        },
      ];
    case 'ACC-MUL-03':
      return [
        {
          id: 'SR-260927-0540', type: 'Address Change', status: 'Received', raised_at: isoDaysBefore(1, 14, 5), raised_via: 'Mobile App',
          sla_due: isoDaysBefore(-2, 18, 0), details: 'Customer wants to change the registered address to a hostel in another city. Supporting proof is pending.', tracking: chequeTimeline([[1, 'Request received']]),
        },
      ];
    default:
      return [];
  }
}

/* -------------------------------------------------------------------------- */
/* LEA notices                                                                */
/* -------------------------------------------------------------------------- */

interface NoticeSeed {
  id: string;
  complaint_ref: string;
  agency: string;
  agency_type: LeaNotice['agency_type'];
  io: LeaNotice['investigating_officer'];
  nature: LeaNotice['nature'];
  legal_basis: string;
  action: LeaNotice['action'];
  disputed_amount: number;
  lien_amount: number;
  received_at: string;
  response_due: string;
  status: LeaNotice['status'];
  linked_txn_ids: string[];
  victim_summary: string;
  signatory: LeaDocument['signatory'];
  annexure_txn_ids: string[];
}

function makeNotice(seed: NoticeSeed, account: Account, profile: BankProfile, txnLookup: Map<string, Transaction>): LeaNotice {
  const annexure = seed.annexure_txn_ids
    .map((id) => txnLookup.get(id))
    .filter((t): t is Transaction => Boolean(t))
    .map((t) => ({
      date: t.timestamp,
      reference: `${t.type}-${t.transaction_id.replace('TXN-', '')}`,
      amount: t.amount,
      note: t.receiver_id === account.id ? 'Credited to the account under reference' : 'Debited from the account under reference',
    }));

  const actionText: Record<LeaNotice['action'], string> = {
    'Lien Marked': `mark a lien of ₹${seed.lien_amount.toLocaleString('en-IN')} on the account`,
    'Total Account Freeze': 'freeze the account for all debits and credits until further written orders',
    'Debit Freeze': 'freeze all debits on the account while allowing credits',
    'Partial Amount Hold': `hold ₹${seed.lien_amount.toLocaleString('en-IN')} in the account and allow the remaining balance to be operated`,
    'Information Request': 'furnish the account opening form, KYC file and statement of account for the period given below',
  };

  const document: LeaDocument = {
    title: seed.action === 'Information Request' ? 'Notice for production of records' : 'Notice for freezing / holding of funds',
    document_ref: `${seed.complaint_ref}/NTC/${seed.received_at.slice(0, 4)}`,
    issued_on: seed.received_at,
    addressed_to: ['The Nodal Officer (Law Enforcement Liaison)', `FraudChain Bank, ${profile.branch_name}`, `IFSC ${profile.ifsc}`],
    subject: `${seed.nature} complaint ${seed.complaint_ref}: A/C ${profile.account_number} (${account.name})`,
    body: [
      `A complaint bearing reference ${seed.complaint_ref} has been registered with this office. ${seed.victim_summary}`,
      `Preliminary analysis shows that funds of ₹${seed.disputed_amount.toLocaleString('en-IN')} connected to this complaint passed through the above account. The account holder, ${account.name}, is being examined as part of the investigation.`,
      `You are requested, under ${seed.legal_basis}, to ${actionText[seed.action]}, and to acknowledge this notice within the response period.`,
    ],
    requested_actions: [
      seed.action === 'Information Request' ? 'Furnish the records listed above within the response date' : `Action requested: ${seed.action}`,
      'Do not inform the account holder of the contents of this notice beyond what the law requires',
      'Share the current balance and the amount actually held, with a certified statement, on compliance',
    ],
    signatory: seed.signatory,
    annexure,
  };

  const timeline: LeaNotice['timeline'] = [
    { at: seed.received_at, actor: 'Nodal Officer Desk', text: `Notice received from ${seed.agency} (${seed.complaint_ref}).` },
  ];
  if (seed.status === 'Acknowledged' || seed.status === 'Action Applied') {
    timeline.push({ at: seed.received_at, actor: 'Nodal Officer Desk', text: 'Notice acknowledged. Acknowledgement mailed to the investigating officer.' });
  }
  if (seed.status === 'Action Applied') {
    timeline.push({ at: seed.received_at, actor: 'Operations · Account Control', text: `${seed.action} applied on the account.` });
  }

  return {
    id: seed.id,
    complaint_ref: seed.complaint_ref,
    agency: seed.agency,
    agency_type: seed.agency_type,
    investigating_officer: seed.io,
    nature: seed.nature,
    legal_basis: seed.legal_basis,
    action: seed.action,
    disputed_amount: seed.disputed_amount,
    lien_amount: seed.lien_amount,
    received_at: seed.received_at,
    response_due: seed.response_due,
    status: seed.status,
    linked_txn_ids: seed.linked_txn_ids,
    document,
    timeline,
  };
}

const NOTICE_SEEDS: Record<string, NoticeSeed[]> = {
  'ACC-FRD-01': [
    {
      id: 'LEA-2609-001', complaint_ref: 'NCRP-2609-25-014872', agency: 'Cyber Police Station, Pune City', agency_type: 'Police Station',
      io: { name: 'Insp. Sandeep Pawar', rank: 'Inspector of Police', phone: '+91 90000 11201', email: 'sandeep.pawar@cyberpolice.example', office: 'Cyber Police Station, Pune City' },
      nature: 'Cyber Fraud', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Total Account Freeze', disputed_amount: 485000, lien_amount: 8200,
      received_at: '2026-09-25T14:32:00+05:30', response_due: '2026-10-02', status: 'Action Applied', linked_txn_ids: ['TXN-894201'],
      victim_summary: 'The complainant, a retired government employee, reports losing ₹4,85,000 through a fake electricity-bill app that took over his SIM and authorised a UPI transfer.',
      signatory: { name: 'Sandeep Pawar', designation: 'Inspector of Police, Cyber Police Station, Pune City' }, annexure_txn_ids: ['TXN-894201'],
    },
    {
      id: 'LEA-2609-002', complaint_ref: 'NCRP-2609-26-015340', agency: 'Cyber Crime Police Station, Bengaluru City', agency_type: 'Police Station',
      io: { name: 'SI Meera Rao', rank: 'Sub-Inspector', phone: '+91 90000 11244', email: 'meera.rao@blrcyber.example', office: 'Cyber Crime Police Station, Bengaluru City' },
      nature: 'Loan App Extortion', legal_basis: 'Section 94 BNSS (production of documents)', action: 'Information Request', disputed_amount: 60000, lien_amount: 0,
      received_at: '2026-09-27T11:05:00+05:30', response_due: '2026-09-30', status: 'Acknowledged', linked_txn_ids: ['TXN-894220'],
      victim_summary: 'The complainant reports paying ₹60,000 under threat from an instant-loan app collection agent.',
      signatory: { name: 'Meera Rao', designation: 'Sub-Inspector, Cyber Crime Police Station, Bengaluru City' }, annexure_txn_ids: ['TXN-894220'],
    },
  ],
  'ACC-MUL-01': [
    {
      id: 'LEA-2609-003', complaint_ref: 'RJ-CYB-2026-08811', agency: 'State Cyber Crime Cell, Rajasthan', agency_type: 'State Cyber Cell',
      io: { name: 'SI Anita Choudhary', rank: 'Sub-Inspector', phone: '+91 90000 22317', email: 'anita.choudhary@rajcyber.example', office: 'State Cyber Crime Cell, Jaipur' },
      nature: 'Mule Account', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Debit Freeze', disputed_amount: 480000, lien_amount: 1240,
      received_at: '2026-09-25T16:48:00+05:30', response_due: '2026-10-03', status: 'Action Applied', linked_txn_ids: ['TXN-894202', 'TXN-894203'],
      victim_summary: 'Funds from a cyber-fraud victim were received into this account and forwarded within minutes. The account is suspected to be a rented mule account.',
      signatory: { name: 'Anita Choudhary', designation: 'Sub-Inspector, State Cyber Crime Cell, Rajasthan' }, annexure_txn_ids: ['TXN-894202', 'TXN-894203'],
    },
  ],
  'ACC-MUL-02': [
    {
      id: 'LEA-2609-004', complaint_ref: 'UP-CYB-MTH-2026-0442', agency: 'Cyber Crime Police Station, Mathura', agency_type: 'Police Station',
      io: { name: 'SI Rakesh Yadav', rank: 'Sub-Inspector', phone: '+91 90000 33458', email: 'rakesh.yadav@upcyber.example', office: 'Cyber Crime Police Station, Mathura' },
      nature: 'Suspicious Inflow', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Partial Amount Hold', disputed_amount: 465000, lien_amount: 2000,
      received_at: '2026-09-26T10:20:00+05:30', response_due: '2026-10-04', status: 'Action Applied', linked_txn_ids: ['TXN-894203', 'TXN-894204'],
      victim_summary: 'An inbound credit of ₹4,65,000 from a suspected mule account was forwarded to a P2P desk within seven minutes.',
      signatory: { name: 'Rakesh Yadav', designation: 'Sub-Inspector, Cyber Crime Police Station, Mathura' }, annexure_txn_ids: ['TXN-894203', 'TXN-894204'],
    },
  ],
  'ACC-CSH-01': [
    {
      id: 'LEA-2609-005', complaint_ref: 'KA-CCPS-2026-3127', agency: 'Cyber Crime Police Station, Bengaluru City', agency_type: 'Police Station',
      io: { name: 'DySP Farhan Qureshi', rank: 'Deputy Superintendent of Police', phone: '+91 90000 44562', email: 'farhan.qureshi@blrcyber.example', office: 'CCPS, Bengaluru City' },
      nature: 'P2P Scam', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Lien Marked', disputed_amount: 450000, lien_amount: 450000,
      received_at: '2026-09-26T17:15:00+05:30', response_due: '2026-10-05', status: 'Action Applied', linked_txn_ids: ['TXN-894204'],
      victim_summary: 'Layered fraud proceeds were received in a P2P settlement account and converted to a digital asset through an OTC trade.',
      signatory: { name: 'Farhan Qureshi', designation: 'Deputy Superintendent of Police, CCPS, Bengaluru City' }, annexure_txn_ids: ['TXN-894204'],
    },
  ],
  'ACC-MUL-03': [
    {
      id: 'LEA-2609-006', complaint_ref: 'MP-CYB-IDR-2026-1903', agency: 'State Cyber Cell, Madhya Pradesh (Indore Range)', agency_type: 'State Cyber Cell',
      io: { name: 'Insp. Divya Solanki', rank: 'Inspector of Police', phone: '+91 90000 55671', email: 'divya.solanki@mpcyber.example', office: 'State Cyber Cell, Indore Range' },
      nature: 'Suspicious Inflow', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Lien Marked', disputed_amount: 157000, lien_amount: 4200,
      received_at: '2026-09-27T09:42:00+05:30', response_due: '2026-10-04', status: 'Acknowledged', linked_txn_ids: ['TXN-894208', 'TXN-894209', 'TXN-894210'],
      victim_summary: 'Small extortion credits were aggregated in this account and merged into a collector account.',
      signatory: { name: 'Divya Solanki', designation: 'Inspector of Police, State Cyber Cell, Indore Range' }, annexure_txn_ids: ['TXN-894208', 'TXN-894209', 'TXN-894210'],
    },
  ],
  'ACC-CORP-01': [
    {
      id: 'LEA-2609-007', complaint_ref: 'EOW-MUM-2026-0287', agency: 'Economic Offences Wing, Mumbai', agency_type: 'Economic Offences Wing',
      io: { name: 'ACP Neha Verma', rank: 'Assistant Commissioner of Police', phone: '+91 90000 66784', email: 'neha.verma@eowmumbai.example', office: 'Economic Offences Wing, Mumbai' },
      nature: 'Suspicious Inflow', legal_basis: 'Section 106 BNSS (seizure of property)', action: 'Partial Amount Hold', disputed_amount: 3450000, lien_amount: 1500000,
      received_at: '2026-09-28T08:55:00+05:30', response_due: '2026-09-30', status: 'New', linked_txn_ids: ['TXN-894215'],
      victim_summary: 'A society maintenance-fund payment of ₹34,50,000 is alleged to have been diverted to this account through a spoofed vendor invoice.',
      signatory: { name: 'Neha Verma', designation: 'Assistant Commissioner of Police, Economic Offences Wing, Mumbai' }, annexure_txn_ids: ['TXN-894215'],
    },
  ],
};

export function buildNotices(account: Account, profile: BankProfile, transactions: Transaction[]): LeaNotice[] {
  const lookup = new Map(transactions.map((t) => [t.transaction_id, t]));
  return (NOTICE_SEEDS[account.id] || []).map((seed) => makeNotice(seed, account, profile, lookup));
}

/** Amount that active notices require the bank to hold. */
export function activeLienTotal(notices: LeaNotice[], balance: number): number {
  const total = notices
    .filter((n) => n.status === 'Action Applied' && n.lien_amount > 0)
    .reduce((sum, n) => sum + n.lien_amount, 0);
  return Math.min(total, balance);
}

const INITIAL_STATUS: Record<string, AccountStatus> = {
  'ACC-FRD-01': 'Total Freeze',
  'ACC-MUL-01': 'Debit Freeze',
};

/* -------------------------------------------------------------------------- */
/* Ledger                                                                     */
/* -------------------------------------------------------------------------- */

interface RoutineTemplate {
  label: string;
  detail: string;
  type: 'Credit' | 'Debit';
  channel: LedgerChannel;
  min: number;
  max: number;
  day: number;
}

const ROUTINE_TEMPLATES: Record<Account['account_type'], RoutineTemplate[]> = {
  Salaried: [
    { label: 'Employer payroll', detail: 'Salary credit', type: 'Credit', channel: 'NEFT', min: 0.8, max: 0.92, day: 4 },
    { label: 'Employer payroll', detail: 'Salary credit', type: 'Credit', channel: 'NEFT', min: 0.8, max: 0.92, day: 34 },
    { label: 'Landlord', detail: 'House rent', type: 'Debit', channel: 'UPI', min: 0.2, max: 0.28, day: 8 },
    { label: 'BBPS electricity', detail: 'Utility bill', type: 'Debit', channel: 'Net Banking', min: 0.02, max: 0.04, day: 11 },
    { label: 'AMC SIP mandate', detail: 'Mutual fund SIP', type: 'Debit', channel: 'Net Banking', min: 0.07, max: 0.11, day: 14 },
    { label: 'Supermarket', detail: 'Groceries', type: 'Debit', channel: 'POS', min: 0.02, max: 0.05, day: 6 },
    { label: 'ATM withdrawal', detail: 'Cash withdrawal', type: 'Debit', channel: 'ATM', min: 0.03, max: 0.06, day: 17 },
    { label: 'Restaurant', detail: 'Dining', type: 'Debit', channel: 'UPI', min: 0.01, max: 0.03, day: 20 },
  ],
  Student: [
    { label: 'Parent transfer', detail: 'Monthly allowance', type: 'Credit', channel: 'UPI', min: 0.5, max: 0.65, day: 5 },
    { label: 'Parent transfer', detail: 'Monthly allowance', type: 'Credit', channel: 'UPI', min: 0.5, max: 0.65, day: 35 },
    { label: 'Hostel mess', detail: 'Mess fee', type: 'Debit', channel: 'Net Banking', min: 0.25, max: 0.3, day: 9 },
    { label: 'Campus canteen', detail: 'Food', type: 'Debit', channel: 'POS', min: 0.02, max: 0.05, day: 12 },
    { label: 'Mobile recharge', detail: 'Prepaid recharge', type: 'Debit', channel: 'UPI', min: 0.03, max: 0.05, day: 15 },
    { label: 'Friend split', detail: 'UPI split', type: 'Credit', channel: 'UPI', min: 0.02, max: 0.06, day: 18 },
    { label: 'ATM withdrawal', detail: 'Cash withdrawal', type: 'Debit', channel: 'ATM', min: 0.08, max: 0.12, day: 21 },
  ],
  Homemaker: [
    { label: 'Family transfer', detail: 'Household allowance', type: 'Credit', channel: 'NEFT', min: 0.5, max: 0.7, day: 6 },
    { label: 'Family transfer', detail: 'Household allowance', type: 'Credit', channel: 'NEFT', min: 0.5, max: 0.7, day: 36 },
    { label: 'Kirana store', detail: 'Groceries', type: 'Debit', channel: 'UPI', min: 0.06, max: 0.1, day: 8 },
    { label: 'School fees', detail: 'Term fee', type: 'Debit', channel: 'Net Banking', min: 0.15, max: 0.22, day: 13 },
    { label: 'Tailoring customer', detail: 'Payment received', type: 'Credit', channel: 'UPI', min: 0.03, max: 0.08, day: 16 },
    { label: 'ATM withdrawal', detail: 'Cash withdrawal', type: 'Debit', channel: 'ATM', min: 0.05, max: 0.09, day: 22 },
  ],
  'Small Business': [
    { label: 'Retail customer', detail: 'Sales receipt', type: 'Credit', channel: 'UPI', min: 0.12, max: 0.25, day: 3 },
    { label: 'Retail customer', detail: 'Sales receipt', type: 'Credit', channel: 'UPI', min: 0.12, max: 0.25, day: 9 },
    { label: 'Card settlement', detail: 'POS settlement', type: 'Credit', channel: 'POS', min: 0.1, max: 0.2, day: 12 },
    { label: 'Supplier payment', detail: 'Inventory purchase', type: 'Debit', channel: 'NEFT', min: 0.25, max: 0.35, day: 7 },
    { label: 'GST payment', detail: 'Monthly GST', type: 'Debit', channel: 'Net Banking', min: 0.06, max: 0.1, day: 15 },
    { label: 'Staff salaries', detail: 'Payroll batch', type: 'Debit', channel: 'NEFT', min: 0.2, max: 0.28, day: 19 },
  ],
  Corporate: [
    { label: 'Client remittance', detail: 'Invoice settlement', type: 'Credit', channel: 'RTGS', min: 0.25, max: 0.45, day: 4 },
    { label: 'Client remittance', detail: 'Invoice settlement', type: 'Credit', channel: 'RTGS', min: 0.25, max: 0.45, day: 13 },
    { label: 'Vendor payment', detail: 'Supplier invoice', type: 'Debit', channel: 'NEFT', min: 0.15, max: 0.3, day: 7 },
    { label: 'Payroll', detail: 'Monthly payroll batch', type: 'Debit', channel: 'RTGS', min: 0.2, max: 0.3, day: 25 },
    { label: 'GST and TDS', detail: 'Statutory payments', type: 'Debit', channel: 'Net Banking', min: 0.05, max: 0.1, day: 16 },
  ],
};

const REF_PREFIX: Record<LedgerChannel, string> = {
  UPI: '', IMPS: '', NEFT: 'FCGBN', RTGS: 'FCGBR', ATM: 'ATM', POS: 'POS', 'Net Banking': 'NB', Cheque: 'CHQ', Branch: 'BR',
};

function makeReference(channel: LedgerChannel, seed: string): string {
  const prefix = REF_PREFIX[channel];
  if (channel === 'UPI' || channel === 'IMPS') return `6${digits(seed, 11)}`;
  return `${prefix}${digits(seed, channel === 'NEFT' || channel === 'RTGS' ? 11 : 9)}`;
}

function roundAmount(value: number): number {
  if (value >= 100000) return Math.round(value / 1000) * 1000;
  if (value >= 5000) return Math.round(value / 100) * 100;
  return Math.max(10, Math.round(value / 10) * 10);
}

export function generateRoutineEntries(account: Account): LedgerEntry[] {
  const rnd = mulberry32(hashString(`${account.id}-routine`));
  const cap = account.usual_monthly_credit_range[1];
  return ROUTINE_TEMPLATES[account.account_type].map((tpl, i) => {
    const amount = roundAmount((tpl.min + rnd() * (tpl.max - tpl.min)) * cap);
    const statusRoll = (hashString(`${account.id}-${i}`) % 13);
    return {
      id: `RT-${account.id}-${i}`,
      account_id: account.id,
      date: isoDaysBefore(tpl.day + 3, 9 + Math.floor(rnd() * 9), Math.floor(rnd() * 60)),
      type: tpl.type,
      amount,
      reference: makeReference(tpl.channel, `${account.id}-ref-${i}`),
      channel: tpl.channel,
      counterparty: tpl.label,
      counterparty_detail: tpl.detail,
      status: statusRoll === 0 ? 'Failed' : statusRoll === 1 ? 'Pending' : 'Success',
      suspicious: false,
    };
  });
}

export interface LedgerContext {
  accountsMap: Map<string, Account>;
  profiles: Record<string, BankProfile>;
  transactions: Transaction[];
  routine: Record<string, LedgerEntry[]>;
}

const TXN_CHANNEL: Record<Transaction['type'], LedgerChannel> = { UPI: 'UPI', IMPS: 'IMPS', NEFT: 'NEFT' };

export function buildLedger(accountId: string, ctx: LedgerContext): LedgerEntry[] {
  const fromTransactions: LedgerEntry[] = ctx.transactions
    .filter((t) => t.sender_id === accountId || t.receiver_id === accountId)
    .map((t) => {
      const isCredit = t.receiver_id === accountId;
      const otherId = isCredit ? t.sender_id : t.receiver_id;
      const other = ctx.accountsMap.get(otherId);
      const otherProfile = ctx.profiles[otherId];
      const topSignal = [...t.detected_signals].sort((a, b) => b.points - a.points)[0];
      const suspicious = t.label === 'suspicious' || t.risk_band === 'High' || t.risk_band === 'Critical';
      return {
        id: `${t.transaction_id}:${accountId}`,
        account_id: accountId,
        date: t.timestamp,
        type: isCredit ? 'Credit' : 'Debit',
        amount: t.amount,
        reference: makeReference(TXN_CHANNEL[t.type], t.transaction_id),
        channel: TXN_CHANNEL[t.type],
        counterparty: other?.name || otherId,
        counterparty_detail: other?.upi_handle || (otherProfile ? `A/C ${maskAccountNumber(otherProfile.account_number)}` : undefined),
        status: isCredit && t.investigation_status === 'Customer Verification Pending' ? 'On Hold' : 'Success',
        suspicious,
        flag_reason: suspicious ? `${topSignal ? topSignal.name : 'Model flag'} · risk score ${t.risk_score}` : undefined,
        flag_source: suspicious ? 'System' : undefined,
        txn_id: t.transaction_id,
        risk_score: t.risk_score,
      } as LedgerEntry;
    });

  return [...fromTransactions, ...(ctx.routine[accountId] || [])].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
  );
}

/* -------------------------------------------------------------------------- */
/* Aggregate initial state                                                    */
/* -------------------------------------------------------------------------- */

function seedAudit(accountId: string, status: AccountStatus, notices: LeaNotice[]): AuditEntry[] {
  const entries: AuditEntry[] = [];
  notices.forEach((n) => {
    entries.push({
      id: `AUD-${n.id}-rx`, at: n.received_at, actor: 'Nodal Officer Desk', category: 'LEA', action: 'LEA notice received',
      detail: `${n.complaint_ref} from ${n.agency}. Requested action: ${n.action}.`,
    });
    if (n.status === 'Action Applied') {
      entries.push({
        id: `AUD-${n.id}-act`, at: n.received_at, actor: 'Operations · Account Control', category: 'LEA', action: `${n.action} applied`,
        detail: `Applied against notice ${n.complaint_ref}.`,
      });
    }
  });
  if (status !== 'Active') {
    entries.push({
      id: `AUD-${accountId}-status`, at: notices[0]?.received_at || SEED_REFERENCE_DATE.toISOString(), actor: 'Operations · Account Control',
      category: 'Account Status', action: `Account status set to ${status}`, detail: 'Applied under a law enforcement notice.',
    });
  }
  return entries.sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
}

export function createInitialBankState(accounts: Account[], transactions: Transaction[]): BankState {
  const state: BankState = {};
  accounts.forEach((account) => {
    const profile = buildProfile(account);
    const status = INITIAL_STATUS[account.id] || 'Active';
    const notices = buildNotices(account, profile, transactions);
    const statusNote: { category: string; reason: string; by: string; at: string } | undefined =
      status !== 'Active'
        ? {
            category: 'LEA Request',
            reason: `Applied under notice ${notices.find((n) => n.status === 'Action Applied')?.complaint_ref || 'on file'}.`,
            by: 'Operations · Account Control',
            at: notices[0]?.received_at || SEED_REFERENCE_DATE.toISOString(),
          }
        : undefined;
    state[account.id] = {
      status,
      status_note: statusNote,
      kyc: buildKycDocuments(account, profile),
      channels: buildChannels(account),
      requests: buildServiceRequests(account, profile),
      notices,
      audit: seedAudit(account.id, status, notices),
      flag_overrides: {},
    };
  });
  return state;
}
