import { useCallback, useMemo, useState } from 'react';
import { Account, Transaction } from '../types';
import {
  AccountStatus, AuditCategory, AuditEntry, BankState, CustomerState, PaymentChannelId,
  ServiceRequest, ServiceRequestStatus, ServiceRequestType,
} from '../types/banking';
import { CHANNEL_META, EMPLOYEE, createInitialBankState } from '../data/bankingData';
import { isFreezeAction } from '../utils/bankSelectors';

export const ACTOR = `${EMPLOYEE.name} (${EMPLOYEE.employee_id})`;

interface EntryInput { category: AuditCategory; action: string; detail: string }
type Outcome = { state: CustomerState; entries?: EntryInput[] } | null;

let auditSeq = 0;
const nowIso = () => new Date().toISOString();
const makeAudit = (e: EntryInput): AuditEntry => ({
  id: `AUD-${Date.now()}-${++auditSeq}-${Math.random().toString(36).slice(2, 6)}`,
  at: nowIso(), actor: ACTOR, ...e,
});
const digits = (n: number) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join('');

export interface NewRequestInput {
  type: ServiceRequestType;
  details: string;
  leaves?: 25 | 50 | 100;
  delivery_address?: string;
}

export interface BankActions {
  reviewKyc(accountId: string, docId: string, decision: 'Verified' | 'Rejected', remarks: string, category?: string): void;
  setChannel(accountId: string, channel: PaymentChannelId, enabled: boolean): void;
  setAllChannels(accountId: string, enabled: boolean, reason: string): void;
  changeStatus(accountId: string, status: AccountStatus, category: string, reason: string): void;
  setFlag(accountId: string, entryId: string, suspicious: boolean, reason: string): void;
  createRequest(accountId: string, input: NewRequestInput): string;
  updateRequest(accountId: string, requestId: string, patch: Partial<ServiceRequest>, event: { label: string; location?: string } | null, audit: { action: string; detail: string }): void;
  acknowledgeNotice(accountId: string, noticeId: string): void;
  applyNotice(accountId: string, noticeId: string, remarks: string): void;
  releaseNotice(accountId: string, noticeId: string, releaseRef: string, remarks: string, restoreActive: boolean): void;
  logNoticeView(accountId: string, noticeId: string): void;
  reset(accounts: Account[], transactions: Transaction[]): void;
}

export function useBankState(accounts: Account[], transactions: Transaction[]) {
  const [bank, setBank] = useState<BankState>(() => createInitialBankState(accounts, transactions));

  const mutate = useCallback((accountId: string, fn: (c: CustomerState) => Outcome) => {
    setBank((prev) => {
      const current = prev[accountId];
      if (!current) return prev;
      const out = fn(current);
      if (!out) return prev;
      const fresh = (out.entries || []).map(makeAudit).reverse();
      return { ...prev, [accountId]: { ...out.state, audit: [...fresh, ...out.state.audit] } };
    });
  }, []);

  const actions = useMemo<BankActions>(() => ({
    reviewKyc(accountId, docId, decision, remarks, category) {
      mutate(accountId, (c) => {
        const doc = c.kyc.find((d) => d.id === docId);
        if (!doc) return null;
        const note = [category, remarks.trim()].filter(Boolean).join(': ');
        return {
          state: {
            ...c,
            kyc: c.kyc.map((d) => d.id === docId
              ? { ...d, status: decision, remarks: note || undefined, reviewed_by: ACTOR, reviewed_at: nowIso() }
              : d),
          },
          entries: [{
            category: 'KYC',
            action: `${doc.type} ${decision === 'Verified' ? 'approved' : 'rejected'}`,
            detail: `${doc.document_name} (${doc.number_masked}) moved from ${doc.status} to ${decision}.${note ? ` Remarks: ${note}` : ''}`,
          }],
        };
      });
    },

    setChannel(accountId, channel, enabled) {
      mutate(accountId, (c) => ({
        state: {
          ...c,
          channels: c.channels.map((ch) => ch.id === channel
            ? { ...ch, enabled, last_changed_by: ACTOR, last_changed_at: nowIso(), reason: enabled ? undefined : 'Restricted by branch operations' }
            : ch),
        },
        entries: [{ category: 'Payment Control', action: `${CHANNEL_META[channel].label} ${enabled ? 'allowed' : 'restricted'}`, detail: `Channel control changed by ${ACTOR}.` }],
      }));
    },

    setAllChannels(accountId, enabled, reason) {
      mutate(accountId, (c) => ({
        state: {
          ...c,
          channels: c.channels.map((ch) => ({ ...ch, enabled, last_changed_by: ACTOR, last_changed_at: nowIso(), reason: enabled ? undefined : reason })),
        },
        entries: [{ category: 'Payment Control', action: enabled ? 'All channels allowed' : 'All channels restricted', detail: reason }],
      }));
    },

    changeStatus(accountId, status, category, reason) {
      mutate(accountId, (c) => {
        if (c.status === status) return null;
        return {
          state: { ...c, status, status_note: status === 'Active' ? undefined : { category, reason, by: ACTOR, at: nowIso() } },
          entries: [{ category: 'Account Status', action: `Account status changed: ${c.status} → ${status}`, detail: `${category}: ${reason}` }],
        };
      });
    },

    setFlag(accountId, entryId, suspicious, reason) {
      mutate(accountId, (c) => ({
        state: { ...c, flag_overrides: { ...c.flag_overrides, [entryId]: suspicious }, flag_notes: { ...(c.flag_notes || {}), [entryId]: reason } },
        entries: [{ category: 'Ledger', action: suspicious ? 'Transaction flagged as suspicious' : 'Suspicious flag cleared', detail: `Entry ${entryId}. ${reason}` }],
      }));
    },

    createRequest(accountId, input) {
      const d = new Date();
      const id = `SR-${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${digits(4)}`;
      mutate(accountId, (c) => {
        const isCheque = input.type === 'Cheque Book Request';
        const request: ServiceRequest = {
          id, type: input.type, status: 'Received', raised_at: nowIso(), raised_via: 'Branch',
          sla_due: new Date(Date.now() + 3 * 86400000).toISOString(), details: input.details,
          ...(isCheque ? { leaves: input.leaves || 25, delivery_address: input.delivery_address, address_check: 'Not Checked' as const } : {}),
          tracking: [{ at: nowIso(), label: 'Request received at branch' }],
        };
        return {
          state: { ...c, requests: [request, ...c.requests] },
          entries: [{ category: 'Service Request', action: `${input.type} raised`, detail: `${id}: ${input.details}` }],
        };
      });
      return id;
    },

    updateRequest(accountId, requestId, patch, event, audit) {
      mutate(accountId, (c) => ({
        state: {
          ...c,
          requests: c.requests.map((r) => r.id === requestId
            ? { ...r, ...patch, tracking: event ? [...r.tracking, { at: nowIso(), ...event }] : r.tracking }
            : r),
        },
        entries: [{ category: 'Service Request', action: audit.action, detail: `${requestId}. ${audit.detail}` }],
      }));
    },

    acknowledgeNotice(accountId, noticeId) {
      mutate(accountId, (c) => {
        const n = c.notices.find((x) => x.id === noticeId);
        if (!n || n.status !== 'New') return null;
        return {
          state: {
            ...c,
            notices: c.notices.map((x) => x.id === noticeId
              ? { ...x, status: 'Acknowledged', timeline: [...x.timeline, { at: nowIso(), actor: ACTOR, text: 'Notice acknowledged. Acknowledgement sent to the investigating officer.' }] }
              : x),
          },
          entries: [{ category: 'LEA', action: 'LEA notice acknowledged', detail: `${n.complaint_ref} from ${n.agency}.` }],
        };
      });
    },

    applyNotice(accountId, noticeId, remarks) {
      mutate(accountId, (c) => {
        const n = c.notices.find((x) => x.id === noticeId);
        if (!n || n.status === 'Action Applied' || n.status === 'Released') return null;
        const entries: EntryInput[] = [];
        let status = c.status;
        let status_note = c.status_note;
        const applied = n.action === 'Information Request' ? 'Requested records furnished to the investigating officer' : `${n.action} applied on the account`;
        entries.push({ category: 'LEA', action: n.action === 'Information Request' ? 'Records furnished to LEA' : `${n.action} applied`, detail: `${n.complaint_ref}.${remarks ? ` ${remarks}` : ''}` });
        const target: AccountStatus | null = n.action === 'Total Account Freeze' ? 'Total Freeze' : n.action === 'Debit Freeze' && c.status !== 'Total Freeze' ? 'Debit Freeze' : null;
        if (target && target !== c.status) {
          entries.push({ category: 'Account Status', action: `Account status changed: ${c.status} → ${target}`, detail: `LEA Request: applied under notice ${n.complaint_ref}.` });
          status = target;
          status_note = { category: 'LEA Request', reason: `Applied under notice ${n.complaint_ref}.`, by: ACTOR, at: nowIso() };
        }
        return {
          state: {
            ...c, status, status_note,
            notices: c.notices.map((x) => x.id === noticeId
              ? { ...x, status: 'Action Applied', timeline: [...x.timeline, { at: nowIso(), actor: ACTOR, text: `${applied}.${remarks ? ` ${remarks}` : ''}` }] }
              : x),
          },
          entries,
        };
      });
    },

    releaseNotice(accountId, noticeId, releaseRef, remarks, restoreActive) {
      mutate(accountId, (c) => {
        const n = c.notices.find((x) => x.id === noticeId);
        if (!n || n.status === 'Released') return null;
        const notices = c.notices.map((x) => x.id === noticeId
          ? { ...x, status: 'Released' as const, timeline: [...x.timeline, { at: nowIso(), actor: ACTOR, text: `Released against order ${releaseRef}.${remarks ? ` ${remarks}` : ''}` }] }
          : x);
        const entries: EntryInput[] = [{ category: 'LEA', action: 'LEA notice released', detail: `${n.complaint_ref}. Release order ${releaseRef}.${remarks ? ` ${remarks}` : ''}` }];
        let { status, status_note } = c;
        const stillFrozen = notices.some((x) => x.status === 'Action Applied' && isFreezeAction(x.action));
        if (restoreActive && !stillFrozen && (c.status === 'Debit Freeze' || c.status === 'Total Freeze')) {
          entries.push({ category: 'Account Status', action: `Account status changed: ${c.status} → Active`, detail: `LEA Release: restored after release order ${releaseRef}.` });
          status = 'Active';
          status_note = undefined;
        }
        return { state: { ...c, notices, status, status_note }, entries };
      });
    },

    logNoticeView(accountId, noticeId) {
      mutate(accountId, (c) => {
        const n = c.notices.find((x) => x.id === noticeId);
        if (!n) return null;
        return { state: c, entries: [{ category: 'LEA', action: 'Notice document viewed', detail: `${n.complaint_ref}. Opened in the secure viewer.` }] };
      });
    },

    reset(accs, txns) { setBank(createInitialBankState(accs, txns)); },
  }), [mutate]);

  return { bank, actions };
}

export type { ServiceRequestStatus };
