/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Account, CyberComplaint, EvidenceSubmission, RiskBand, Transaction } from './types';
import { INITIAL_ACCOUNTS, initializeSeedTransactions } from './data/seedData';
import { computeRiskScore, evaluateProfileMismatch } from './utils/riskEngine';
import { Sidebar, Tab } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { LeaDesk } from './components/LeaDesk';
import { CustomerWorkspace } from './components/banking/CustomerWorkspace';
import { WorkspaceTab } from './components/banking/context';
import { useBankState } from './state/useBankState';
import { buildAllProfiles } from './data/bankingData';
import { searchCustomers, pendingNotices } from './utils/bankSelectors';
import { LoginScreen } from './components/LoginScreen';
import { EthicsBanner } from './components/EthicsBanner';
import { DashboardStats } from './components/DashboardStats';
import { RiskBandChart } from './components/RiskBandChart';
import { TransactionsTable } from './components/TransactionsTable';
import { FraudChainGraph } from './components/FraudChainGraph';
import { InvestigationPanel } from './components/InvestigationPanel';
import { ProfileMismatchModal } from './components/ProfileMismatchModal';
import { ComplaintModal } from './components/ComplaintModal';
import { CustomerVerificationModal } from './components/CustomerVerificationModal';
import { TransactionDetailDrawer } from './components/TransactionDetailDrawer';
import { RiskEngineSimulator } from './components/RiskEngineSimulator';
import { TriggersHub } from './components/TriggersHub';
import { IncidentReportModal } from './components/IncidentReportModal';
import { GeminiChatbot } from './components/GeminiChatbot';
import { VoiceConversationModal } from './components/VoiceConversationModal';
import { OperationsCenter } from './components/OperationsCenter';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

const PAGES: Record<Tab, { group: string; title: string; sub: string }> = {
  customers: { group: 'Branch operations', title: 'Customer workspace', sub: 'Look up a customer, review KYC, control payments and handle service requests.' },
  lea: { group: 'Branch operations', title: 'LEA compliance desk', sub: 'Every notice from cyber cells, police and courts, across all accounts.' },
  dashboard: { group: 'Fraud monitoring', title: 'Overview and ledger', sub: 'Risk-scored transactions across the book.' },
  graph: { group: 'Fraud monitoring', title: 'Fraud chain graph', sub: 'Trace how funds move between accounts.' },
  cases: { group: 'Fraud monitoring', title: 'Investigation cases', sub: 'Work cases from first alert to disposition.' },
  triggers: { group: 'Fraud monitoring', title: 'Triggers and scrutiny', sub: 'Rules and events that raise accounts for review.' },
  simulator: { group: 'Fraud monitoring', title: 'Risk engine', sub: 'See how each signal changes a risk score.' },
  operations: { group: 'Fraud monitoring', title: 'Operations center', sub: 'Alert queue, watchlist, audit trail and reports.' },
};

export default function App() {
  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [transactions, setTransactions] = useState<Transaction[]>(() =>
    initializeSeedTransactions(INITIAL_ACCOUNTS)
  );

  const { bank, actions: bankActions } = useBankState(INITIAL_ACCOUNTS, transactions);
  const [activeTab, setActiveTab] = useState<Tab>('customers');
  const [workspaceTab, setWorkspaceTab] = useState<WorkspaceTab>('overview');
  const [customerId, setCustomerId] = useState<string>('ACC-FRD-01');
  const [pendingNoticeId, setPendingNoticeId] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => localStorage.getItem('fraudchain_sidebar') === 'collapsed');
  const [mobileNav, setMobileNav] = useState(false);
  const [selectedBand, setSelectedBand] = useState<RiskBand | 'ALL'>('ALL');

  // Modals & Drawers state
  const [selectedTxnForDrawer, setSelectedTxnForDrawer] = useState<Transaction | null>(null);
  const [targetTxnForModal, setTargetTxnForModal] = useState<Transaction | null>(null);
  const [activeModal, setActiveModal] = useState<'profileMismatch' | 'complaint' | 'verification' | 'exportReport' | null>(null);
  const [preselectedTxnIdForComplaint, setPreselectedTxnIdForComplaint] = useState<string | undefined>(undefined);

  // Gemini AI Chatbot & Voice Conversations
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => sessionStorage.getItem('fraudchain_authenticated') === 'true');
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<'light' | 'dark' | 'black'>(() =>
    (localStorage.getItem('fraudchain_theme') as 'light' | 'dark' | 'black') || 'light'
  );

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'alert' | 'info' } | null>(null);

  const accountsMap = useMemo(() => new Map(accounts.map((a) => [a.id, a])), [accounts]);
  const profiles = useMemo(() => buildAllProfiles(accounts), [accounts]);
  const pendingLeaCount = useMemo(() => accounts.reduce((n, a) => n + pendingNotices(bank[a.id]?.notices || []).length, 0), [accounts, bank]);
  const openAlertCount = useMemo(() => transactions.filter((t) => t.risk_band === 'Critical' || t.risk_band === 'High').length, [transactions]);

  const showToast = (message: string, type: 'success' | 'alert' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Re-sync transaction in drawer if updated
  const syncSelectedTxn = (updatedList: Transaction[]) => {
    if (selectedTxnForDrawer) {
      const match = updatedList.find((t) => t.transaction_id === selectedTxnForDrawer.transaction_id);
      if (match) setSelectedTxnForDrawer(match);
    }
  };

  // Handle Submit Customer Proof
  const handleSubmitProof = (txnId: string, evidence: EvidenceSubmission) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;

        const newNote = {
          id: `N-${Date.now()}`,
          author: 'Customer Mobile Gateway',
          role: 'SMS Evidence Portal',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: `Customer provided proof [${evidence.purposeCategory}]: "${evidence.description}". Document "${evidence.documentName}" verified.`,
        };

        return {
          ...t,
          evidence,
          investigation_status: 'Customer Confirmed' as const,
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });

    showToast(`Proof recorded for ${txnId}. Status marked as Customer Confirmed.`, 'success');
  };

  // Handle Customer Denial
  const handleDenyPayment = (txnId: string, denialReason: string) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;

        const updatedSignals = Array.from(new Set([...t.signals, 'CUSTOMER_DENIES']));
        const rec = computeRiskScore(t, accountsMap, updatedSignals);

        const newNote = {
          id: `N-${Date.now()}`,
          author: 'Customer Mobile Gateway',
          role: 'Fraud Report Desk',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: `CUSTOMER DENIAL REPORTED: ${denialReason}. Risk elevated by +40 points. Account marked for freeze triage.`,
        };

        return {
          ...t,
          signals: updatedSignals,
          risk_score: rec.score,
          risk_band: rec.band,
          detected_signals: rec.detectedSignals,
          investigation_status: 'Under Investigation' as const,
          evidence: {
            purposeCategory: 'Other' as const,
            description: denialReason,
            submittedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'denied' as const,
            denialReason,
          },
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });

    // Mark the receiving account as Under Investigation
    const targetTx = transactions.find((t) => t.transaction_id === txnId);
    if (targetTx) {
      setAccounts((prevAccs) =>
        prevAccs.map((acc) =>
          acc.id === targetTx.receiver_id ? { ...acc, risk_status: 'Under Investigation' } : acc
        )
      );
    }

    showToast(`ALERT: Customer denied knowledge of payment ${txnId}. Risk elevated to Critical!`, 'alert');
  };

  // Handle File Cyber Complaint
  const handleSubmitComplaint = (txnId: string, complaint: CyberComplaint, analystNoteText: string) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;

        const updatedSignals = Array.from(new Set([...t.signals, 'LINKED_TO_SUSPICIOUS', 'SENDER_SUSPICIOUS']));
        const rec = computeRiskScore(t, accountsMap, updatedSignals);

        const newNote = {
          id: `N-${Date.now()}`,
          author: 'Cyber Desk Ingest (1930)',
          role: 'Analyst',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: analystNoteText,
        };

        return {
          ...t,
          complaint,
          case_id: t.case_id || `CASE-${new Date().getFullYear()}-${t.transaction_id.slice(-6)}`,
          signals: updatedSignals,
          risk_score: rec.score,
          risk_band: rec.band,
          detected_signals: rec.detectedSignals,
          investigation_status: 'Under Investigation' as const,
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });

    showToast(`Cyber complaint ref ${complaint.portal_ref} filed against ${txnId}. Evidence request triggered.`, 'alert');
  };

  // Handle Case Status Update
  const handleUpdateStatus = (txnId: string, status: Transaction['investigation_status']) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;
        const newNote = {
          id: `N-${Date.now()}`,
          author: 'AML Compliance Officer',
          role: 'Analyst Ops',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: `Case disposition changed to: ${status}.`,
        };
        return {
          ...t,
          investigation_status: status,
          status_history: [
            {
              status,
              timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
              actor: 'AML Compliance Officer',
            },
            ...(t.status_history || []),
          ],
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });
    showToast(`Case ${txnId} status updated to: ${status}`, 'info');
  };

  // Handle Add Case Note
  const handleAddCaseNote = (txnId: string, noteText: string) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;
        const newNote = {
          id: `N-${Date.now()}`,
          author: 'Fraud Risk Analyst',
          role: 'Level 2 Reviewer',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: noteText,
        };
        return {
          ...t,
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });
    showToast(`Analyst note recorded on ${txnId}`, 'success');
  };

  // Handle Interactive Signal Toggling in Drawer
  const handleUpdateSignals = (txnId: string, updatedSignalCodes: string[]) => {
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;
        const rec = computeRiskScore(t, accountsMap, updatedSignalCodes);
        return {
          ...t,
          signals: updatedSignalCodes,
          risk_score: rec.score,
          risk_band: rec.band,
          detected_signals: rec.detectedSignals,
          label: rec.label,
        };
      });
      syncSelectedTxn(next);
      return next;
    });
  };

  // Demo Tour Launcher
  const handleLaunchDemoTour = (tourId: string) => {
    if (tourId === 'mule-chain') {
      setActiveTab('graph');
      const target = transactions.find((t) => t.transaction_id === 'TXN-894202');
      if (target) {
        setSelectedTxnForDrawer(target);
      }
      showToast('Tour loaded: Inspecting 4-Hop Rapid Money Forwarding Chain', 'info');
    } else if (tourId === 'profile-mismatch') {
      const target = transactions.find((t) => t.transaction_id === 'TXN-894202');
      if (target) {
        setTargetTxnForModal(target);
        setActiveModal('profileMismatch');
      }
      showToast('Tour loaded: Inspecting Student Profile Mismatch (+19.2x Limit)', 'info');
    } else if (tourId === 'complaint') {
      const target = transactions.find((t) => t.transaction_id === 'TXN-894201');
      if (target) {
        setTargetTxnForModal(target);
        setPreselectedTxnIdForComplaint(target.transaction_id);
        setActiveModal('complaint');
      }
      showToast('Tour loaded: Filing 1930 Cyber Crime Complaint on Transaction', 'info');
    }
  };

  // Inject High-Risk Fraud Spike Simulation
  const handleInjectSpike = () => {
    const newTxnId = `TXN-SPIKE-${Math.floor(1000 + Math.random() * 9000)}`;
    const newAmount = 375000;
    const receiverAcc = accounts.find((a) => a.id === 'ACC-MUL-01') || accounts[2]; // Student Aarav

    const raw = {
      transaction_id: newTxnId,
      sender_id: 'ACC-FRD-01', // Apex Digital
      receiver_id: receiverAcc.id,
      amount: newAmount,
      timestamp: new Date().toISOString(),
      display_time: 'Just Now',
      type: 'IMPS' as const,
      label: 'suspicious' as const,
      signals: ['SENDER_SUSPICIOUS', 'UNUSUAL_AMOUNT', 'RAPID_MULTIHOP', 'LINKED_TO_SUSPICIOUS'],
      investigation_status: 'Customer Verification Pending' as const,
      is_fraud_chain_part: true,
      chain_role: 'Mule Account A' as const,
      rapid_forward_minutes: 3,
      notes: [
        {
          id: `N-${Date.now()}`,
          author: 'Real-Time Ingestion Sensor',
          role: 'Core Rail Watcher',
          timestamp: 'Just now',
          text: `LIVE SPIKE DETECTED: Rapid IMPS inward credit of ₹3,75,000 received on Student account. Automated evidence request SMS sent.`,
        },
      ],
    };

    const evaluated = computeRiskScore(raw, accountsMap);
    const deviation = evaluateProfileMismatch(newAmount, receiverAcc);

    const fullTxn: Transaction = {
      ...raw,
      risk_score: evaluated.score,
      risk_band: evaluated.band,
      detected_signals: evaluated.detectedSignals,
      label: evaluated.label,
      profile_deviation: deviation.isMismatch
        ? {
            account_limit_max: deviation.maxLimit,
            multiplier: deviation.multiplier,
            is_mismatch: true,
          }
        : undefined,
    };

    setTransactions((prev) => [fullTxn, ...prev]);
    setSelectedTxnForDrawer(fullTxn);
    showToast(`🚨 Simulated High-Risk Spike Ingested: ${newTxnId} (Score: ${fullTxn.risk_score})`, 'alert');
  };

  // Reset Simulation Data
  const handleResetData = () => {
    setAccounts(INITIAL_ACCOUNTS);
    const freshTxns = initializeSeedTransactions(INITIAL_ACCOUNTS);
    setTransactions(freshTxns);
    bankActions.reset(INITIAL_ACCOUNTS, freshTxns);
    setSelectedBand('ALL');
    setSelectedTxnForDrawer(null);
    setActiveModal(null);
    setPendingNoticeId(null);
    showToast('Simulation dataset reset to initial state.', 'info');
  };

  const handleOverrideRisk = (txnId: string, score: number, reason: string) => {
    const safeScore = Math.min(100, Math.max(0, Math.round(score)));
    setTransactions((prev) => {
      const next = prev.map((t) => {
        if (t.transaction_id !== txnId) return t;
        const newNote = {
          id: `N-${Date.now()}`,
          author: 'Fraud Risk Analyst',
          role: 'Investigator Override',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          text: `Investigator adjusted automated risk score from ${t.risk_score} to ${safeScore}. Reason: ${reason}`,
        };
        return {
          ...t,
          risk_score: safeScore,
          risk_band: safeScore >= 76 ? 'Critical' as const : safeScore >= 51 ? 'High' as const : safeScore >= 26 ? 'Medium' as const : 'Low' as const,
          manual_risk_score: safeScore,
          risk_score_source: 'Investigator Override' as const,
          risk_override_reason: reason,
          notes: [newNote, ...t.notes],
        };
      });
      syncSelectedTxn(next);
      return next;
    });
    showToast(`Risk score manually adjusted to ${safeScore}/100`, 'info');
  };

  const handleThemeChange = (nextTheme: 'light' | 'dark' | 'black') => {
    setTheme(nextTheme);
    localStorage.setItem('fraudchain_theme', nextTheme);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('fraudchain_authenticated');
    setIsAuthenticated(false);
  };

  const openTransactionById = (txnId: string) => {
    const tx = transactions.find((t) => t.transaction_id === txnId);
    if (tx) setSelectedTxnForDrawer(tx);
    else showToast(`Transaction ${txnId} is not in the monitoring set.`, 'info');
  };

  const handleTopSearch = (query: string) => {
    const hit = searchCustomers(query, 'all', accounts, profiles)[0];
    if (!hit) { showToast(`No customer found for “${query}”.`, 'alert'); return; }
    setCustomerId(hit.account.id);
    setWorkspaceTab('overview');
    setActiveTab('customers');
    showToast(`Opened ${hit.account.name} (matched on ${hit.matchedOn.toLowerCase()}).`, 'info');
  };

  const toggleSidebar = () => setSidebarCollapsed((v) => { const next = !v; localStorage.setItem('fraudchain_sidebar', next ? 'collapsed' : 'open'); return next; });

  const activeCasesCount = transactions.filter(
    (t) => t.investigation_status === 'Under Investigation' || t.investigation_status === 'Customer Verification Pending'
  ).length;

  if (!isAuthenticated) {
    return <LoginScreen onAuthenticated={() => setIsAuthenticated(true)} />;
  }

  const page = PAGES[activeTab];

  return (
    <div className={`app-shell theme-${theme} min-h-screen`}>
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeCasesCount={activeCasesCount}
        pendingLeaCount={pendingLeaCount}
        collapsed={sidebarCollapsed}
        onToggleCollapsed={toggleSidebar}
        mobileOpen={mobileNav}
        onCloseMobile={() => setMobileNav(false)}
        onInjectSpike={handleInjectSpike}
        onResetData={handleResetData}
        onOpenChat={() => setIsChatbotOpen(true)}
        onOpenVoice={() => setIsVoiceModalOpen(true)}
      />

      <div className={`bk-main ${sidebarCollapsed ? 'is-collapsed' : ''}`}>
        <TopBar
          onOpenMenu={() => setMobileNav(true)}
          onSearch={handleTopSearch}
          alertCount={openAlertCount}
          onOpenAlerts={() => setActiveTab('operations')}
          theme={theme}
          onThemeChange={handleThemeChange}
          onLogout={handleLogout}
        />

        <div className="bk-pagehead">
          <nav aria-label="Breadcrumb">
            <ol className="bk-crumbs">
              <li><button onClick={() => setActiveTab('customers')}>Home</button></li>
              <li aria-hidden>/</li>
              <li>{page.group}</li>
              <li aria-hidden>/</li>
              <li aria-current="page">{page.title}</li>
              {activeTab === 'customers' && <><li aria-hidden>/</li><li>{accountsMap.get(customerId)?.name}</li></>}
            </ol>
          </nav>
          <h1>{page.title}</h1>
          <p>{page.sub}</p>
        </div>

        <main className="banking-content bk-content">
        {activeTab === 'customers' && (
          <CustomerWorkspace
            accounts={accounts}
            transactions={transactions}
            bank={bank}
            actions={bankActions}
            accountId={customerId}
            onSelectAccount={setCustomerId}
            tab={workspaceTab}
            onTab={setWorkspaceTab}
            onToast={showToast}
            onOpenTransaction={openTransactionById}
            initialNoticeId={pendingNoticeId}
            onNoticeClosed={() => setPendingNoticeId(null)}
          />
        )}

        {activeTab === 'lea' && (
          <LeaDesk
            accounts={accounts}
            bank={bank}
            onOpen={(accountId, noticeId) => {
              setCustomerId(accountId);
              setWorkspaceTab('lea');
              setPendingNoticeId(noticeId);
              setActiveTab('customers');
            }}
          />
        )}

  
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fadeIn">
            {/* KPI Cards */}
            <DashboardStats
              transactions={transactions}
              onFilterFlagged={() => setSelectedBand('Critical')}
              onFilterMuleChain={() => {
                setActiveTab('graph');
              }}
              onNavigateToCases={() => setActiveTab('cases')}
            />

            {/* Risk-Band Chart */}
            <RiskBandChart
              transactions={transactions}
              selectedBand={selectedBand}
              onSelectBand={setSelectedBand}
            />

            {/* Transaction Ledger Table */}
            <TransactionsTable
              transactions={transactions}
              accountsMap={accountsMap}
              selectedBand={selectedBand}
              onSelectTransaction={(tx) => setSelectedTxnForDrawer(tx)}
              onViewInGraph={(tx) => {
                setSelectedTxnForDrawer(tx);
                setActiveTab('graph');
              }}
              onOpenProfileMismatch={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('profileMismatch');
              }}
              onOpenCustomerVerification={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('verification');
              }}
              onOpenFileComplaint={(tx) => {
                setTargetTxnForModal(tx);
                setPreselectedTxnIdForComplaint(tx.transaction_id);
                setActiveModal('complaint');
              }}
            />
          </div>
        )}

        {/* TAB 2: INTERACTIVE FRAUD CHAIN GRAPH */}
        {activeTab === 'graph' && (
          <div className="space-y-6 animate-fadeIn">
            <FraudChainGraph
              accounts={accounts}
              transactions={transactions}
              selectedTransactionId={selectedTxnForDrawer?.transaction_id}
              onSelectTransaction={(tx) => setSelectedTxnForDrawer(tx)}
              onOpenCustomerVerification={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('verification');
              }}
              onOpenProfileMismatch={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('profileMismatch');
              }}
            />
          </div>
        )}

        {/* TAB 3: CASE INVESTIGATION PANEL */}
        {activeTab === 'cases' && (
          <div className="space-y-6 animate-fadeIn">
            <InvestigationPanel
              transactions={transactions}
              accountsMap={accountsMap}
              onSelectTransaction={(tx) => setSelectedTxnForDrawer(tx)}
              onViewInGraph={(tx) => {
                setSelectedTxnForDrawer(tx);
                setActiveTab('graph');
              }}
              onOpenCustomerVerification={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('verification');
              }}
              onUpdateStatus={handleUpdateStatus}
              onOverrideRisk={handleOverrideRisk}
              onAddCaseNote={handleAddCaseNote}
              onExportReport={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('exportReport');
              }}
            />
          </div>
        )}

        {/* TAB 4: TRIGGERS & SCRUTINY HUB */}
        {activeTab === 'triggers' && (
          <div className="space-y-6 animate-fadeIn">
            <TriggersHub
              accounts={accounts}
              transactions={transactions}
              onOpenProfileMismatch={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('profileMismatch');
              }}
              onOpenFileComplaint={(tx) => {
                setTargetTxnForModal(tx);
                setPreselectedTxnIdForComplaint(tx.transaction_id);
                setActiveModal('complaint');
              }}
              onOpenCustomerVerification={(tx) => {
                setTargetTxnForModal(tx);
                setActiveModal('verification');
              }}
            />
          </div>
        )}

        {/* TAB 5: RISK ENGINE SIMULATOR */}
        {activeTab === 'simulator' && (
          <div className="space-y-6 animate-fadeIn">
            <RiskEngineSimulator />
          </div>
        )}

        {/* TAB 6: BANK OPERATIONS CENTER */}
        {activeTab === 'operations' && (
          <OperationsCenter
            accounts={accounts}
            transactions={transactions}
            onSelectTransaction={(tx) => setSelectedTxnForDrawer(tx)}
            onOpenCase={(tx) => { setSelectedTxnForDrawer(tx); setActiveTab('cases'); }}
            onToast={showToast}
          />
        )}
        </main>

      {toast && (
        <div className="fixed bottom-5 right-5 z-[80] animate-slideUp" role="status" aria-live="polite">
          <div className={`bk-toast ${toast.type === 'alert' ? 'is-alert' : toast.type === 'info' ? 'is-info' : ''}`}>
            {toast.type === 'alert' && <AlertTriangle size={17} />}
            {toast.type === 'info' && <Info size={17} />}
            {toast.type === 'success' && <CheckCircle2 size={17} />}
            <span>{toast.message}</span>
            <button onClick={() => setToast(null)} className="bk-icon-btn" style={{ width: 26, height: 26, color: 'var(--bk-muted)' }} aria-label="Dismiss notification"><X size={14} /></button>
          </div>
        </div>
      )}

      {/* MODALS */}
      {/* 1. Profile Mismatch Modal */}
      <ProfileMismatchModal
        transaction={targetTxnForModal}
        accountsMap={accountsMap}
        isOpen={activeModal === 'profileMismatch'}
        onClose={() => setActiveModal(null)}
        onOpenCustomerVerification={(tx) => {
          setActiveModal('verification');
          setTargetTxnForModal(tx);
        }}
      />

      {/* 2. Cyber Complaint Modal */}
      <ComplaintModal
        isOpen={activeModal === 'complaint'}
        onClose={() => setActiveModal(null)}
        transactions={transactions}
        accountsMap={accountsMap}
        preselectedTxnId={preselectedTxnIdForComplaint}
        onSubmitComplaint={handleSubmitComplaint}
      />

      {/* 3. Customer Verification Modal */}
      <CustomerVerificationModal
        transaction={targetTxnForModal}
        accountsMap={accountsMap}
        isOpen={activeModal === 'verification'}
        onClose={() => setActiveModal(null)}
        onSubmitProof={handleSubmitProof}
        onDenyPayment={handleDenyPayment}
      />

      {/* 4. Incident SAR Report Modal */}
      <IncidentReportModal
        transaction={targetTxnForModal}
        accountsMap={accountsMap}
        isOpen={activeModal === 'exportReport'}
        onClose={() => setActiveModal(null)}
      />

      {/* 5. Transaction Detail Slide-Over Drawer */}
      <TransactionDetailDrawer
        transaction={selectedTxnForDrawer}
        accountsMap={accountsMap}
        isOpen={selectedTxnForDrawer !== null}
        onClose={() => setSelectedTxnForDrawer(null)}
        onViewInGraph={(tx) => {
          setActiveTab('graph');
        }}
        onOpenCustomerVerification={(tx) => {
          setTargetTxnForModal(tx);
          setActiveModal('verification');
        }}
        onOpenProfileMismatch={(tx) => {
          setTargetTxnForModal(tx);
          setActiveModal('profileMismatch');
        }}
        onOpenFileComplaint={(tx) => {
          setTargetTxnForModal(tx);
          setPreselectedTxnIdForComplaint(tx.transaction_id);
          setActiveModal('complaint');
        }}
        onUpdateSignals={handleUpdateSignals}
        onConsultCopilot={(tx) => {
          setIsChatbotOpen(true);
        }}
      />

      {/* 6. Gemini Multi-Turn AML Intelligence Chatbot */}
      <GeminiChatbot
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        accounts={accounts}
        transactions={transactions}
        onSelectTransaction={(tx) => {
          setSelectedTxnForDrawer(tx);
        }}
      />

      {/* 7. Gemini 3.8 Live API Voice Conversation Modal */}
      <VoiceConversationModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
      />

      <footer className="bk-footer">
        <span>FraudChain Bank operations portal · Synthetic demonstration data</span>
        <span>Client-side simulation · no real banking integration</span>
      </footer>
      </div>
    </div>
  );
}
