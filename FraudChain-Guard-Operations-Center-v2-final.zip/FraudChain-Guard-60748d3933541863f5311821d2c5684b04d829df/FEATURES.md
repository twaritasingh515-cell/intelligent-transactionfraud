# FraudChain Guard — Feature Map

## Core fraud monitoring
- Transaction ledger with risk-band filtering
- Automatic signal-weighted risk score (0–100)
- Profile mismatch detection
- Rapid multi-hop detection
- Customer denial signal
- Suspicious counterparty/network signals
- Manual investigator score override with reason
- Fraud-chain graph visualisation

## Investigation workflow
- Case/ticket creation
- Customer verification and evidence capture
- Cyber complaint simulation
- Status/escalation history
- Investigator notes
- Branch Manager / Internal Fraud Team / LEA / Resolved / Closed dispositions
- Incident report generation flow

## Operations Center
- Alert queue
- Customer 360
- Watchlist
- Audit trail
- Reports & exports
- System health
- Queue search and bulk review selection
- SLA-style triage indicators

## Analyst tools
- AML Copilot integration point
- Live voice integration point
- Risk-engine simulator
- High-risk spike simulator
- Theme switcher: Banking Light / Banking Dark / Black Ops

## Prototype boundary
This project uses synthetic demonstration data. It does not perform real account freezes, real banking transactions, real KYC decisions, or real regulatory filing.
